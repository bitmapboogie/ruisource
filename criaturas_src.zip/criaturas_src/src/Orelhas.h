#ifndef ORELHAS_H
#define ORELHAS_H


#include "ofMain.h"
#include "ofxVectorMath.h"
#include "Ponto.h"
#include "Tira.h"

#define NumTiras 5

//the antenas that appear on the fingertips :)
//they are formed by a wobbly line (the "Tira" class) and a circle at the end
//p.s. "Orelhas" means ears, and at first, were suposed to be ears and not these antenas, but then it just evolve int this...

class Criatura;

class Orelhas {
public:

	Tira tiras[NumTiras];

	Criatura *mae;
	Orelhas();
	Orelhas(Criatura *_mae, ofxVec2f iniPos);
	
	virtual void move(ofxVec2f _target);
	virtual void render();
};

#endif