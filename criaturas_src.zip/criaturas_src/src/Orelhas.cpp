
#include "Orelhas.h"
#include "Criatura.h"

Orelhas::Orelhas(){
}

Orelhas::Orelhas(Criatura *_mae, ofxVec2f iniPos){
	mae = _mae;
	for(int i=0; i<NumTiras; i++){
		tiras[i] = Tira(iniPos);
	}
}

void Orelhas::move(ofxVec2f _target){
	
	for(int i=0; i<NumTiras; i++){
		tiras[i].move(_target, -HALF_PI);
	}
}

void Orelhas::render(){
	for(int i=0; i<NumTiras; i++){
		tiras[i].render(mae->fillColor, mae->glowColor);
	}
}












