/*
 *  Ponto.cpp
 *  openFrameworks
 *
 *  Created by rui madeira on 6/23/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#include "Ponto.h"

Ponto::Ponto(){
	k = 0.5;
	damp = 0.9;
	pos = 0;
	vel = 0;
	acel = 0;
}

Ponto::Ponto(ofxVec2f _pos){
	pos = _pos;
	vel = 0;
	acel = 0;
	k = 0.2;
	damp = 0.6;
	oldPos = pos;
}

void Ponto::goTo(ofxVec2f target){
	acel = (target - pos) * k;
	vel += acel;
	vel *= damp;
	pos += vel;
}

void Ponto::goTo(ofxVec2f target, float clipDist){
	acel = (target - pos) * k;
	vel += acel;
	vel *= damp;
	pos += vel;
	
	float distX = target.x - pos.x;
	float distY = target.y - pos.y;
	float distSQ = distX*distX + distY+distY;
	
	float clipDistSQ = clipDist*clipDist;
	if(distSQ > clipDistSQ){
		ofxVec2f clipedPos = target - pos;
		clipedPos /= distSQ;
		clipedPos *= clipDistSQ;
		clipedPos += target;
		pos = clipedPos;
	}
}
















