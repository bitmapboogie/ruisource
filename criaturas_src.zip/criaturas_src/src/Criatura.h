#ifndef SILHUETA_DEFS
#define SILHUETA_DEFS

#define OF_ADDON_USING_OFXVECTORMATH

#include "ofMain.h"
#include "ofxOpenCv.h"
#include "ofxCvBlobToo.h"
#include "Particles.h"
#include "Constants.h"
#include "perlin.h"
#include "Ponto.h"

#include "Orelhas.h"
#include "Face.h"
#include "Tira.h"



class Criatura{
public:
	float angOffSet;
	
	vector <Ponto> p;
	
	ofxCvBlobToo * blob;
	
	Perlin *noise;
	int indexOffSet;
	
	int oldDefectsNum;
	ofPoint oldCentro;
	bool hasBlob;
	
	int fillColor[3], lineColor[3], glowColor[3];
	
	vector <Orelhas> orelhas;
	vector <Tira> tiras;
	//Orelhas orelhas;
	Face face;
	
	vector <Particles> *particlesPtr;
	
	Criatura();
	Criatura(Perlin *_noise, vector<Particles> *_particlesPtr);
	~Criatura();
	void reset();
	void updateBlob(ofxCvBlobToo *_blob);
	void updatePontos();
	void updateOrelhas();
	void mover();
	void render();
	void renderContours();
	unsigned long& getBlobId();
};


#endif