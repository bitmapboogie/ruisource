#ifndef CORNER_H
#define CORNER_H

#include "ofMain.h"

class Corner{
public:
	float x, y;
	Corner();
	~Corner();
	void setCoords(int _x, int _y);
	bool mouseOver(int _x, int _y);
	void draw();
};


#endif