#ifndef OLHOS_H
#define OLHOS_H


#include "ofMain.h"
#include "ofxVectorMath.h"
#include "Ponto.h"

//this basically draws the eyes
//futura code might include eyebrows, maybe a mouth, and maybe freckles or some other visual candy

class Criatura;

class Face{
public:
	Criatura *mae;
	ofxVec2f acel, vel, pos, eyePos, posOffSet;
	float gap[2], outerSize[2], innerSize[2], innerOffSet[2];
	
	int blinkCountDown;
	bool blinking;
	float scaleUp;

	Face();
	Face(Criatura *_mae);
	~Face();
	
	void reset();
	
	virtual bool blink();
	virtual void move();
	virtual void render();
	
	void renderOlhos();
};

#endif
