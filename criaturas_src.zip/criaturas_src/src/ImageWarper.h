#ifndef IMAGEWARPER_H
#define IMAGEWARPER_H

#include "ofMain.h"
#include "ofxCvImage.h"
#include "Corner.h"

//not much of a proper GUI but oh well...
//simple class to perform perspective warping on an image

class ImageWarper{
public:
	
	int imgX, imgY, imgWidth, imgHeight;
	ofxCvImage *srcImg, *warpedImg;
	Corner corner[4];
	ofPoint srcPts[4], dstPts[4];
	int whichCorner;
	
	ImageWarper();
	~ImageWarper();
	void setup(ofxCvImage *_srcImage, ofxCvImage *_warpedImg, int _imgX, int _imgY);
	void checkCornerHit(int _x, int _y);
	void updateCorner(int _mouseX, int _mouseY);
	void warpImage();
	void draw();
	

};

#endif