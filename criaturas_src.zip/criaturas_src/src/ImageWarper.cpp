/*
 *  ImageWarper.cpp
 *  openFrameworks
 *
 *  Created by rui madeira on 6/18/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#include "ImageWarper.h"
using namespace std;

ImageWarper::ImageWarper(){
}

ImageWarper::~ImageWarper(){}

void ImageWarper::setup(ofxCvImage *_srcImg, ofxCvImage *_warpedImg, int _imgX, int _imgY){
	srcImg = _srcImg;
	warpedImg = _warpedImg;
	imgX = _imgX;
	imgY = _imgY;
	imgWidth = srcImg->width;
	imgHeight = srcImg->height;
	
	corner[0].setCoords(0, 0);
	corner[1].setCoords(imgWidth, 0);
	corner[2].setCoords(imgWidth, imgHeight);
	corner[3].setCoords(0, imgHeight);
	
	for(int i=0; i<4; i++){
		dstPts[i].x = corner[i].x;
		dstPts[i].y = corner[i].y;
		srcPts[i].x = corner[i].x;
		srcPts[i].y = corner[i].y;
	}
}

void ImageWarper::checkCornerHit(int _x, int _y){
	whichCorner = -1;
	for(int i=0; i<4; i++){
		int dx = (_x-imgX) - corner[i].x;
		int dy = (_y-imgY) - corner[i].y;
		float distSQ = dx*dx+dy*dy;
		if(distSQ<=100) {
			whichCorner = i;
		}
	}
}

void ImageWarper::updateCorner( int _mouseX, int _mouseY){
	if(whichCorner>-1){
		corner[whichCorner].x = _mouseX-imgX;
		corner[whichCorner].y = _mouseY-imgY;
		srcPts[whichCorner].x = corner[whichCorner].x;
		srcPts[whichCorner].y = corner[whichCorner].y;
	}
}


void ImageWarper::warpImage(){
	warpedImg->warpIntoMe((*srcImg), srcPts, dstPts);
}

void ImageWarper::draw(){
	glPushMatrix();
	glTranslatef(imgX, imgY, 0);
	for(int i=0; i<4; i++){
		if(whichCorner == i){
			ofSetColor(255, 0, 0);
		} else ofSetColor(0, 255, 0);
		corner[i].draw();
	}
	ofLine(corner[0].x, corner[0].y, corner[1].x, corner[1].y);
	ofLine(corner[1].x, corner[1].y, corner[2].x, corner[2].y);
	ofLine(corner[2].x, corner[2].y, corner[3].x, corner[3].y);
	ofLine(corner[3].x, corner[3].y, corner[0].x, corner[0].y);
	glPopMatrix();
}

















