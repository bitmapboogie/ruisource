#ifndef PARTICLES_H
#define PARTICLES_H


#include "ofMain.h"
#include "ofxVectorMath.h"
#include "Constants.h"
#include "perlin.h"

class Particles{
public:
	
	ofxVec2f pos, vel, acel;
	int color[3];
	int life, iniLife;
	float G;
	float size;
	Perlin *noise;
	
	Particles();
	Particles(ofxVec2f iniPos,ofxVec2f iniVel, Perlin *_noise);
	
	void mover();
	void render();
	
	
private:
	GLfloat damp;
};

#endif
	