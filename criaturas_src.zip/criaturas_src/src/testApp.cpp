#include "testApp.h"
using namespace std;

bool deadParticle(Particles _p){
	return _p.life == 0;
}



//--------------------------------------------------------------
void testApp::setup(){
	ofBackground(220,220,240);
	ofSetVerticalSync(true);
	ofEnableAlphaBlending();
	glEnable(GL_LINE_SMOOTH);
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glLineWidth(2);
//	glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
	threshold = 80;
	full = false;
	showSettings = false;
	vid.setVerbose(true);
	vid.initGrabber(640, 480);
	frame.allocate(vid.width, vid.height);
	grayFrame.allocate(vid.width, vid.height);
	smallGrayFrame.allocate(floor(vid.width/ScaleDown), floor(vid.height/ScaleDown));
	warpedImage.allocate(floor(vid.width/ScaleDown), floor(vid.height/ScaleDown));
	smallBackground.allocate(floor(vid.width/ScaleDown), floor(vid.height/ScaleDown));
	difImage.allocate(floor(vid.width/ScaleDown), floor(vid.height/ScaleDown));
	
	noise = new Perlin(4, 4, 1, time(NULL));
	
	for(int i=0; i<MaxBlobs; i++){
		criaturas[i] = new Criatura(noise, &particles);
	}
	
	idleScreen = new IdleScreen(noise);
	
	imgX = 20;
	imgY = 20;
	warper.setup(&smallGrayFrame, &warpedImage);
	warper.load();
	oldBlobNum = 0;
	
	particles.reserve(MaxParticles);
	
	flipMode = 0;
	
	//ofHideCursor();
	//ofAddListener(contourFinder.addBlob, this, &testApp::onAddBlob);
	//ofAddListener(contourFinder.removeBlob, this, &testApp::onRemoveBlob);
}

//--------------------------------------------------------------
void testApp::update(){
	vid.grabFrame();
	if(vid.isFrameNew()){
		frame.setFromPixels(vid.getPixels(), 640, 480);
		grayFrame = frame;
		smallGrayFrame.scaleIntoMe(grayFrame, CV_INTER_LINEAR);
		cvFlip(smallGrayFrame.getCvImage(), smallGrayFrame.getCvImage(), flipMode);
		warper.warp();
		difImage.absDiff(smallBackground, warpedImage);
		difImage.threshold(threshold);
		
	
		contourFinder.findContoursAndDefects(difImage, MinBlobSize, MaxBlobSize, MaxBlobs, true, false);

		vector<ofxCvBlobToo>&blobs = contourFinder.getBlobs();
		int nBlobs = blobs.size();

		for(int i=0; i<MaxBlobs; i++){
			if(criaturas[i]->hasBlob){
				bool bBlobRemoved = true;
				for(int j=0; j<nBlobs; j++){
					if(criaturas[i]->blob == &blobs[j]){
						bBlobRemoved = false;
						break;
					}
				}
				if(bBlobRemoved){
					criaturas[i]->updateBlob(NULL);
				}
			}
		}
		
		
		for(int i=0; i<nBlobs; i++){
			bool bBlobTaken = false;
			for(int j=0; j<MaxBlobs; j++){
				if(criaturas[j]->hasBlob){
					if(criaturas[j]->blob == &blobs[i]){
						bBlobTaken = true;
						break;
					}
				}
			}
			if(bBlobTaken == false){
				for(int j=0; j<MaxBlobs; j++){
					if(!criaturas[j]->hasBlob){
						criaturas[j]->updateBlob(&blobs[i]);
						break;
					}
				}
			}
		}
		
		oldBlobNum = nBlobs;
		if(nBlobs == 0){
			idleScreen->setAlpha(1.0, 0.05f);
		} else {
			idleScreen->setAlpha(0.0f, 0.1f);
		}
	}
	idleScreen->update();
		
	for(int i=0; i<MaxBlobs; i++){
		if(criaturas[i]->hasBlob){
			criaturas[i]->updatePontos();
			criaturas[i]->mover();
		}
	}
	
	for(int i=0; i<particles.size(); i++){
		particles[i].mover();
	}	
	
	particles.erase(std::remove_if(particles.begin(), particles.end(), &deadParticle), particles.end());
	
}

//--------------------------------------------------------------
void testApp::draw(){
	

	for(int i=0; i<MaxBlobs; i++){
		if(criaturas[i]->hasBlob){
			criaturas[i]->render();
		}
	}
	
	ofFill();
	for(int i=0; i<particles.size(); i++){
		particles[i].render();
	}
	
	idleScreen->draw();
	ofSetRectMode(OF_RECTMODE_CORNER);
	if(showSettings){
		showSettingsFunc();
	}
}


//--------------------------------------------------------------
void testApp::keyPressed  (int key){ 
	if(key == 'c' or key == 'C') copyBackground();
	if(key == '+'){
		threshold++;
		if(threshold>255) threshold == 255;
		if(threshold<0) threshold == 0;
	}
	if(key == '-'){ threshold--;
		if(threshold>255) threshold == 255;
		if(threshold<0) threshold == 0;
	}
	if(key == 'f' or key == 'F'){
		full = !full;
		ofSetFullscreen(full);
	}
	
	if(key == ' '){
		showSettings = !showSettings;
		if(showSettings) ofShowCursor();
		else ofHideCursor();
	}
	
	//if(key == 's' or key == 'S') vid.videoSettings();
	if(key == 's' or key == 'S')warper.save();
	if(key == 'l' or key == 'L')warper.load();
	
	if(key == 'r' or key == 'R'){
		flipMode++;
		if(flipMode > 1){
			flipMode = -1;
		}
	}
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){
	if(showSettings){
		mouseX = x;
		mouseY = y;
	}
}	

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
}

//--------------------------------------------------------------
void testApp::mouseReleased(){
}

void testApp::copyBackground(){
	smallBackground = warpedImage;
}

void testApp::showSettingsFunc(){
	glPushAttrib(GL_COLOR_BUFFER_BIT);
	glDisable(GL_BLEND);
	glLineWidth(1);
	ofSetColor(0,0,0);
	ofRect(imgX, imgY, smallGrayFrame.width, smallGrayFrame.height);
	ofRect(40+smallGrayFrame.width, 20, warpedImage.width, warpedImage.height);
	ofRect(20, warpedImage.height+40, smallBackground.width, smallBackground.height );
	ofRect(40 + smallBackground.width, warpedImage.height+40, difImage.width, difImage.height);
	ofSetColor(255, 255, 255, 255);
	smallGrayFrame.draw(imgX, imgY, smallGrayFrame.width, smallGrayFrame.height);
	warpedImage.draw(40+smallGrayFrame.width, 20, warpedImage.width, warpedImage.height);
	smallBackground.draw(20, warpedImage.height+40);
	difImage.draw(40 + smallBackground.width, warpedImage.height+40);
	string info = 	
	"THRESHOLD: " + ofToString(threshold, 0) + " (PRESS'+' OR '-' TO CHANGE)\n" +
	"FRAMES PER SECOND: " + ofToString(ofGetFrameRate(), 2) + "\n" + 
	"FOUND " + ofToString(contourFinder.getNumBlobs(), 0) + " BLOBS, OUT OF "+ofToString(MaxBlobs, 0) + " MAXIMUM\n"+
	"PRESS 'R' TO SWITCH BETWEEN THE DIFERENT IMAGE FLIP MODES\n"+
	"PRESS 'C' TO COPY BACKGROUND";
	ofSetColor(3, 3, 3);
	ofDrawBitmapString(info, 20, ofGetHeight()-90);
	//warper.updateCorner(mouseX, mouseY);
	warper.draw(imgX, imgY);
	glPopAttrib();
}




