#ifndef PONTO_H
#define PONTO_H

#define OF_ADDON_USING_OFXVECTORMATH

#include "ofMain.h"
#include "ofxVectorMath.h"

//this is a Point class which is basically the base of everything here...
//it has variables to store various data and a function to interpolate between values using an elastic force

class Ponto{
public:
	ofxVec2f pos, offSet, vel, acel, oldPos;
	float k, damp;
	float hairHeight;
	float ang;
	float angOffSet;
	
	Ponto();
	Ponto(ofxVec2f _pos);
	void goTo(ofxVec2f target);
	void goTo(ofxVec2f target, float clipDist);
	
};

#endif




