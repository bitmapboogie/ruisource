#include "IdleScreen.h"

IdleScreen::IdleScreen(Perlin*_noise){
	noise = _noise;
	alpha = 1.0f;
	bNewAlpha = false;
	targetAlpha = alpha;
	alphaInterp = 0.1f;
	textImg = new ofImage();
	textImg->loadImage("texto.png");
	tableImg = new ofImage();
	tableImg->loadImage("mesa.png");
	for(int i=0; i<4; i++){
		color[i] = 1.0f;
	}
	tableAlpha = 1.0f;
}

IdleScreen::~IdleScreen(){
	textImg->clear();
	tableImg->clear();
}

void IdleScreen::update(){
	if(bNewAlpha){
		alpha += (targetAlpha - alpha) * alphaInterp;
		if(fabs(alpha - targetAlpha) < 0.05){
			alpha = targetAlpha;
			bNewAlpha = false;
		}
	}
	color[3] = alpha;
	if(alpha > 0.0f)
	tableAlpha = MIN(1.0f, (cos(((float)ofGetFrameNum())*0.03f) + 1.0f))*alpha; 
	else tableAlpha = 0;
}

void IdleScreen::setAlpha(float _alpha){
	targetAlpha = _alpha;
	bNewAlpha = true;
}

void IdleScreen::setAlpha(float _alpha, float _alphaInterp){
	targetAlpha = _alpha;
	alphaInterp = _alphaInterp;
	bNewAlpha = true;
}

void IdleScreen::draw(){
	ofSetRectMode(OF_RECTMODE_CENTER);
	glColor4fv(color);
	float x = ofGetWidth()*0.5f;
	float y = ofGetHeight()*0.5f;
	textImg->draw(x, y);
	glColor4f(1.0f, 1.0f, 1.0f, tableAlpha);
	tableImg->draw(x, y);
}

