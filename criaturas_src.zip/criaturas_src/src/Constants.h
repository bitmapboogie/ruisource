#ifndef CONSTANTS_H
#define CONSTANTS_H

//i have since found that having a single file with all the constants of all the classes is not a very good ideia :)

//#define MINI_DV
#define WEB_CAM

#define ScaleDown 2

#define QUARTER_PI 0.785398163

#ifdef WEB_CAM
#define CamWidth 640
#define CamHeight 480
#define Scale2Screen 1024/(640/ScaleDown)
#endif

#ifdef MINI_DV
#define CamWidth 720
#define CamHeight 578
#define Scale2Screen (1024/720)*ScaleDown
#endif

#define MaxBlobs 10
#define MaxBlobSize CamWidth*CamHeight/3
#define MinBlobSize 100

#define MaxParticles 300

#define FlowFieldComplexity 1000

#define MAXBLOBDIST 50
#define MAXBLOBDISTSQ MAXBLOBDIST*MAXBLOBDIST


#endif