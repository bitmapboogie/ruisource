#include "Criatura.h"
using namespace std;

Criatura::Criatura(){
	angOffSet = 0;
	
	reset();	
}

Criatura::~Criatura(){
	
}

Criatura::Criatura(Perlin *_noise, vector<Particles> *_particlesPtr){
	noise = _noise;
	particlesPtr = _particlesPtr;
	angOffSet = 0;
	
	reset();	
}

void Criatura::reset(){
	ofxVec3f colorVec = ofxVec3f(0,0,180);
	colorVec.rotate(ofRandom(0, 360), ofRandom(0, 360), 0);
	fillColor[0] = abs((int)colorVec[0]);
	fillColor[1] = abs((int)colorVec[1]);
	fillColor[2] = abs((int)colorVec[2]);
	
	for(int i=0; i<3; i++){
		lineColor[i] = MAX(0, fillColor[i] - (int)ofRandom(30, 50));
		glowColor[i] = MIN(255, fillColor[i] + (int)ofRandom(80, 100));
	}
	
	face = Face(this);
    orelhas.clear();
	oldDefectsNum = 0;
	blob = NULL;
	hasBlob = false;
}

void Criatura::updateBlob(ofxCvBlobToo * _blob){
	if(_blob == NULL){
		_blob = NULL;
		hasBlob = false;
	} else {
		blob = _blob;
		//blob->hasCriatura = true;
		oldCentro = blob->getCentroid();
		hasBlob = true;
	}
}


//this function updates the points that form each Criatura to match the number of points contained in the blob
void Criatura::updatePontos(){	
	vector<ofPoint>&pts = blob->getPoints();
	int nPts = pts.size();
	if(p.size() < nPts){ //if our Criatura has less points than the blob it is tracking 
		int dif = nPts - p.size();//then we need to insert new points
		for(int i=0; i<dif; i++){
			int pos = (int)((float)nPts / dif * i); //points are distributed uniformely in the shape at regular intervals
			ofxVec2f iniPos = ofxVec2f(pts[pos].x, pts[pos].y);
			p.insert(p.begin()+pos, Ponto(iniPos)); //maybe a std::vector is not the best choice for this...
		}
	}
	
	if(p.size() > nPts){ //if our Criatura has more points than the blob it is tracking
		int dif = p.size() - nPts; //then we need to erase points...
		for(int i=0; i<dif; i++){
			int pos = (int)((float)nPts / dif * i);//points are erased at regular intervals
			p.erase(p.begin()+pos, p.begin()+pos+1);
		}
	} 
}

void Criatura::mover(){ 
	angOffSet += 0.5;
	int larg = 5;
	vector<ofPoint>& pts = blob->getPoints();
	for(int i=0; i<p.size(); i++){
		ofxVec2f target = ofxVec2f(pts[i].x, pts[i].y);
		//p[i].goTo(target, 100);
		p[i].pos = target;
		
		//particles *might* be created at each point if its velocity is greater than a certain value 
		ofxVec2f pVel = p[i].pos - p[i].oldPos;
		float pVelSQ = pVel.x*pVel.x + pVel.y+pVel.y; //finding the squared value of the velocity
		
		float minVel2CreateParticlesSQ = 400;//minimun vel to create particles
		if(pVelSQ > minVel2CreateParticlesSQ){
			if(ofRandom(0, 10) < 1.0f){ //maybe create the particle, maybe not (this is to restrain the number of particles
				if(particlesPtr->size() < MaxParticles){
					particlesPtr->push_back(Particles(p[i].pos, p[i].vel*4, noise));
				}
			}
		}
		p[i].oldPos = p[i].pos;
	}
	
	//this finds the position of each point that forms the creature to create the waving animation
	for(int i=0; i<p.size(); i++){
		int next = (i+20)%p.size();
		float ang = atan2(p[next].pos.y - p[i].pos.y, p[next].pos.x - p[i].pos.x)+QUARTER_PI; //this finds the perpendicular angle between this point and the point 20 positions ahead
		float scaleAngle = ((float)i)/(p.size()-1)*TWO_PI*blob->getLength()/20; //the angle that will be used by the sin and cos to determine how wide the offset will be
		float scale = larg + (sin(scaleAngle+angOffSet)+1)*5; //how wide the offset will be
		p[i].offSet.x = cos(ang) * scale; //offset.x
		p[i].offSet.y = sin(ang) * scale; //offset.y
	}
	indexOffSet = 0;
	
	face.move();
	
	updateOrelhas();//update those antenas
	
	int whichOrelha = 0;
	vector<ofxCvConvexityDefect>& defects = blob->getDefects();
	int nDefects = defects.size();
	for(int i=0; i<nDefects; i++){
		if(defects[i].depth > 10){ //place an antena on each starting point of a convexity defects whose depth is greater than 10
			ofPoint& startPt = defects[i].startPoint;
			ofPoint& endPt = defects[i].endPoint;
			ofxVec2f target = ofxVec2f(startPt.x, startPt.y);
			orelhas[whichOrelha].move(target);
			whichOrelha++;
		}
	}
	oldCentro = blob->getCentroid();
	
}

void Criatura::render(){
	if(!blob->isHole()){ //i think the boolean value to check if it is a hole is wrong, returning true means it is NOT a hole.
		glLineWidth(2);
		for(int i=0; i<orelhas.size(); i++){
			orelhas[i].render();
		}
	}
	ofFill();
	
	ofSetPolyMode(OF_POLY_WINDING_NONZERO);
	
	if(!blob->isHole())ofSetColor(fillColor[0], fillColor[1], fillColor[2]);	
	else ofSetColor(220, 220, 240);//if it is a hole, then fill with the background color
	ofBeginShape();
	for(int i=0; i<p.size(); i+=2){
		ofVertex((p[i].pos.x+p[i].offSet.x)*Scale2Screen, (p[i].pos.y+p[i].offSet.y)*Scale2Screen);
	}
	
	ofEndShape(true);
	
	renderContours();
	
	if(!blob->isHole()){ //if it is not a hole then render the face
		face.render();
	}
}

void Criatura::renderContours(){
	indexOffSet++;
	ofSetColor(lineColor[0], lineColor[1], lineColor[2]);
	if(blob) glLineWidth(3); else glLineWidth(1);
	glBegin(GL_LINE_STRIP);
	for(int i=0; i<p.size(); i+=2){
		glVertex2f((p[i].pos.x+p[i].offSet.x)*Scale2Screen, (p[i].pos.y+p[i].offSet.y)*Scale2Screen);
	}
	glEnd();
	if(!blob->isHole()){
		glLineWidth(2);
		glBegin(GL_LINES);
		for(int i=0; i<p.size(); i+=10){
			glVertex2f(p[i].pos.x*Scale2Screen, p[i].pos.y*Scale2Screen);
			glVertex2f((p[i].pos.x + p[i].offSet.x) * Scale2Screen, (p[i].pos.y + p[i].offSet.y) * Scale2Screen);
		}
		glEnd();
	}
}


void Criatura::updateOrelhas(){
	int defectsNum = 0;
	vector<ofxCvConvexityDefect>& defects = blob->getDefects();
	int nDefects = defects.size();
	for(int i=0; i<nDefects; i++){
		if(defects[i].depth > 10){
			defectsNum++; //the number of defects with a depth greater than 10
		}
	}
	if(oldDefectsNum > defectsNum){ //if we have more antenas than defects then we need to erase the correct amount
		int dif = oldDefectsNum - defectsNum;
		for(int i=0; i<dif; i++){
			orelhas.pop_back();
		}
	} 
	if( oldDefectsNum < defectsNum) {//if we have more defects than antenas then we need to push_back the correct amount
		int dif = defectsNum - oldDefectsNum;
		for(int i=0; i<dif; i++){
			ofPoint& centroid = blob->getCentroid();
			ofxVec2f iniPos = ofxVec2f(centroid.x, centroid.y);
			orelhas.push_back(Orelhas(this, iniPos));
		}
	}
	oldDefectsNum = defectsNum;
}

unsigned long& Criatura::getBlobId(){
	return blob->getSessionId();
}





