/*
 *  Tira.cpp
 *  openFrameworks
 *
 *  Created by rui madeira on 7/21/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#include "Tira.h"

Tira::Tira(){}

Tira::Tira(ofxVec2f iniPos){
	angOffSet = ofRandom(-0.7f, 0.7f);
	length = ofRandom(0.3, 1.5f);
	size = (int)ofRandom(5, 10);
	for(int i=0; i<5; i++){
		p[i] = Ponto(iniPos);
	}
}

void Tira::move(ofxVec2f target, float ang){
	ang += angOffSet;
	ofxVec2f hsVec = ofxVec2f(cos(ang)*length, sin(ang)*length);
	p[0].pos = target;
	for(int i=1; i<5; i++){
		p[i].goTo(p[i-1].pos);
		p[i].vel += hsVec;
	}
}

void Tira::render(int lineColor[3], int fillColor[3]){
	ofSetColor(lineColor[0], lineColor[1], lineColor[2]);
	glLineWidth(3);
	glBegin(GL_LINES);
	for(int i=1; i<5; i++){
		glVertex2f(p[i].pos.x *Scale2Screen, p[i].pos.y *Scale2Screen);
		glVertex2f(p[i-1].pos.x*Scale2Screen, p[i-1].pos.y*Scale2Screen);
	}
	glEnd();
	
	ofFill();
	
	ofSetColor(fillColor[0], fillColor[1], fillColor[2]);
	ofCircle(p[4].pos.x * Scale2Screen, p[4].pos.y * Scale2Screen, size);
	ofSetColor(lineColor[0], lineColor[1], lineColor[2]);
	ofNoFill();
	ofCircle(p[4].pos.x * Scale2Screen, p[4].pos.y * Scale2Screen, size);
}






