#pragma once


#include "ofMain.h"
#include "ofxVectorMath.h"
#include "ofxOpenCv.h"
#include "Constants.h"
#include "Ponto.h"

//the wobbly line that connects the antenas

class Tira{
public:

	Ponto p[5];
	float angOffSet;
	float length;
	int size;

	Tira();
	Tira(ofxVec2f iniPos);
	
	void move(ofxVec2f target, float ang);
	void render(int lineColor[3], int fillColor[3]);

};

