#include "Particles.h"

Particles::Particles(){
}

Particles::Particles(ofxVec2f iniPos, ofxVec2f iniVel, Perlin *_noise){
	pos = iniPos;
	vel = iniVel;
	acel = 0;
	noise = _noise;
	life = (int)ofRandom(20, 30);
	iniLife = life;
	size = ofRandom(2, 5);
	damp = 0.5;
	G = -ofRandom(3, 6);
	ofxVec3f colorVec = ofxVec3f(0,0,250);
	colorVec.rotate(ofRandom(0, 360), ofRandom(0, 360), 0);
	color[0] = abs((int)colorVec.x);
	color[1] = abs((int)colorVec.y);
	color[2] = abs((int)colorVec.z);
}



void Particles::mover(){
	life--;
	if(life < 0) return;
	
	int step = 2;
	int div = 4000;
	int mult = 5;
	
	ofxVec2f perlinVec;
	float rad = noise->Get(pos.x/div, pos.y/div)*TWO_PI;
	perlinVec.x = cos(rad)*mult;
	perlinVec.y = sin(rad)*mult;
	
	ofxVec2f randomVec;
	randomVec.x = ofRandom(-step, step);
	randomVec.y = ofRandom(-step, step);
	
	vel += perlinVec + randomVec; 
	vel.y += G;
	vel *= damp;
	
	pos += vel;
}

void Particles::render(){
int alpha = 200;

	ofSetColor(color[0], color[1], color[2], alpha*((float)life/iniLife)+50);
	ofCircle(pos.x*Scale2Screen, pos.y*Scale2Screen, size+=0.5);
}






