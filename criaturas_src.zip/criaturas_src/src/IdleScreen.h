#pragma once

#include "ofMain.h"
#include "ofxVec3f.h"
#include "perlin.h"


class IdleScreen{
protected:
	Perlin*noise;
	float alpha, targetAlpha;
	float alphaInterp;
	bool bNewAlpha;
	ofImage* textImg;
	ofImage* tableImg;
	float tableAlpha;
	ofxVec3f colorVec;
	float color[4];
public:
	IdleScreen(Perlin* _noise);
	~IdleScreen();
	
	void update();
	void setAlpha(float _alpha);
	void setAlpha(float _alpha, float _alphaInterp);
	void draw();
};