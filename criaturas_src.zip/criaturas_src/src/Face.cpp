

#include "Face.h"
#include "Criatura.h"

Face::Face(){

}

Face::Face(Criatura *_mae){
	mae = _mae; //"mae" means mother :)
	
	reset();
	
}

Face::~Face(){}

void Face::reset(){
	blinkCountDown = 10;
	blinking = false;
		
	for(int i=0; i<2; i++){
		outerSize[i] = ofRandom(0.8, 1.4);
		innerSize[i] = outerSize[i]-ofRandom(0.1, 0.6);
		gap[i] = ofRandom(0.8, 1.5); 
		innerOffSet[i] = ofRandom(-0.2, 0.2);
	}
	
	acel = 0;
	vel = 0;
	pos = 0;
}

void Face::move(){

	float k = 0.5;
	float damp = 0.4;
	ofPoint& centroid = mae->blob->getCentroid();
	ofxVec2f target = ofxVec2f(centroid.x, centroid.y);
	
	pos = ofxVec2f(centroid.x, centroid.y);
	
	eyePos = (vel/vel.length())/3;
	
	scaleUp = mae->blob->getLength()/30;
	scaleUp = MAX(15, scaleUp);
}

void Face::render(){
	renderOlhos();
}


void Face::renderOlhos(){
	ofFill();
	glPushMatrix();
	glTranslatef((pos.x*Scale2Screen)+vel.x, (pos.y*Scale2Screen)+vel.y, 0);
	glScalef(scaleUp, scaleUp, 0);
	
	//outer circle
	ofSetColor(mae->glowColor[0], mae->glowColor[1], mae->glowColor[2]);
	ofCircle(-gap[0], 0, outerSize[0]);
	ofCircle(gap[1], 0, outerSize[1]);
	if(!blink()){
		//white circle
		ofSetColor(255, 255, 255);
		ofCircle(-gap[0], innerOffSet[0], innerSize[0]);
		ofCircle(gap[1], innerOffSet[1], innerSize[1]);
		//iris
		ofSetColor(10,10,10);
		ofCircle(-gap[0]+eyePos.x, innerOffSet[0]+eyePos.y, 0.3);
		ofCircle(gap[1]+eyePos.x, innerOffSet[1]+eyePos.y, 0.3);
	}
	glPopMatrix();
}



bool Face::blink(){
	if(blinking){
		blinkCountDown --;
		if(blinkCountDown <= 0){
			blinkCountDown = 10;
			blinking = false;
			return false;
		} else return true;
	}
	if(ofRandom(0, 50) < 1){
		blinking = true;
		return true;
	} else{
		return false;
	}
}


