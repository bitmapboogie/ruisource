/*
 *  Corner.cpp
 *  openFrameworks
 *
 *  Created by rui madeira on 6/18/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#include "Corner.h"

Corner::Corner(){
}

Corner::~Corner(){
}

void Corner::setCoords(int _x, int _y){
	x = _x;
	y = _y;
}

bool Corner::mouseOver(int _x, int _y){
	return false;
}

void Corner::draw(){
	ofNoFill();
	ofCircle(x, y, 10);
}






