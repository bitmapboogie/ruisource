#ifndef _TEST_APP
#define _TEST_APP


#include "ofMain.h"
#include "ofxVectorMath.h"
#include "Constants.h"
#include "Particles.h"
#include "ImageWarper.h"
#include "perlin.h"
#include "ofxCvContourFinderToo.h"
#include "ofxCvEasyWarper.h"

#include "Criatura.h"
#include "IdleScreen.h"


class testApp : public ofSimpleApp{
	
public:
	
	void setup();
	void update();
	void draw();
	
	void keyPressed  (int key);
	void mouseMoved(int x, int y );
	void mouseDragged(int x, int y, int button);
	void mousePressed(int x, int y, int button);
	void mouseReleased();
	
	//
	
	int threshold;
	bool full;
	bool showSettings;
	int oldBlobNum;
	
	ofVideoGrabber vid;
	
	ofxCvColorImage frame;
	ofxCvGrayscaleImage grayFrame;
	ofxCvGrayscaleImage smallGrayFrame;
	ofxCvGrayscaleImage smallBackground;
	ofxCvGrayscaleImage warpedImage;
	ofxCvGrayscaleImage difImage;
	
	int imgX, imgY;
	
	int flipMode;
	
	ofxCvContourFinderToo contourFinder;
	
	Criatura *criaturas[MaxBlobs];
	vector <Particles> particles;
	
	Perlin *noise;
	
	ofxCvEasyWarper warper;
	IdleScreen* idleScreen;
	
	
	void copyBackground();
	void showSettingsFunc();
	void manageBlobs();
	
};

#endif
