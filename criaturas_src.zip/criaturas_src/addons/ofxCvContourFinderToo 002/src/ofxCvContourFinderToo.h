#pragma once

#include "ofMain.h"
#include "ofxOpenCv.h"
#include "ofxCvBlobToo.h"

#define DEFAULT_BLOB_FRAME_TOLLERANCE 3

typedef struct{
	float x, y;
} BlobPos;

class ofxCvContourFinderToo{
protected:	
	ofxCvGrayscaleImage *inputCopy;
	CvMemStorage* contourStorage;
	CvMemStorage* storage;
	CvMoments* myMoments;
	vector<CvSeq*> cvSeqBlobs;
	vector<BlobPos> blobPos;
	int oldNumBlobs;
	vector<ofxCvBlobToo> blobs;
	int numBlobs;
	unsigned long totalBlobsFound;
	int blobDeadFramesTollerance;
	virtual void updateBlobs();
	void reset();
	
	//needed to find convexity defects
	CvSeq *seqHull;
	CvSeq *defectsSeq;
	CvConvexityDefect* defectsArray;
	CvMemStorage *hullStorage;
	CvMemStorage *defectsStorage; 	
public:
	
	ofxCvContourFinderToo();
	virtual ~ofxCvContourFinderToo();
	void setTollerance(int _tollerance); // number of frames that a blob has to be missing before removing it
	virtual void findContours(ofxCvGrayscaleImage& img, int minArea, int maxArea, int maxBlobs, bool _holes = true, bool _approx = true);
	virtual void findContoursAndDefects(ofxCvGrayscaleImage& img, int minArea, int maxArea, int maxBlobs, bool _holes = true, bool _approx = true);
	virtual vector<ofPoint> getConvexHull(unsigned int blobIndex);
	virtual vector<ofPoint> getConvexHull(ofxCvBlobToo& theBlob);
	virtual void draw(float x = 0, float y = 0);
	long getTotalBlobsFound();
	int getNumBlobs();
	vector<ofxCvBlobToo>& getBlobs();
	
	//events
	ofEvent<ofxCvBlobToo>addBlob;
	ofEvent<ofxCvBlobToo>removeBlob;
	ofEvent<ofxCvBlobToo>moveBlob;
};
