#pragma once

#include "ofMain.h"
#include "ofxOpenCv.h"

typedef struct{
	ofPoint startPoint, endPoint, depthPoint;
	float depth;
}ofxCvConvexityDefect;

class ofxCvBlobToo: protected ofxCvBlob{
protected:
	bool bNewBlob;
	int screenId;
	unsigned long sessionId;
	ofPoint oldCentroid;
	ofPoint vel;
	unsigned long timeAtCreation;
	unsigned long lifeMillis;
	int frameCounter;
	int deadFrames;
	vector<ofxCvConvexityDefect>defects;
	friend class ofxCvContourFinderToo;
	void update(long _currentTime, int _screenId){
		lifeMillis = _currentTime - timeAtCreation;
		screenId = _screenId;
		frameCounter++;
		vel.x = centroid.x - oldCentroid.x;
		vel.y = centroid.y - oldCentroid.y;
		oldCentroid.x = centroid.x;
		oldCentroid.y = centroid.y;
	}
public:
	ofxCvBlobToo(int _screenId = 0, long _sessionId = 0L, long _timeAtCreation = 0L){
		screenId = _screenId;
		sessionId = _sessionId;
		timeAtCreation = _timeAtCreation;
		frameCounter = 0;
		deadFrames = 0;
	}
	
	~ofxCvBlobToo(){
		defects.clear();	
	}
	
	int getScreenId(){
		return screenId;
	}
	
	unsigned long& getSessionId(){
		return sessionId;
	}
	
	ofPoint getVel() const{
		return vel;
	}
	
	int getNumFrames(){
		return frameCounter;
	}
	
	long getElapsedMillis(){
		return lifeMillis;
	}
	
	int getElapsedSeconds(){
		return (int)(lifeMillis/1000.0f);
	}
	
	vector<ofxCvConvexityDefect>& getDefects(){
		return defects;
	}
	
	int getNumDefects(){
		return defects.size();	
	}
	
	vector<ofPoint>& getPoints(){
		return pts;	
	}
	
	int getNumPoints(){
		return pts.size();	
	}
	
	ofPoint& getCentroid(){
		return centroid;	
	}
	
	float getLength(){
		return length;	
	}
	
	bool isHole(){
		return hole;	
	}
};
