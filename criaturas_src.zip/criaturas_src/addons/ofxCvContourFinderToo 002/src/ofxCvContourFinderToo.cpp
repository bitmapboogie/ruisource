#include "ofxCvContourFinderToo.h"


ofxCvContourFinderToo::ofxCvContourFinderToo(){
	myMoments = (CvMoments*)malloc(sizeof(CvMoments));
	inputCopy = new ofxCvGrayscaleImage();
	//doesn't use opengl texture for multi-threading :)
	inputCopy->setUseTexture(false);
	totalBlobsFound = 0;
	numBlobs = 0;
	oldNumBlobs = 0;
	blobDeadFramesTollerance = DEFAULT_BLOB_FRAME_TOLLERANCE;
}

ofxCvContourFinderToo::~ofxCvContourFinderToo(){
	free(myMoments);
	inputCopy->clear();
	delete inputCopy;
	reset();
}

void ofxCvContourFinderToo::setTollerance(int _tollerance){
	blobDeadFramesTollerance = _tollerance;
}

void ofxCvContourFinderToo::findContours(ofxCvGrayscaleImage& img, int minArea, int maxArea, int maxBlobs, bool _holes, bool _approx){
	IplImage *_iplTemp = img.getCvImage();
	float _width = _iplTemp->width;
	float _height = _iplTemp->height;
	
	//reset
	cvSeqBlobs.clear();
	
	if(inputCopy->width != _width or inputCopy->height != _height){
		inputCopy->clear();
		inputCopy->allocate(_width, _height);
	}
	
	*inputCopy = img;
	
	CvSeq * contourList = NULL;
	contourStorage = cvCreateMemStorage(1000);
	storage = cvCreateMemStorage(1000);
	
	CvContourRetrievalMode retrieveMode = _holes ? CV_RETR_LIST : CV_RETR_EXTERNAL;
	
	cvFindContours(inputCopy->getCvImage(), contourStorage, &contourList,
				   sizeof(CvContour), retrieveMode,
				   _approx ? CV_CHAIN_APPROX_SIMPLE : CV_CHAIN_APPROX_NONE);
	
	CvSeq* contourPtr = contourList;
	while(contourPtr != NULL){
		float area = fabs( cvContourArea(contourPtr, CV_WHOLE_SEQ));
		if(area > minArea and area < maxArea) {
			cvSeqBlobs.push_back(contourPtr);
			
		}
		if(cvSeqBlobs.size() == maxBlobs) break;
		contourPtr = contourPtr->h_next;
	}
	
	numBlobs = cvSeqBlobs.size();
	blobPos.clear();
	blobPos.resize(numBlobs);
	for(int i=0; i<numBlobs; i++){
		cvMoments(cvSeqBlobs[i], myMoments);
		blobPos[i].x = myMoments->m10 / myMoments->m00;
		blobPos[i].y = myMoments->m01 / myMoments->m00;
	}
	
	int blobsDif = numBlobs - blobs.size();
	if(blobsDif != 0){
		if( blobsDif > 0){
			int currentElapsed = ofGetElapsedTimeMillis();
			//add blobs:
			//just add blobs at the end of the array
			for(int i=0; i<blobsDif; i++){
				totalBlobsFound++;
				ofxCvBlobToo theBlob(oldNumBlobs + i, totalBlobsFound, currentElapsed);
				theBlob.bNewBlob = true;
				blobs.push_back(theBlob);
			}
		} else {
			//remove blobs:
			//check the distance between each blob and all cvSeqs,
			//the blob with the biggest distance is assumed to be the one that has
			//disapeared
			float maxDistSQ = 0, distSQ;
			float dx, dy;
			int maxDistBlobID = 0;
			blobsDif = -blobsDif;
			for(int diff=0; diff<blobsDif; diff++){
				for(int i=0; i<blobs.size(); i++){
					for(int j=0; j<cvSeqBlobs.size(); j++){
						dx = blobPos[j].x - blobs[i].centroid.x;
						dy = blobPos[j].y - blobs[i].centroid.y;
						distSQ = dx*dx + dy*dy;
						if(distSQ > maxDistSQ){
							maxDistSQ = distSQ;
							maxDistBlobID = i;
						}
					}
				}
				blobs[maxDistBlobID].deadFrames++;
				if(blobs[maxDistBlobID].deadFrames > blobDeadFramesTollerance){
					ofNotifyEvent(removeBlob, blobs[maxDistBlobID],this);
					blobs.erase(blobs.begin() + maxDistBlobID);
				}
			}
		} 
	} else{
		for(int i=0; i<blobs.size(); i++){
			blobs[i].deadFrames = 0;
		}
	}
	
	int nearestSeqID = 0;
	float dx, dy, distSQ, maxDistSQ;
	
	for(int i=0; i<numBlobs; i++){
		if(blobs[i].deadFrames > 0)continue;
		//check each blob with all available cvSeqs,
		//the nearest cvSeq is assumed to be this blob's new position
		dx = blobPos[0].x - blobs[i].centroid.x;
		dy = blobPos[0].y - blobs[i].centroid.y;
		distSQ = dx*dx + dy*dy;
		maxDistSQ = distSQ;
		nearestSeqID = 0;
		
		for(int j=1; j<cvSeqBlobs.size(); j++){
			dx = blobPos[j].x - blobs[i].centroid.x;
			dy = blobPos[j].y - blobs[i].centroid.y;
			distSQ = dx*dx+dy*dy;
			if(distSQ < maxDistSQ){
				maxDistSQ = distSQ;
				nearestSeqID = j;
			}
		}
		bool bBlobMoved = false;
		CvRect rect = cvBoundingRect(cvSeqBlobs[nearestSeqID], 0);
		blobs[i].boundingRect.x = rect.x;
		blobs[i].boundingRect.y = rect.y;
		float area = cvContourArea(cvSeqBlobs[nearestSeqID], CV_WHOLE_SEQ);
		blobs[i].hole = area > 0;
		blobs[i].area = fabs(area);
		blobs[i].length = cvArcLength(cvSeqBlobs[nearestSeqID]);
		
		blobs[i].boundingRect.width = rect.width;
		blobs[i].boundingRect.height = rect.height;
		if(blobs[i].centroid.x != blobPos[nearestSeqID].x or
		   blobs[i].centroid.y != blobPos[nearestSeqID].y){
			bBlobMoved = true;
		}
		blobs[i].centroid.x = blobPos[nearestSeqID].x;
		blobs[i].centroid.y = blobPos[nearestSeqID].y;
		CvPoint pt;
		CvSeqReader reader;
		cvStartReadSeq(cvSeqBlobs[nearestSeqID], &reader, 0);
		int numPoints = cvSeqBlobs[nearestSeqID]->total;
		int pointsDif = numPoints - blobs[i].pts.size();
		blobs[i].nPts = numPoints;
		blobs[i].pts.resize(numPoints);
		for(int j=0; j< numPoints; j++){
			CV_READ_SEQ_ELEM(pt, reader);
			blobs[i].pts[j].x = pt.x;
			blobs[i].pts[j].y = pt.y;
		}
		
		//after everything is copied into the blob,
		//erase the cvSeq and blobPos, so that it doesn't get assigned twice.
		blobPos.erase(blobPos.begin() + nearestSeqID);
		cvSeqBlobs.erase(cvSeqBlobs.begin() + nearestSeqID);
		if(blobs[i].bNewBlob){
			blobs[i].bNewBlob = false;
			ofNotifyEvent(addBlob, blobs[i], this);
		} else if(bBlobMoved) ofNotifyEvent(moveBlob, blobs[i], this);
	}
	
	oldNumBlobs = numBlobs;
	if(contourStorage != NULL) cvReleaseMemStorage(&contourStorage);
	if(storage != NULL) cvReleaseMemStorage(&storage);	
	updateBlobs();
}

void ofxCvContourFinderToo::findContoursAndDefects(ofxCvGrayscaleImage& img, int minArea, int maxArea, int maxBlobs, bool _holes, bool _approx){
	IplImage *_iplTemp = img.getCvImage();
	float _width = _iplTemp->width;
	float _height = _iplTemp->height;
	
	//reset
	cvSeqBlobs.clear();
	
	if(inputCopy->width != _width or inputCopy->height != _height){
		inputCopy->clear();
		inputCopy->allocate(_width, _height);
	}
	
	*inputCopy = img;
	
	CvSeq * contourList = NULL;
	contourStorage = cvCreateMemStorage(1000);
	storage = cvCreateMemStorage(1000);
	
	hullStorage = cvCreateMemStorage( 1000);
	defectsStorage = cvCreateMemStorage(1000);
	
	CvContourRetrievalMode retrieveMode = _holes ? CV_RETR_LIST : CV_RETR_EXTERNAL;
	
	cvFindContours(inputCopy->getCvImage(), contourStorage, &contourList,
				   sizeof(CvContour), retrieveMode,
				   _approx ? CV_CHAIN_APPROX_SIMPLE : CV_CHAIN_APPROX_NONE);
	
	CvSeq* contourPtr = contourList;
	while(contourPtr != NULL){
		float area = fabs( cvContourArea(contourPtr, CV_WHOLE_SEQ));
		if(area > minArea and area < maxArea) {
			cvSeqBlobs.push_back(contourPtr);
			
		}
		if(cvSeqBlobs.size() == maxBlobs) break;
		contourPtr = contourPtr->h_next;
	}
	
	numBlobs = cvSeqBlobs.size();
	blobPos.clear();
	blobPos.resize(numBlobs);
	for(int i=0; i<numBlobs; i++){
		cvMoments(cvSeqBlobs[i], myMoments);
		blobPos[i].x = myMoments->m10 / myMoments->m00;
		blobPos[i].y = myMoments->m01 / myMoments->m00;
	}
	
	int blobsDif = numBlobs - blobs.size();
	if(blobsDif != 0){
		if( blobsDif > 0){
			int currentElapsed = ofGetElapsedTimeMillis();
			//add blobs:
			//just add blobs at the end of the array
			for(int i=0; i<blobsDif; i++){
				totalBlobsFound++;
				ofxCvBlobToo theBlob(oldNumBlobs + i, totalBlobsFound, currentElapsed);
				theBlob.bNewBlob = true;
				blobs.push_back(theBlob);
			//	ofNotifyEvent(addBlob, theBlob, this);
			}
		} else {
			//remove blobs:
			//check the distance between each blob and all cvSeqs,
			//the blob with the biggest distance is assumed to be the one that has
			//disapeared
			float maxDistSQ = 0, distSQ;
			float dx, dy;
			int maxDistBlobID = 0;
			blobsDif = -blobsDif;
			for(int diff=0; diff<blobsDif; diff++){
				for(int i=0; i<blobs.size(); i++){
					for(int j=0; j<cvSeqBlobs.size(); j++){
						dx = blobPos[j].x - blobs[i].centroid.x;
						dy = blobPos[j].y - blobs[i].centroid.y;
						distSQ = dx*dx + dy*dy;
						if(distSQ > maxDistSQ){
							maxDistSQ = distSQ;
							maxDistBlobID = i;
						}
					}
				}
				blobs[maxDistBlobID].deadFrames++;
				if(blobs[maxDistBlobID].deadFrames > blobDeadFramesTollerance){
					ofNotifyEvent(removeBlob, blobs[maxDistBlobID],this);
					blobs.erase(blobs.begin() + maxDistBlobID);
				}
			}
		} 
	} else{
		for(int i=0; i<blobs.size(); i++){
			blobs[i].deadFrames = 0;
		}
	}
	
	int nearestSeqID = 0;
	float dx, dy, distSQ, maxDistSQ;
	
	for(int i=0; i<numBlobs; i++){
		//check each blob with all available cvSeqs,
		//the nearest cvSeq is assumed to be this blob's new position
		dx = blobPos[0].x - blobs[i].centroid.x;
		dy = blobPos[0].y - blobs[i].centroid.y;
		distSQ = dx*dx + dy*dy;
		maxDistSQ = distSQ;
		nearestSeqID = 0;
		
		for(int j=1; j<cvSeqBlobs.size(); j++){
			dx = blobPos[j].x - blobs[i].centroid.x;
			dy = blobPos[j].y - blobs[i].centroid.y;
			distSQ = dx*dx+dy*dy;
			if(distSQ < maxDistSQ){
				maxDistSQ = distSQ;
				nearestSeqID = j;
			}
		}
		bool bBlobMoved = false;
		CvRect rect = cvBoundingRect(cvSeqBlobs[nearestSeqID], 0);
		blobs[i].boundingRect.x = rect.x;
		blobs[i].boundingRect.y = rect.y;
		float area = cvContourArea(cvSeqBlobs[nearestSeqID], CV_WHOLE_SEQ);
		blobs[i].hole = area > 0;
		blobs[i].area = fabs(area);
		blobs[i].length = cvArcLength(cvSeqBlobs[nearestSeqID]);
		
		blobs[i].boundingRect.width = rect.width;
		blobs[i].boundingRect.height = rect.height;
		if(blobs[i].centroid.x != blobPos[nearestSeqID].x or
		   blobs[i].centroid.y != blobPos[nearestSeqID].y){
			bBlobMoved = true;
		}
		blobs[i].centroid.x = blobPos[nearestSeqID].x;
		blobs[i].centroid.y = blobPos[nearestSeqID].y;
		CvPoint pt;
		CvSeqReader reader;
		cvStartReadSeq(cvSeqBlobs[nearestSeqID], &reader, 0);
		int numPoints = cvSeqBlobs[nearestSeqID]->total;
		//int pointsDif = numPoints - blobs[i].pts.size();
		blobs[i].nPts = numPoints;
		blobs[i].pts.resize(numPoints);
		for(int j=0; j< numPoints; j++){
			CV_READ_SEQ_ELEM(pt, reader);
			blobs[i].pts[j].x = pt.x;
			blobs[i].pts[j].y = pt.y;
		}
		
		seqHull = cvConvexHull2(cvSeqBlobs[nearestSeqID], hullStorage, CV_COUNTER_CLOCKWISE, 0);
		defectsSeq = cvConvexityDefects(cvSeqBlobs[nearestSeqID], seqHull, NULL);
		
		CvConvexityDefect defect;
		cvStartReadSeq(defectsSeq, &reader, 0);
		int numDefects = defectsSeq->total;
		blobs[i].defects.resize(numDefects);
		for(int j=0; j<numDefects; j++){
			CV_READ_SEQ_ELEM(defect, reader);
			pt = *defect.start;
			blobs[i].defects[j].startPoint.x = pt.x;
			blobs[i].defects[j].startPoint.y = pt.y;
			pt = *defect.end;
			blobs[i].defects[j].endPoint.x = pt.x;
			blobs[i].defects[j].endPoint.y = pt.y;
			pt = *defect.depth_point;
			blobs[i].defects[j].depthPoint.x = pt.x;
			blobs[i].defects[j].depthPoint.y = pt.y;
			blobs[i].defects[j].depth = defect.depth;
		}
		
		//after everything is copied into the blob,
		//erase the cvSeq and blobPos, so that it doesn't get assigned twice.
		blobPos.erase(blobPos.begin() + nearestSeqID);
		cvSeqBlobs.erase(cvSeqBlobs.begin() + nearestSeqID);
		if(blobs[i].bNewBlob){
			blobs[i].bNewBlob = false;
			ofNotifyEvent(addBlob, blobs[i], this);
		}else if(bBlobMoved) ofNotifyEvent(moveBlob, blobs[i], this);
	}
	
	oldNumBlobs = numBlobs;
	if(contourStorage != NULL) cvReleaseMemStorage(&contourStorage);
	if(storage != NULL) cvReleaseMemStorage(&storage);	
	
	if(hullStorage != NULL) cvReleaseMemStorage(&hullStorage);
	if(defectsStorage != NULL) cvReleaseMemStorage(&defectsStorage);
	updateBlobs();	
}

vector<ofPoint> ofxCvContourFinderToo::getConvexHull(unsigned int blobIndex){
	if(blobIndex < blobs.size()){
		return getConvexHull(blobs[blobIndex]);
	}
	vector<ofPoint>v;
	return v;
}

vector<ofPoint> ofxCvContourFinderToo::getConvexHull(ofxCvBlobToo& theBlob){
	CvMemStorage* _pointStorage = cvCreateMemStorage(0);
	CvSeqWriter _seqWriter;
	cvStartWriteSeq(CV_32SC2, sizeof(CvSeq), sizeof(CvPoint), _pointStorage, &_seqWriter);
	vector<ofPoint>&points = theBlob.getPoints();
	for(int i=0; i<points.size(); i++){
		CvPoint pt;
		pt.x = points[i].x;
		pt.y = points[i].y;
		CV_WRITE_SEQ_ELEM(pt, _seqWriter);
	}
	CvSeq* _pointsSeq = cvEndWriteSeq(&_seqWriter);
	
	CvMemStorage* _hullStorage = cvCreateMemStorage(0);
	CvSeq* _hullSeq = cvConvexHull2(_pointsSeq, _hullStorage, CV_COUNTER_CLOCKWISE, 0);
	CvPoint* _pt;
	vector<ofPoint>convexHull;
	CvSeqReader _seqReader;
	cvStartReadSeq(_hullSeq, &_seqReader, 0);
	ofPoint _point;
	for(int i=0; i<_hullSeq->total; i++){
		CV_READ_SEQ_ELEM(_pt, _seqReader);
		convexHull.push_back(ofPoint(_pt->x, _pt->y));
	}
	if(_pointStorage)cvReleaseMemStorage(&_pointStorage);
	if(_hullStorage)cvReleaseMemStorage(&_hullStorage);
	return convexHull;
}

void ofxCvContourFinderToo::updateBlobs(){
	long currentTime = ofGetElapsedTimeMillis();
	for(int i=0; i<blobs.size(); i++){
		blobs[i].update(currentTime, i);
	}
}

void ofxCvContourFinderToo::reset(){
	cvSeqBlobs.clear();
	blobs.clear();
	blobPos.clear();
}

void ofxCvContourFinderToo::draw(float x, float y){
	glPushMatrix();
	glTranslatef(x, y, 0.0f);
	for(int i=0; i<blobs.size(); i++){
		glColor3f(0.0f, 1.0f, 0.0f);
		glBegin(GL_LINE_STRIP);
		for(int j=0; j<blobs[i].pts.size(); j++){
			glVertex2f(blobs[i].pts[j].x, blobs[i].pts[j].y);
		}
		glEnd();
		if(blobs[i].defects.size() > 0){
			glColor3f(0.0f, 0.0f, 1.0f);
			for(int j=0; j<blobs[i].defects.size(); j++){
				ofxCvConvexityDefect& defect = blobs[i].defects[j];
				ofCircle(defect.startPoint.x, defect.startPoint.y, 3);
			}
		}
		
		
		glColor3f(1.0f, 0.0f, 0.0f);
		string info;
		info = "Hi, i'm blob " + ofToString((int)blobs[i].getSessionId(), 0) + 
		"\ni've been here for " + ofToString(blobs[i].getElapsedSeconds()) + " seconds";
		ofDrawBitmapString(info, blobs[i].centroid.x, blobs[i].centroid.y);
	}
	glPopMatrix();
}

long ofxCvContourFinderToo::getTotalBlobsFound(){
	return totalBlobsFound;
}

int ofxCvContourFinderToo::getNumBlobs(){
	return blobs.size();
}

vector<ofxCvBlobToo>& ofxCvContourFinderToo::getBlobs(){
	return blobs;
}

