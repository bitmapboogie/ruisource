#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
	ofBackground(0,0,0);
	threshold = 50;
	bCopyBG = true;
	camGrabber.initGrabber(CAM_W, CAM_H);
	camImgColor.allocate(CAM_W, CAM_H);
	camImgGray.allocate(CAM_W, CAM_H);
	bgImg.allocate(CAM_W, CAM_H);
	diffImg.allocate(CAM_W, CAM_H);
	ofAddListener(contourFinder.addBlob, this, &testApp::addBlobEvent);
	ofAddListener(contourFinder.removeBlob, this, &testApp::removeBlobEvent);
	ofAddListener(contourFinder.moveBlob, this, &testApp::moveBlobEvent);
}

//--------------------------------------------------------------
void testApp::update(){
	camGrabber.grabFrame();
	if(camGrabber.isFrameNew()){
		camImgColor.setFromPixels(camGrabber.getPixels(), CAM_W, CAM_H);
		camImgGray = camImgColor;
		if(bCopyBG){
			bCopyBG = false;
			bgImg = camImgGray;
		}
		diffImg.absDiff(bgImg, camImgGray);
		diffImg.threshold(threshold);
		contourFinder.findContoursAndDefects(diffImg, 20, (320*240)/3, 10, true);
	}
	
	
}

//--------------------------------------------------------------
void testApp::draw(){
	glColor3f(1.0f, 1.0f, 1.0f);
	camGrabber.draw(20,20);
	contourFinder.draw(20,20);
}

void testApp::addBlobEvent(ofxCvBlobToo& blob){
	//cout << "blob added" << endl;
}

void testApp::removeBlobEvent(ofxCvBlobToo& blob){
	//cout << "blob removed" << endl;
}

void testApp::moveBlobEvent(ofxCvBlobToo& blob){
	//cout << "blob moved" << endl;
}

//--------------------------------------------------------------
void testApp::keyPressed(int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

