#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
	ofBackground(0,0,0);
	cam.initGrabber(640, 480);
	sourceImg.allocate(640, 480);
	destImg.allocate(640, 480);
	warper.setup(&sourceImg, &destImg);
}

//--------------------------------------------------------------
void testApp::update(){
	cam.grabFrame();
	if(cam.isFrameNew()){
		sourceImg.setFromPixels(cam.getPixels(), 640, 480);
		warper.warp();
	}
}

//--------------------------------------------------------------
void testApp::draw(){
	sourceImg.draw(20, 20);
	warper.draw(20, 20);
	glColor3f(1.0f, 1.0f, 1.0f);
	destImg.draw(20, 550);
	
}

//--------------------------------------------------------------
void testApp::keyPressed(int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){
	if(key == 'l' or key == 'L')warper.load();
	if(key == 's' or key == 'S')warper.save();
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

