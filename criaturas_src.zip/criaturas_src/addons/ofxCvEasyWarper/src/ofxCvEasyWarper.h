#pragma once

#include "ofMain.h"
#include "ofxOpenCv.h"
#include <iostream>
#include <fstream>
#include <string>


#define DEFAULT_FILE_NAME "ofxCvEasyWarper.txt"
#define CORNER_RADIUS 15

class ofxCvEasyWarper{
protected:
	ofxCvImage*sourceImg, *destImg;
	ofPoint imgOffSet;
	int cornerHitId;
	ofPoint sourcePts[4], destPts[4];
	string fileName;
	float imageWidth, imageHeight;
	bool bEventsAdded;
	void onMousePressed(ofMouseEventArgs& mouseArgs);
	void onMouseReleased(ofMouseEventArgs& mouseArgs);
	void onMouseDragged(ofMouseEventArgs& mouseArgs);
	int checkCornerHit(float x, float y);
public:
	ofxCvEasyWarper();
	
	void setup(ofxCvImage*_sourceImg, ofxCvImage*_destImg);
	
	void warp();
	void draw(float x=0, float y=0);
	
	void save();
	void load();
	
	void reset();
	
	//normally you shouldn't have to mess with these.
	//internally it uses mouse events, use this if you want to remove these events
	void removeEvents();
	//use this if after removing the events you wish to add them again
	void addEvents();
	
	//if you want to specify a file name to save the settings
	//otherwise its defaulted to the DEFAULT_FILE_PATH defined above
	void setFileName(string _file);
};



