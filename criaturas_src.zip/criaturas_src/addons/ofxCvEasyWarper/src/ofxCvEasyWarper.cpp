
#include "ofxCvEasyWarper.h"

ofxCvEasyWarper::ofxCvEasyWarper(){
	cornerHitId = -1;
	bEventsAdded = false;
	imageWidth = 0;
	imageHeight = 0;
	addEvents();
	fileName = DEFAULT_FILE_NAME;
}

void ofxCvEasyWarper::setup(ofxCvImage*_sourceImg, ofxCvImage*_destImg){
	sourceImg = _sourceImg;
	destImg = _destImg;
	
	imageWidth = sourceImg->width;
	imageHeight = destImg->height;
	
	reset();
}

void ofxCvEasyWarper::warp(){
	destImg->warpIntoMe(*sourceImg, sourcePts, destPts);
}

void ofxCvEasyWarper::draw(float x, float y){
	imgOffSet.x = x;
	imgOffSet.y = y;
	glPushMatrix();
	glTranslatef(x, y, 0);
	for(int i=0; i<4; i++){
		if(i== cornerHitId)glColor3f(1.0f, 0.0f, 0.0f);
		else glColor3f(0.0f, 1.0f, 0.0f);
		ofCircle(sourcePts[i].x, sourcePts[i].y, CORNER_RADIUS);
	}
	glColor3f(0.0f, 1.0f, 0.0f);
	ofLine(sourcePts[0].x, sourcePts[0].y, sourcePts[1].x, sourcePts[1].y);
	ofLine(sourcePts[1].x, sourcePts[1].y, sourcePts[2].x, sourcePts[2].y);
	ofLine(sourcePts[2].x, sourcePts[2].y, sourcePts[3].x, sourcePts[3].y);
	ofLine(sourcePts[3].x, sourcePts[3].y, sourcePts[0].x, sourcePts[0].y);
	glPopMatrix();
	glColor3f(1.0f, 1.0f, 1.0f);
}

void ofxCvEasyWarper::save(){
	ofstream myFile;
	myFile.open(ofToDataPath(fileName).c_str());
	if(myFile.is_open()){
		for(int i=0; i<4; i++){
			myFile << sourcePts[i].x << endl;
			myFile << sourcePts[i].y << endl;
		}
	}
	myFile.close();
}

void ofxCvEasyWarper::load(){
	ifstream myFile;
	string line;
	myFile.open(ofToDataPath(fileName).c_str());
	if(myFile.is_open()){
		int pointIndex = 0;
		int lineIndex = 0;
		while(!myFile.eof()){
			getline(myFile, line);
			if(lineIndex %2 == 0){
				sourcePts[pointIndex].x = atof(line.c_str());
			} else {
				sourcePts[pointIndex].y = atof(line.c_str());
			}
			lineIndex++;
			pointIndex = (int)(lineIndex*0.5f);
		}
	}
	myFile.close();
}

void ofxCvEasyWarper::reset(){
	sourcePts[0].set(0, 0);
	sourcePts[1].set(imageWidth, 0);
	sourcePts[2].set(imageWidth, imageHeight);
	sourcePts[3].set(0, imageHeight);
	
	for(int i=0; i<4; i++){
		destPts[i].x = sourcePts[i].x;
		destPts[i].y = sourcePts[i].y;
	}
	
}

void ofxCvEasyWarper::onMousePressed(ofMouseEventArgs& mouseArgs){
	cornerHitId = checkCornerHit(mouseArgs.x, mouseArgs.y);
	if(cornerHitId > -1){
		sourcePts[cornerHitId].x = mouseArgs.x - imgOffSet.x;
		sourcePts[cornerHitId].y = mouseArgs.y - imgOffSet.y;
	}
}

void ofxCvEasyWarper::onMouseReleased(ofMouseEventArgs& mouseArgs){
	cornerHitId = -1;
}

void ofxCvEasyWarper::onMouseDragged(ofMouseEventArgs& mouseArgs){
	if(cornerHitId > -1){
		sourcePts[cornerHitId].x = mouseArgs.x - imgOffSet.x;
		sourcePts[cornerHitId].y = mouseArgs.y - imgOffSet.y;
	}
}

void ofxCvEasyWarper::removeEvents(){
	if(bEventsAdded){
		ofRemoveListener(ofEvents.mousePressed, this, &ofxCvEasyWarper::onMousePressed);
		ofRemoveListener(ofEvents.mouseReleased, this, &ofxCvEasyWarper::onMouseReleased);
		ofRemoveListener(ofEvents.mouseDragged, this, &ofxCvEasyWarper::onMouseDragged);
		bEventsAdded = false;
	}
}

void ofxCvEasyWarper::addEvents(){
	if(!bEventsAdded){
		ofAddListener(ofEvents.mousePressed, this, &ofxCvEasyWarper::onMousePressed);
		ofAddListener(ofEvents.mouseReleased, this, &ofxCvEasyWarper::onMouseReleased);
		ofAddListener(ofEvents.mouseDragged, this, &ofxCvEasyWarper::onMouseDragged);
		bEventsAdded = true;
	}
}

int ofxCvEasyWarper::checkCornerHit(float x, float y){
	float dx, dy;
	float cornerRadiusSQ = CORNER_RADIUS*CORNER_RADIUS;
	for(int i=0; i<4; i++){
		dx = x - sourcePts[i].x - imgOffSet.x;
		dy = y - sourcePts[i].y - imgOffSet.y;
		if(dx*dx + dy*dy < cornerRadiusSQ) return i;
	}
	return -1;
}
