#ifndef CONSTANTS_H
#define CONSTANTS_H


#define GRAB_FRAME_SEQUENCE


#ifdef GRAB_FRAME_SEQUENCE

//boids

#define NumBoids 10000
#define NumP 10

//sphere

#define SphereNumLines 100
#define SphereNumRows 100

//particles

#define AddMult 1000


#else

//boids

#define NumBoids 2000

#define NumP 10

//sphere

#define SphereNumLines 100
#define SphereNumRows 100

//particles

#define AddMult 1000

#endif

#define NumBands 1024

#endif


