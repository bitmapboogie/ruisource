/****
 Copyright 2008 Rui Madeira
 
 This file is part of A Whole Lot of Balls.
 
 A Whole Lot of Balls is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 A Whole Lot of Balls is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with A Whole Lot of Balls.  If not, see <http://www.gnu.org/licenses/>.
 *******/


#ifndef IMAGESEQUENCER_H
#define IMAGESEQUENCER_H
#include "ofMain.h"

class SnapShooter{
public:

string fileName;
int frameCounter;
int maxFrames;
bool close;
ofImage img;

float seconds, minutes;

SnapShooter(string _fileName, int _numFrames, bool _close);
~SnapShooter();
void grabFrame();

};




#endif