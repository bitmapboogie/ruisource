/****
 Copyright 2008 Rui Madeira
 
 This file is part of A Whole Lot of Balls.
 
 A Whole Lot of Balls is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 A Whole Lot of Balls is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with A Whole Lot of Balls.  If not, see <http://www.gnu.org/licenses/>.
*******/

#ifndef _TEST_APP
#define _TEST_APP


#include "ofMain.h"

#define OF_ADDON_USING_OFXVECTORMATH

#include "ofAddons.h"
#include "perlin.h"
#include "Constants.h"
#include "Emitter.h"
#ifdef GRAB_FRAME_SEQUENCE
#include "SnapShooter.h"
#endif

#include "Camera.h"
#include "Particles.h"


class testApp : public ofSimpleApp{
	
	public:
		
		void setup();
		void update();
		void draw();
		
		void keyPressed  (int key);
		void keyReleased (int key);
		
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased();
		
		//
		
		bool bFullScreen;

		Camera cam;
		
		Perlin *noise;
		int div;
		
		ofxVec3f center;
		int dist;
		int distSQ;
		
		Emitter emitters[NumEmitters];
		float counter;
		
	
		
		vector <Particles> p;
		
		float averFFT;
			
		bool showInfo;
		bool pause;
		
		ofSoundPlayer music;
		
		#ifdef GRAB_FRAME_SEQUENCE
		SnapShooter *snapShooter;
		float totalFrames;
		#endif
		
		void updateEmitters();
		void updateParticles();
		
};

#endif
	
