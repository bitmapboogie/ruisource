/****
 Copyright 2008 Rui Madeira
 
 This file is part of A Whole Lot of Balls.
 
 A Whole Lot of Balls is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 A Whole Lot of Balls is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with A Whole Lot of Balls.  If not, see <http://www.gnu.org/licenses/>.
*******/

// a lot of this camera class is adapted from the ofCamera class which can be found here:
// http://www.openframeworks.cc/forum/viewtopic.php?t=363&highlight=ofcamera
 
 
 #ifndef CAMERA_H
 #define CAMERA_H

#include "ofMain.h"

#define OF_ADDON_USING_OFXVECTORMATH

#include "ofAddons.h"


class Camera{
private:
	float	fieldOfView;
	float	yon;
	float	hither;
	
	int	w; 
	int	h; 
	float	aspectRatio;
	
	float k, damp;
	
	ofxVec3f acel, vel;
	
public:
	ofxVec3f pos, eye, up;
	ofxVec3f * center;
	float rotY;
	float radius;
	float step;

	Camera();
	~Camera();
	
	void goTo(ofxVec3f target);
	
	void move();
	void lookAt(ofxVec3f _eye);
	
	void place();
	void place(ofxVec3f _pos, ofxVec3f _eye, ofxVec3f _up);
	void place(ofxVec3f _pos, ofxVec3f _eye);
	
	
	
};
#endif

