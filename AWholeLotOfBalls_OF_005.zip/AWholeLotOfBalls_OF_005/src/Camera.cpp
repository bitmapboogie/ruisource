/****
 Copyright 2008 Rui Madeira
 
 This file is part of A Whole Lot of Balls.
 
 A Whole Lot of Balls is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 A Whole Lot of Balls is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with A Whole Lot of Balls.  If not, see <http://www.gnu.org/licenses/>.
*******/

#include "Camera.h"
using namespace std;

Camera::Camera(){
	fieldOfView = 65.0f;
	yon = 10000.0f;
	hither = 0.5f;
	w = glutGet(GLUT_WINDOW_WIDTH);
	h = glutGet(GLUT_WINDOW_HEIGHT);
	aspectRatio = (float)w/(float)h;
	
	k = 0.3;
	damp = 0.3;
	
	vel = 0;
	
	up.x = 0;
	up.y = 1;
	up.z = 0;
		
	eye.x = ofGetWidth()/2;
	eye.y = ofGetHeight()/2;
	eye.z = 0;
	
	radius = 1000;
}

Camera::~Camera(){};

void Camera::goTo(ofxVec3f target){
	acel = (target - pos) * k;
	vel += acel;
	vel *= damp;
	pos += vel;
		
}

void Camera::move(){
	rotY += 0.2;
	radius = 1000;
	ofxVec3f rot = ofxVec3f(0, 0, radius);
	rot.rotate(0, rotY, 0);
	ofxVec3f pos = (*center) + rot;
	goTo(pos);
}

void Camera::lookAt(ofxVec3f _eye){
	eye = _eye;
}

void Camera::place(){
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fieldOfView, aspectRatio, hither, yon);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(pos.x, pos.y, pos.z, eye.x, eye.y, eye.z, up.x, up.y, up.z);
	glScalef(1, -1, 1);
	glTranslatef(0, -h, 0);
}

void Camera::place(ofxVec3f _pos, ofxVec3f _eye, ofxVec3f _up){
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fieldOfView, aspectRatio, hither, yon);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(_pos.x, _pos.y, _pos.z, _eye.x, _eye.y, _eye.z, _up.x, _up.y, _up.z);
	glScalef(1, -1, 1);
	glTranslatef(0, -h, 0);
}

void Camera::place(ofxVec3f _pos, ofxVec3f _eye){
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fieldOfView, aspectRatio, hither, yon);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(_pos.x, _pos.y, _pos.z, _eye.x, _eye.y, _eye.z, 0, 1, 0);
	glScalef(1, -1, 1);
	glTranslatef(0, -h, 0);
}






