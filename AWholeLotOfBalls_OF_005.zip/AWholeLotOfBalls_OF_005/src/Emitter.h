/****
 Copyright 2008 Rui Madeira
 
 This file is part of A Whole Lot of Balls.
 
 A Whole Lot of Balls is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 A Whole Lot of Balls is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with A Whole Lot of Balls.  If not, see <http://www.gnu.org/licenses/>.
 *******/


#ifndef EMITTER_H
#define EMITTER_H


#include "ofMain.h"

#define OF_ADDON_USING_OFXVECTORMATH

#include "ofAddons.h"
#include "perlin.h"
#include "Constants.h"



class Emitter{
public:
	float rotX, rotY, radius, currentRadius;
	int band;
	
	ofxVec3f pos, acel, vel;
	
	Emitter();
	~Emitter();
	
	void updateRadius(float _target);
	void move(ofxVec3f target);
	void render();
};


#endif EMITTER_H