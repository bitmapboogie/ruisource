/****
 Copyright 2008 Rui Madeira
 
 This file is part of A Whole Lot of Balls.
 
 A Whole Lot of Balls is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 A Whole Lot of Balls is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with A Whole Lot of Balls.  If not, see <http://www.gnu.org/licenses/>.
*******/

#ifndef CONSTANTS_H
#define CONSTANTS_H


//#define GRAB_FRAME_SEQUENCE //uncomenting this will save an image of every frame

#define NumBands 1024


//settings for when exporting a frame sequence
#ifdef GRAB_FRAME_SEQUENCE

//boids

#define NumEmitters NumBands

//particles

#define AddMult 300

//Pontos

#define NumP 3

#define ShowTrail // show a trail


//settings for when NOT exporting a frame sequence
#else

//boids

#define NumEmitters NumBands

//particles

#define AddMult 300

//Pontos

#define NumP 3

//#define ShowTrail // uncomenting this will allow a trail for each particle (will slow things down a lot) 

#endif



#endif


