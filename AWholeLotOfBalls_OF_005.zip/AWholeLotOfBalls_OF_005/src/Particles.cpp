/****
 Copyright 2008 Rui Madeira
 
 This file is part of A Whole Lot of Balls.
 
 A Whole Lot of Balls is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 A Whole Lot of Balls is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with A Whole Lot of Balls.  If not, see <http://www.gnu.org/licenses/>.
 *******/

#include "Particles.h"
using namespace std;

Particles::Particles(ofxVec3f iniPos, ofxVec3f _vel, Perlin *_noise){
	pos = iniPos;
	vel = _vel;
	noise = _noise;
	life = (int)ofRandom(20, 50);
	iniLife = life;
	size = ofRandom(4, 8);

	ofxVec3f colorVec = ofxVec3f(0,0,250);
	colorVec.rotate(ofRandom(0, 360), ofRandom(0, 360), 0);

	color[0] = abs((int)colorVec.x);
	color[1] = abs((int)colorVec.y);
	color[2] = abs((int)colorVec.z);
	
	G = -ofRandom(3, 6);
	
	for(int i=0; i<NumP; i++){
		pontos[i] = Ponto(iniPos);
	}
}

Particles::~Particles(){}

void Particles::move(){
float damp = 0.5;
	life--;
	int step = 2;
	int mult = 5;
	int div = 4000;
	
	float radXZ = noise->Get(pos.x/div, pos.z/div)* TWO_PI;
	float radY = noise->Get(pos.x/div, pos.y/div)*TWO_PI;
	
	acel.x = cos(radXZ)*mult+ofRandom(-step, step);
	acel.y = -sin(radY)*mult+ofRandom(-step, step);
	acel.z = sin(radXZ)*mult+ofRandom(-step, step);
	
	vel += acel;
	vel.y += G;
	vel *= damp;
	
	pos += vel;
	
	#ifdef ShowTrail
	moveTrail();
	#endif
}

void Particles::render(){
	float scale =  (float)life/iniLife;
	ofSetColor(color[0],color[1], color[2]);
	ofCircle(pos.x, pos.y, pos.z, size*scale);
	
	#ifdef ShowTrail
	ofSetColor(color[0],color[1], color[2], 40);
	
	renderTrail();
	#endif
	
}

#ifdef ShowTrail
void Particles::moveTrail(){
	pontos[0].pos = pos;
	for(int i=1; i<NumP; i++){
		pontos[i].ang = atan2(pontos[i-1].pos.y - pontos[i].pos.y, pontos[i-1].pos.x + pontos[i].pos.x);
		pontos[i].move(pontos[i-1].pos);
	}
}

void Particles::renderTrail(){
	glBegin(GL_QUAD_STRIP);
	float scale = ((float)life)/iniLife;
	float actualSize = size * scale;
	for(int i=0; i<NumP; i++){
		float normalI = 1-((float)i)/(NumP-1);
		
		float offSetX = cos(pontos[i].ang)*actualSize*normalI;
		float offSetY = sin(pontos[i].ang)*actualSize*normalI; 
		
		glVertex3f(pontos[i].pos.x + offSetX, pontos[i].pos.y + offSetY, pontos[i].pos.z);
		glVertex3f(pontos[i].pos.x - offSetX, pontos[i].pos.y - offSetY, pontos[i].pos.z);
	}
	glEnd();
}

#endif




