/****
 Copyright 2008 Rui Madeira
 
 This file is part of A Whole Lot of Balls.
 
 A Whole Lot of Balls is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 A Whole Lot of Balls is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with A Whole Lot of Balls.  If not, see <http://www.gnu.org/licenses/>.
*******/

#include "testApp.h"
using namespace std;


//--------------------------------------------------------------
void testApp::setup(){	
	ofBackground(220, 220, 240);
	#ifndef GRAB_FRAME_SEQUENCE
	ofSetVerticalSync(true);
	ofSetFrameRate(30);
	#endif
	glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
	glEnable(GL_DEPTH_TEST);
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	
	
	center.x = ofGetWidth()/2;
	center.y = ofGetHeight()/2;
	center.z = 0;
	
	noise = new Perlin(4, 4, 1, time(NULL));
	for(int i=0; i<NumEmitters; i++){
		emitters[i].rotX = ofRandom(0, 360);
		emitters[i].rotY = ofRandom(0, 360);
		emitters[i].band = NumEmitters%NumBands;
	}
	counter = 0;

	pause = false;
	
	music.loadSound("music/music.mp3");
	music.play();
	music.setVolume(1);
	
#ifdef GRAB_FRAME_SEQUENCE
	totalFrames = (float)music.length/music.internalFreq*30;
	snapShooter = new SnapShooter("teste", totalFrames, true);
#endif
	
	
	cam.pos.x = 0;
	cam.pos.y = center.y;
	cam.pos.z = 9000;
	cam.center = &center;
	cam.lookAt(center);
	
	bFullScreen = false;
}

//--------------------------------------------------------------
void testApp::update(){
#ifdef GRAB_FRAME_SEQUENCE
	float playHeadPos = counter/totalFrames;
	music.setPosition(playHeadPos);
#endif


	counter++;
	
	float *fftList = ofSoundGetSpectrum(NumBands);
	
	float totalFFT = 0;
	for(int i=0; i<NumBands; i++){
		totalFFT += fftList[i]*50;
	}
	averFFT = totalFFT / NumBands;
	
	
	//emitters
	updateEmitters();	
	
	//particles
	updateParticles();
}

//--------------------------------------------------------------
void testApp::draw(){
	
	ofxVec3f camPos = ofxVec3f(center.x, center.y, 900);
	
	cam.place(camPos, center);
	
	/*
	for(int i=0; i<NumEmitters; i++){
		emitters[i].render(); //for reference only...
	}*/
	
	for(int i=0; i<p.size(); i++){
		p[i].render();
	}
	
	#ifdef GRAB_FRAME_SEQUENCE
	snapShooter->grabFrame();	
	#endif
}

//--------------------------------------------------------------
void testApp::keyPressed  (int key){ 
	if(key == 'i' or key == 'I') cout << ofGetFrameRate() << endl;
	if(key == 'p' or key == 'P') {
		pause = !pause;
		music.setPaused(pause);
	}
	
	if(key == 'f' or key == 'F') {
		bFullScreen = !bFullScreen;
		ofSetFullscreen(bFullScreen);
		if(bFullScreen) ofHideCursor();
		else ofShowCursor();
	}
	
    
}

//--------------------------------------------------------------
void testApp::keyReleased  (int key){ 
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){
	

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
  }

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
}

//--------------------------------------------------------------
void testApp::mouseReleased(){
}


void testApp::updateEmitters(){
	float *fftList = ofSoundGetSpectrum(NumBands);
	for(int i=0; i<NumEmitters; i++){
		float div = 3000;
		float fftVal = fftList[emitters[i].band] * 50; 
		float targetRadius = averFFT*300+fftVal*10;
		emitters[i].updateRadius(targetRadius);
		ofxVec3f rot = ofxVec3f(0, 0, emitters[i].radius);
		float radRotX = noise->Get(emitters[i].pos.y/div, (emitters[i].pos.z+counter*10)/div)*TWO_PI;
		float radRotY = noise->Get(emitters[i].pos.x/div, (emitters[i].pos.y+counter*10)/div)*TWO_PI;
		int step = 3;
		emitters[i].rotX += cos(radRotX)*(averFFT*50)+ofRandom(-step, step);
		emitters[i].rotY -= sin(radRotY)*(averFFT*50)+ofRandom(-step, step);
		rot.rotate(emitters[i].rotX, emitters[i].rotY, 0);
		ofxVec3f pos = center + rot;
		emitters[i].move(pos);
	}	
}


void testApp::updateParticles(){
	int toAdd =  abs((int)(averFFT*AddMult));

		for(int i=0; i<toAdd; i++){
			int whichEmitter = (int)ofRandom(0, NumEmitters);
			ofxVec3f iniPos = emitters[whichEmitter].pos;
			ofxVec3f iniVel = emitters[whichEmitter].vel*7;
			p.push_back(Particles(iniPos, iniVel, noise));
		}

	
	for(int i=0; i<p.size(); i++){
		if(p[i].life<=0) p.erase(p.begin()+i);
		else{
			p[i].move();
		}
	}
}


