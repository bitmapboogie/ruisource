#include "SkeletonTracking.h"

#include <OpenCV/highgui.h>

static float L0[]={
	-1,-1,-1,-1,-1,
	0, 0, 0, 0, 0,
	2, 2, 2, 2, 2,
	0, 0, 0, 0, 0,
	-1,-1,-1,-1,-1
};
static float L45[]={
	0,-1,-1, 0, 2,
	-1,-1, 0, 2, 0,
	-1, 0, 2, 0,-1,
	0, 2, 0,-1,-1,
	2, 0,-1,-1, 0
};
static float L90[]={
	-1, 0, 2, 0,-1,
	-1, 0, 2, 0,-1,
	-1, 0, 2, 0,-1,
	-1, 0, 2, 0,-1,
	-1, 0, 2, 0,-1
};
static float L135[]={
	2, 0,-1,-1, 0,
	0, 2, 0,-1,-1,
	-1, 0, 2, 0,-1,
	-1,-1, 0, 2, 0,
	0,-1,-1, 0, 2
};

float getMax(float v1, float v2, float v3, float v4){
	float max1 = v1 > v2 ? v1 : v2;
	float max2 = v3 > v4 ? v3 : v4;
	return max1 > max2 ? max1 : max2;
}



SkeletonTracking::SkeletonTracking(){
	int imgW = 640;
	int imgH = 480;
	
	sourceImg.allocate( imgW, imgH );
	sourceImgCopy.allocate( imgW, imgH );
	outImg.allocate( imgW, imgH );
	distSrc.allocate( imgW, imgH );
	s00.allocate( imgW, imgH );
	s45.allocate( imgW, imgH );
	s90.allocate( imgW, imgH );
	s135.allocate( imgW, imgH );
	
	Smax = 0;
	

    cvInitMatHeader(&kern00,5,5,CV_32FC1,L0);
    cvInitMatHeader(&kern45,5,5,CV_32FC1,L45);
    cvInitMatHeader(&kern90,5,5,CV_32FC1,L90);
    cvInitMatHeader(&kern135,5,5,CV_32FC1,L135);
	
	
	threshold = 50;
	skeletonThreshold = 7;
}

SkeletonTracking::~SkeletonTracking(){

}

void SkeletonTracking::update(unsigned char* pixels){
	

	sourceImg.setFromPixels(pixels, 640, 480);
	sourceImgCopy = sourceImg;
	sourceImg.threshold( threshold );
	cvDistTransform(sourceImg.getCvImage(), distSrc.getCvImage() ,CV_DIST_L2,5);
	
    cvFilter2D( distSrc.getCvImage(), s00.getCvImage(), &kern00);
    cvFilter2D( distSrc.getCvImage(), s45.getCvImage(), &kern45);
    cvFilter2D( distSrc.getCvImage(), s90.getCvImage(), &kern90);
    cvFilter2D( distSrc.getCvImage(), s135.getCvImage(), &kern135);
	
	IplImage* out = outImg.getCvImage();
	
	float* outData = (float*)(outImg.getCvImage()->imageData);
	float* s00Data = (float*)(s00.getCvImage()->imageData);
	float* s45Data = (float*)(s45.getCvImage()->imageData);
	float* s90Data = (float*)(s90.getCvImage()->imageData);
	float* s135Data = (float*)(s135.getCvImage()->imageData);
	
	int imageW = distSrc.getWidth();
	int imageH = distSrc.getHeight();
	
	int index;
	for(int x=0; x<imageW; ++x){
		for(int y=0; y<imageH; ++y){
			index = y * imageW + x;
			Smax = getMax( s00Data[index], s45Data[index], s90Data[index], s135Data[index] );
			outData[index] = Smax > 0 ? Smax : 0.0f;
		}
	}
    cvThreshold( out, out, skeletonThreshold, 1, CV_THRESH_BINARY);
	outImg.flagImageChanged();
	
	ofxCvGrayscaleImage grayImg;
	grayImg.allocate( 640, 480 );
	grayImg = outImg;
	contourFinder.findContours( grayImg, 10, 10000000, 10, false, true );
	
	//for(int i=0; i<3; i++) outImg.dilate();
}

void SkeletonTracking::draw(float x, float y){
	sourceImg.draw(x, y, 160, 120 );
	outImg.draw( x + 200, y, 160, 120 );
	contourFinder.draw( x + 200, y, 160, 120 );
}

void SkeletonTracking::drawImages(float x, float y){
	glPushMatrix();
	glTranslatef( x, y, 0.0f );
	
	sourceImg.draw(340, 0, 320, 240);
	s00.flagImageChanged();
	s00.draw(340*2, 0, 320, 240);
	s45.flagImageChanged();
	s45.draw(0, 260, 320, 240);
	s90.flagImageChanged();
	s90.draw(340, 260, 320, 240);
	s135.flagImageChanged();
	s135.draw(340*2, 260, 320, 240);
	outImg.draw(0, 260*2, 320, 240);
	
	glPopMatrix();
}

void SkeletonTracking::drawPointCloud( float x, float y, float w, float h, bool bCenter, float rotX, float rotY ){
	float scaleX = w / outImg.getWidth();
	float scaleY = h / outImg.getHeight();
	
	unsigned char * depthPixels = sourceImgCopy.getPixels();
	float * skeletonPixels = outImg.getPixelsAsFloats();
	int imgW = outImg.getWidth();
	int imgH = outImg.getHeight();
	
	glPushMatrix();
	glTranslatef( x, y, 0.0f );
	glRotatef( rotX, 0.0f, 1.0f, 0.0f );
	glRotatef( rotY, 1.0f, 0.0f, 0.0f );
	glScalef( scaleX, scaleY, 1.0f );
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_POINTS);
	int index;
	if(bCenter){
		float offSetX = (float)imgW/2;
		float offSetY = (float)imgH/2;
		for(int x = 0; x < imgW; x++ ){
			for( int y = 0; y < imgH; ++y){
				index = y * imgW + x;
				if( skeletonPixels[index] > 0.0f ){
					glVertex3f( (float)x - offSetX, (float)y - offSetY, (float)depthPixels[index]*2.0f - 100.0f ); 
				}
			}
		}
	}else{
		for(int x = 0; x < imgW; x++ ){
			for( int y = 0; y < imgH; ++y){
				index = y * imgW + x;
				if( skeletonPixels[index] > 0.0f ){
					glVertex3f( (float)x, (float)y, (float)depthPixels[index] ); 
				}
			}
		}
	}
	glEnd();
	glPopMatrix();
}

void SkeletonTracking::setThreshold( int threshold ){
	this->threshold = threshold;
}

void SkeletonTracking::setSkeletonThreshold( int skeletonThreshold ){
	this->skeletonThreshold = skeletonThreshold;
}

