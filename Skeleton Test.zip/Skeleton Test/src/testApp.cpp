#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
	ofBackground(0, 0, 0);
	kinect.init( true );
	kinect.open();
	kinect.enableDepthNearValueWhite( true );
	
	gui = new GUI( &skeletonTracking );
	
	bSaveFrame = false;

}

//--------------------------------------------------------------
void testApp::update(){
	kinect.update();
	if(kinect.isFrameNew()){
		skeletonTracking.update( kinect.getDepthPixels() );
	}
}

//--------------------------------------------------------------
void testApp::draw(){
	//skeletonTracking.draw( 20, 200 );
	//skeletonTracking.drawPointCloud(ofGetWidth()/2, ofGetHeight()/2, 640, 480, true, gui->rotX, gui->rotY);
	skeletonTracking.drawImages(20, 20);
	
	gui->draw();
	
	if(bSaveFrame){
		ofSaveFrame();
		bSaveFrame = false;
	}
}

//--------------------------------------------------------------
void testApp::keyPressed(int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){
	if( button == 2 ){
		bSaveFrame = true;
	}
}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

