#pragma once

#include "MyGUI.h"
#include "SkeletonTracking.h"
#include "ofMain.h"

class GUI{
public:
	
	GUI(SkeletonTracking* skeletonTracking){
		this->skeletonTracking = skeletonTracking;
		gui = new MyGUI();
		
		MyPanel* settings = new MyPanel( "Settings", 20, 20 );
		gui->addControl( settings );
		
		threshold = 50;
		MySlider* thresholdSlider = new MySlider("Threshold", 10, 30, 200, 20, &threshold, 0, 255 );
		settings->addControl( thresholdSlider );
		ofAddListener( thresholdSlider->drag, this, &GUI::onThresholdSliderDrag );
		
		skeletonThreshold = 7;
		MySlider* skeletonThresholdSlider = new MySlider("Skeleton Threshold", 10, 60, 200, 20, &skeletonThreshold, 0, 100 );
		settings->addControl( skeletonThresholdSlider );
		ofAddListener( skeletonThresholdSlider->drag, this, &GUI::onSkeletonThresholdSliderDrag );
		
		rotX = 0.0f;
		MySlider* rotXSlider = new MySlider("Rot X", 10, 90, 200, 20, &rotX, -180.0f, 180.0f );
		settings->addControl( rotXSlider );
		
		rotY = 0.0f;
		MySlider* rotYSlider = new MySlider("Rot Y", 10, 120, 200, 20, &rotY, -180.0f, 180.0f );
		settings->addControl( rotYSlider );
	}
	
	void draw(){
		gui->draw();
	}
	
	void enable(){
		gui->enable();
	}
	
	void disable(){
		gui->disable();
	}
	
	float rotX, rotY;
	
protected:
	MyGUI* gui;
	SkeletonTracking* skeletonTracking;
	int threshold;
	int skeletonThreshold;
	
	void onThresholdSliderDrag( ControlEventArgs& e ){
		skeletonTracking->setThreshold( threshold );
	}
	
	void onSkeletonThresholdSliderDrag( ControlEventArgs& e ){
		skeletonTracking->setSkeletonThreshold( skeletonThreshold );
	}
};
