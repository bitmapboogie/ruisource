#pragma once

#include "ofxOpenCv.h"

class SkeletonTracking{
public:
	SkeletonTracking();
	~SkeletonTracking();
	void update(unsigned char* pixels);
	void draw(float x, float y);
	void drawPointCloud( float x, float y, float w, float h, bool bCenter = false, float rotX = 0.0f, float rotY = 0.0f );
	void drawImages(float x, float y);
	void setThreshold( int threshold );
	void setSkeletonThreshold( int skeletonThreshold );
protected:
	int threshold;
	int skeletonThreshold;
	ofxCvGrayscaleImage sourceImg;
	ofxCvGrayscaleImage sourceImgCopy;
	ofxCvFloatImage outImg;
	ofxCvFloatImage distSrc;
	ofxCvFloatImage s00;
	ofxCvFloatImage s45;
	ofxCvFloatImage s90;
	ofxCvFloatImage s135;
	
	ofxCvContourFinder contourFinder;
 
	CvMat kern00, kern45, kern90, kern135;
    float Smax;
};
