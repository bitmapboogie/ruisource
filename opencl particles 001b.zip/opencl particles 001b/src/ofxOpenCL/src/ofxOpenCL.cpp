/***********************************************************************
 
 Copyright (c) 2008, 2009, Memo Akten, www.memo.tv
 *** The Mega Super Awesome Visuals Company ***
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of MSA Visuals nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS 
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE. 
 *
 * ***********************************************************************/ 


#include "ofxOpenCL.h"
#include "ofxOpenCLProgram.h"
#include "ofxOpenCLKernel.h"


ofxOpenCL openCL;


ofxOpenCL::ofxOpenCL() {
	ofLog(OF_LOG_VERBOSE, "ofxOpenCL::ofxOpenCL");
	
}

ofxOpenCL::~ofxOpenCL() {
	ofLog(OF_LOG_VERBOSE, "ofxOpenCL::~ofxOpenCL");
	
	clFinish(clQueue);
	
	for(int i=0; i<buffers.size(); i++) clReleaseMemObject(buffers[i]);
	for(map<string, ofxOpenCLKernel*>::iterator it = kernels.begin(); it !=kernels.end(); ++it) delete (ofxOpenCLKernel*)it->second;
	for(int i=0; i<programs.size(); i++) delete programs[i];
	clReleaseCommandQueue(clQueue);
    clReleaseContext(clContext);
}


void ofxOpenCL::setup(int clDeviceType) {
	ofLog(OF_LOG_VERBOSE, "ofxOpenCL::setup " + ofToString(clDeviceType));
	
	cl_int err;
	
    err = clGetDeviceIDs(NULL, clDeviceType, 1, &clDevice, NULL);
    if(err != CL_SUCCESS) {
        ofLog(OF_LOG_ERROR, "Error creating clDevice.");
		assert(false);
    }	
	
	size_t	size;
	err = clGetDeviceInfo(clDevice, CL_DEVICE_VENDOR, sizeof(info.vendorName), info.vendorName, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_NAME, sizeof(info.deviceName), info.deviceName, &size);
	err |= clGetDeviceInfo(clDevice, CL_DRIVER_VERSION, sizeof(info.driverVersion), info.driverVersion, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_VERSION, sizeof(info.deviceVersion), info.deviceVersion, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_MAX_COMPUTE_UNITS, sizeof(info.maxComputeUnits), &info.maxComputeUnits, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS, sizeof(info.maxWorkItemDimensions), &info.maxWorkItemDimensions, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_MAX_WORK_ITEM_SIZES, sizeof(info.maxWorkItemSizes), &info.maxWorkItemSizes, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_MAX_WORK_GROUP_SIZE, sizeof(info.maxWorkGroupSize), &info.maxWorkGroupSize, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_MAX_CLOCK_FREQUENCY, sizeof(info.maxClockFrequency), &info.maxClockFrequency, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_MAX_MEM_ALLOC_SIZE, sizeof(info.maxMemAllocSize), &info.maxMemAllocSize, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_IMAGE_SUPPORT, sizeof(info.imageSupport), &info.imageSupport, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_MAX_READ_IMAGE_ARGS, sizeof(info.maxReadImageArgs), &info.maxReadImageArgs, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_MAX_WRITE_IMAGE_ARGS, sizeof(info.maxWriteImageArgs), &info.maxWriteImageArgs, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_IMAGE2D_MAX_WIDTH, sizeof(info.image2dMaxWidth), &info.image2dMaxWidth, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_IMAGE2D_MAX_HEIGHT, sizeof(info.image2dMaxHeight), &info.image2dMaxHeight, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_IMAGE3D_MAX_WIDTH, sizeof(info.image3dMaxWidth), &info.image3dMaxWidth, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_IMAGE3D_MAX_HEIGHT, sizeof(info.image3dMaxHeight), &info.image3dMaxHeight, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_IMAGE3D_MAX_DEPTH, sizeof(info.image3dMaxDepth), &info.image3dMaxDepth, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_MAX_SAMPLERS, sizeof(info.maxSamplers), &info.maxSamplers, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_MAX_PARAMETER_SIZE, sizeof(info.maxParameterSize), &info.maxParameterSize, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_GLOBAL_MEM_CACHE_SIZE, sizeof(info.globalMemCacheSize), &info.globalMemCacheSize, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(info.globalMemSize), &info.globalMemSize, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_MAX_CONSTANT_BUFFER_SIZE, sizeof(info.maxConstantBufferSize), &info.maxConstantBufferSize, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_MAX_CONSTANT_ARGS, sizeof(info.maxConstantArgs), &info.maxConstantArgs, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_LOCAL_MEM_SIZE, sizeof(info.localMemSize), &info.localMemSize, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_ERROR_CORRECTION_SUPPORT, sizeof(info.errorCorrectionSupport), &info.errorCorrectionSupport, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_PROFILING_TIMER_RESOLUTION, sizeof(info.profilingTimerResolution), &info.profilingTimerResolution, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_ENDIAN_LITTLE, sizeof(info.endianLittle), &info.endianLittle, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_PROFILE, sizeof(info.profile), info.profile, &size);
	err |= clGetDeviceInfo(clDevice, CL_DEVICE_EXTENSIONS, sizeof(info.extensions), info.extensions, &size);
	
	if(err != CL_SUCCESS) {
        ofLog(OF_LOG_ERROR, "Error getting clDevice information.");
		assert(false);
    }
	
	ofLog(OF_LOG_VERBOSE, string("\n\n*********\nofxOpenCL Device information:") + 
		  "\n vendorName.................." + string((char*)info.vendorName) + 
		  "\n deviceName.................." + string((char*)info.deviceName) + 
		  "\n driverVersion..............." + string((char*)info.driverVersion) +
		  "\n deviceVersion..............." + string((char*)info.deviceVersion) +
		  "\n maxComputeUnits............." + ofToString(info.maxComputeUnits, 0) +
		  "\n maxWorkItemDimensions......." + ofToString(info.maxWorkItemDimensions, 0) +
		  "\n maxWorkItemSizes[0]........." + ofToString(info.maxWorkItemSizes[0], 0) + 
		  "\n maxWorkGroupSize............" + ofToString(info.maxWorkGroupSize, 0) +
		  "\n maxClockFrequency..........." + ofToString(info.maxClockFrequency, 0) +
		  "\n maxMemAllocSize............." + ofToString(info.maxMemAllocSize/1024.0f/1024.0f, 3) + " MB" + 
		  "\n imageSupport................" + ofToString(info.imageSupport, 0) +
		  "\n maxReadImageArgs............" + ofToString(info.maxReadImageArgs, 0) +
		  "\n maxWriteImageArgs..........." + ofToString(info.maxWriteImageArgs, 0) +
		  "\n image2dMaxWidth............." + ofToString(info.image2dMaxWidth, 0) +
		  "\n image2dMaxHeight............" + ofToString(info.image2dMaxHeight, 0) +
		  "\n image3dMaxWidth............." + ofToString(info.image3dMaxWidth, 0) +
		  "\n image3dMaxHeight............" + ofToString(info.image3dMaxHeight, 0) +
		  "\n image3dMaxDepth............." + ofToString(info.image3dMaxDepth, 0) +
		  "\n maxSamplers................." + ofToString(info.maxSamplers, 0) +
		  "\n maxParameterSize............" + ofToString(info.maxParameterSize, 0) +
		  "\n globalMemCacheSize.........." + ofToString(info.globalMemCacheSize/1024.0f/1024.0f, 3) + " MB" + 
		  "\n globalMemSize..............." + ofToString(info.globalMemSize/1024.0f/1024.0f, 3) + " MB" +
		  "\n maxConstantBufferSize......." + ofToString(info.maxConstantBufferSize/1024.0f, 3) + " KB"
		  "\n maxConstantArgs............." + ofToString(info.maxConstantArgs, 0) +
		  "\n localMemSize................" + ofToString(info.localMemSize/1024.0f, 3) + " KB"
		  "\n errorCorrectionSupport......" + ofToString(info.errorCorrectionSupport, 0) +
		  "\n profilingTimerResolution...." + ofToString(info.profilingTimerResolution, 0) +
		  "\n endianLittle................" + ofToString(info.endianLittle, 0) +
		  "\n profile....................." + string((char*)info.profile) +
		  "\n extensions.................." + string((char*)info.extensions) +
		  "\n*********\n\n");
	
	clContext = clCreateContext(0, 1, &clDevice, NULL, NULL, &err);
    if(clContext == NULL) {
        ofLog(OF_LOG_ERROR, "Error creating clContext.");
		assert(false);
    }
	
	clQueue = clCreateCommandQueue(clContext, clDevice, 0, NULL);
    if(clQueue == NULL) {
        ofLog(OF_LOG_ERROR, "Error creating command queue.");
		assert(false);
    }
	
}	

ofxOpenCLProgram* ofxOpenCL::loadProgramFromFile(string filename) { 
	ofLog(OF_LOG_VERBOSE, "ofxOpenCL::loadProgramFromFile");
	ofxOpenCLProgram *p = new ofxOpenCLProgram(this);
	p->loadFromFile(filename);
	programs.push_back(p);
	return p;
}


ofxOpenCLProgram* ofxOpenCL::loadProgramFromSource(string source) {
	ofLog(OF_LOG_VERBOSE, "ofxOpenCL::loadProgram");
	ofxOpenCLProgram *p = new ofxOpenCLProgram(this);
	p->loadFromSource(source);
	programs.push_back(p);
	return p;
} 


ofxOpenCLKernel* ofxOpenCL::loadKernel(string kernelName, ofxOpenCLProgram *program) {
	ofLog(OF_LOG_VERBOSE, "ofxOpenCL::loadKernel " + kernelName + ", " + ofToString((int)program));
	if(program == NULL) program = programs[programs.size() - 1];
	ofxOpenCLKernel *k = program->loadKernel(kernelName);
	kernels[kernelName] = k;
	return k;
}


cl_mem ofxOpenCL::createBuffer(int numberOfBytes, cl_mem_flags memFlags, void *data, bool blockingWrite) {
	cl_mem clBuffer = clCreateBuffer(clContext, memFlags, numberOfBytes, NULL, NULL);
	
	if(data) {
		//cl_int err = clEnqueueWriteBuffer(clQueue, clBuffer, blockingWrite, 0, numberOfBytes, (void*)data, 0, NULL, NULL);
		//assert(err == CL_SUCCESS);
		writeBuffer(numberOfBytes, clBuffer, data, blockingWrite);
		
	}
	
	buffers.push_back(clBuffer);
	return clBuffer;
}

void ofxOpenCL::writeBuffer(int numberOfBytes, cl_mem clBuffer, void *data, bool blockingWrite){
	cl_int err = clEnqueueWriteBuffer(clQueue, clBuffer, blockingWrite, 0, numberOfBytes, (void*)data, 0, NULL, NULL);
	assert(err == CL_SUCCESS);
}

void ofxOpenCL::readBuffer(int numberOfBytes, cl_mem clBuffer, void *data, bool blockingRead) {
	cl_int err = clEnqueueReadBuffer(clQueue, clBuffer, blockingRead, 0, numberOfBytes, (void*)data, 0, NULL, NULL);
	assert(err == CL_SUCCESS);
}


ofxOpenCLKernel* ofxOpenCL::kernel(string kernelName) {
	return kernels[kernelName];
}

void ofxOpenCL::flush() {
	clFlush(clQueue);
}


void ofxOpenCL::finish() {
	clFinish(clQueue);
}