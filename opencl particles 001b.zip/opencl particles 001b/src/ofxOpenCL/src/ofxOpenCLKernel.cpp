/***********************************************************************
 
 Copyright (c) 2008, 2009, Memo Akten, www.memo.tv
 *** The Mega Super Awesome Visuals Company ***
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of MSA Visuals nor the names of its contributors 
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS 
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE. 
 *
 * ***********************************************************************/ 


#include "ofxOpenCL.h"
#include "ofxOpenCLKernel.h"


ofxOpenCLKernel::ofxOpenCLKernel(ofxOpenCL* pOpenCL, cl_kernel clKernel, string name) {
	ofLog(OF_LOG_VERBOSE, "ofxOpenCLKernel::ofxOpenCLKernel " + ofToString((int)pOpenCL) + ", " + name);
	this->pOpenCL	= pOpenCL;
	this->name		= name;
	this->clKernel	= clKernel;
}


ofxOpenCLKernel::~ofxOpenCLKernel() {
	ofLog(OF_LOG_VERBOSE, "ofxOpenCLKernel::~ofxOpenCLKernel " + name);
	clReleaseKernel(clKernel);
}

/*
void ofxOpenCLKernel::setArg(int argNumber, cl_mem clMem) {
	ofLog(OF_LOG_VERBOSE, "ofxOpenCLKernel::setArg " + name + ": " + ofToString(argNumber));	
	
	assert(clKernel);
	
	cl_int err  = clSetKernelArg(clKernel, argNumber, sizeof(cl_mem), &clMem);
	assert(err == CL_SUCCESS);
}*/

void ofxOpenCLKernel::run(int numDimensions, int _globalSize, int _localSize) {
	assert(clKernel);
	
	cl_int err;
	
	size_t globalSize = _globalSize;
	size_t localSize = _localSize;
//	size_t localSize = MIN(n, info.maxWorkGroupSize);

	if(localSize) {
		err = clEnqueueNDRangeKernel(pOpenCL->clQueue, clKernel, numDimensions, NULL, &globalSize, &localSize, 0, NULL, NULL);
	} else {
		err = clEnqueueNDRangeKernel(pOpenCL->clQueue, clKernel, numDimensions, NULL, &globalSize, NULL, 0, NULL, NULL);
	}
	assert(err == CL_SUCCESS);
}

cl_kernel& ofxOpenCLKernel::getCLKernel(){
	return clKernel;
}
