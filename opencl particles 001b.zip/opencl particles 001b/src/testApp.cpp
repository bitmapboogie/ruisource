#include "testApp.h"
#include "ofxOpenCL.h"


//--------------------------------------------------------------
void testApp::setup(){
	ofBackground(0, 0, 0);

	opencl.setup(CL_DEVICE_TYPE_ALL);
	
	numParticles = NUM_PARTICLES;
	
	float w = ofGetWidth();
	float h = ofGetHeight();
	
	particles = new Particle[numParticles];
	for(int i=0; i<numParticles; i++){
		initParticle(particles[i]);
	}
	
	clProgram = opencl.loadProgramFromFile("MyProgram.cl");
	kernelUpdate = opencl.loadKernel("updateParticle", clProgram);
	int numBytes = sizeof(Particle) * numParticles;
	particlesIn = opencl.createBuffer(numBytes, CL_MEM_READ_WRITE, particles);
	particlesOut = opencl.createBuffer(numBytes, CL_MEM_WRITE_ONLY, particles);
	
	mousePosX = mouseX;
	mousePosY = mouseY;
	kernelUpdate->setArg(0, particlesIn);
	kernelUpdate->setArg(1, particlesOut);
	kernelUpdate->setArg(2, numParticles);
	kernelUpdate->setArg(3, mousePosX);
	kernelUpdate->setArg(4, mousePosY);
}

//--------------------------------------------------------------
void testApp::update(){
	mousePosX = mouseX;
	mousePosY = mouseY;
	kernelUpdate->setArg(3, mousePosX);
	kernelUpdate->setArg(4, mousePosY);
	int numBytes = sizeof(Particle) * numParticles;
	kernelUpdate->run(1, numParticles);
	opencl.readBuffer(numBytes, particlesOut, particles);
}

//--------------------------------------------------------------
void testApp::draw(){
	glPointSize(3);
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_POINTS);
	for(int i=0; i<numParticles; i++){
		glVertex2f(particles[i].pos.x, particles[i].pos.y);
	}
	glEnd();
	string info = "fps: " + ofToString(ofGetFrameRate()) + "\nnumber of particles: " + ofToString(numParticles);
	ofDrawBitmapString(info, 20, 20);
}

//--------------------------------------------------------------
void testApp::exit() {
	opencl.finish();
}

//--------------------------------------------------------------
void testApp::keyPressed(int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){
	
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

