#pragma once
#include "ofMain.h"

#define SCREEN_W 1280.0f
#define SCREEN_H 720.0f

typedef struct {
	float x, y;
} Vec2;

typedef struct{
	Vec2 pos, accel, vel;
	float mass;
	float radius;
} Particle;

static void initParticle(Particle& p, float velX = 0.0f, float velY = 0.0f, float radius = 10.0f){
	p.pos.x = ofRandom(0, SCREEN_W);
	p.pos.y = ofRandom(0, SCREEN_H);
	p.vel.x = velX;
	p.vel.y = velY;
	p.accel.x = p.accel.y = 0.0f;
	p.radius = radius;
	p.mass = radius * 0.1f;
}