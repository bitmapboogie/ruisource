#pragma once

#include "ofxPerlin.h"
#include "ofxPhysics3d.h"

class ParticleContainerBase{
public:
	ParticleContainerBase(ofxPerlin* perlin){
		this->perlin = perlin;
		physics = new ofxPhysics3d();
	}
	
	virtual ~ParticleContainerBase(){
		physics->removeAll();
		delete physics;
	}
	virtual void update() = 0;
	virtual void draw(){debugDraw();}
	virtual void debugDraw(){}
protected:
	ofxPerlin* perlin;
	ofxPhysics3d* physics;
};