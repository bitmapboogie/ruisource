#pragma once

#include <string>

#include "ofxPerlin.h"
#include "ParticleManager.h"
#include "FossileParticleManager.h"
#include "OrbManager.h"
#include "ParticleToOrbInteraction.h"
#include "BlobManager.h"
#include "DustManager.h"
#include "ofxTileSaver.h"

class WrittenImages{
public:
	
	WrittenImages(ofxPerlin* perlin);
	virtual ~WrittenImages();
	void update(int numIterations);
	void tickUpdate();
	void draw();
	
	bool hasSavedImage();
	
protected:
	bool bHasSavedImage;
	ofxPerlin* perlin;
	ParticleManager* particleManager;
	FossileParticleManager* fossileParticleManager;
	OrbManager* orbManager;
	ParticleToOrbInteraction* particleToOrbInteraction;
	BlobManager* blobManager;
	DustManager* dustManager;
	ofxTileSaver* tileSaver;
};