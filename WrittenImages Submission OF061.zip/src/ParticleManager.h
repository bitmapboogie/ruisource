#pragma once

#include "ParticleContainerBase.h"
#include "ofxPhysics3d.h"
#include "ofxNoise.h"
#include "CompoundParticle.h"
#include "Orb.h"
#include "Blob.h"

class ParticleManager: public ParticleContainerBase{
public:
	ParticleManager(ofxPerlin* perlin, int numParticles);
	virtual ~ParticleManager();
	void update();
	void drawFill();
	void drawOutline();
	void drawMixed();
	vector<CompoundParticle*>& getParticles();
	
protected:
	vector<CompoundParticle*> particles;
	void constrain(const ofPoint& min, const ofPoint& max);
};