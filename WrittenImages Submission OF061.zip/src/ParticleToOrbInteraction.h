#pragma once

#include "Particle.h"
#include "Orb.h"
#include "ofxPerlin.h"

class ParticleToOrbInteraction{
public:
	
	ParticleToOrbInteraction(ofxPerlin* perlin){
		this->perlin = perlin;
		vecToCross.set(0.0f, -1.0f, 0.0f);
	}
	
	void update(vector<Particle*>& particles, vector<Orb*>& orbs){
		if(particles.size() == 0) return;
		float counter = (float)ofGetFrameNum() * 0.01f;
		float rotX = perlin->noise(vecToCross.x * 0.01f, vecToCross.y * 0.01f, counter);
		float rotY = perlin->noise(vecToCross.y * 0.01f, vecToCross.z * 0.01f, counter);
		vecToCross.rotate(rotX, rotY, 0.0f);
		
		for(vector<Particle*>::iterator partIt = particles.begin(); partIt != particles.end(); ++partIt){
			Particle& particle = **partIt;
			Orb* orb = particle.getNearestOrb(orbs);
			particle.setTarget(*orb);
			particle.applyRepulsionForce(*orb, orb->getRadius() * 0.1f);
			
			ofxVec3f crossVec = particle - *orb;
			crossVec.cross(vecToCross);
			crossVec.normalize();
			crossVec *= orb->getRadius() * 0.1f;
			particle.applyForce(crossVec);
		}
		
		
		if(particles.size() < 2) return;
		vector<Particle*>::iterator endIt = particles.end();
		--endIt;
		
		float minContactDist = 2;
		float minContactDistSQ = minContactDist*minContactDist;
		for(vector<Particle*>::iterator itA = particles.begin(); itA != endIt; ++itA){
			vector<Particle*>::iterator itB = itA;
			++itB;
			
			Particle& partA = **itA;
			for(; itB != particles.end(); ++itB){
				Particle& partB = **itB;
				
				float distSQ = partA.distanceToSquared(*itB);
				if(distSQ < minContactDistSQ){
					partA.applyRepulsionForce(partB, 10.0f);
					partB.applyRepulsionForce(partA, 10.0f);
				}
				
			}
		}
	}
	
	void update(vector<CompoundParticle*>& particles, vector<Orb*>& orbs){
		float counter = (float)ofGetFrameNum() * 0.01f;
		float rotX = perlin->noise(vecToCross.x * 0.01f, vecToCross.y * 0.01f, counter);
		float rotY = perlin->noise(vecToCross.y * 0.01f, vecToCross.z * 0.01f, counter);
		vecToCross.rotate(rotX, rotY, 0.0f);
		
		for(vector<CompoundParticle*>::iterator partIt = particles.begin(); partIt != particles.end(); ++partIt){
			Particle& particle = **partIt;
			Orb* orb = particle.getNearestOrb(orbs);
			particle.setTarget(*orb);
			particle.applyRepulsionForce(*orb, orb->getRadius() * 0.1f);
			
			ofxVec3f crossVec = particle - *orb;
			crossVec.cross(vecToCross);
			crossVec.normalize();
			crossVec *= orb->getRadius() * 0.5f;
			particle.applyForce(crossVec);
		}
		
		vector<CompoundParticle*>::iterator endIt = particles.end();
		--endIt;
		
		float minContactDist = 2;
		float minContactDistSQ = minContactDist*minContactDist;
		for(vector<CompoundParticle*>::iterator itA = particles.begin(); itA != endIt; ++itA){
			vector<CompoundParticle*>::iterator itB = itA;
			++itB;
			
			Particle& partA = **itA;
			for(; itB != particles.end(); ++itB){
				Particle& partB = **itB;
				
				float distSQ = partA.distanceToSquared(*itB);
				if(distSQ < minContactDistSQ){
					partA.applyRepulsionForce(partB, 10.0f);
					partB.applyRepulsionForce(partA, 10.0f);
				}
				
			}
		}
	}
	
	
protected:
	ofxPerlin* perlin;
	ofxVec3f vecToCross;
};