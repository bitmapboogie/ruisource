#include "WrittenImages.h"

WrittenImages::WrittenImages(ofxPerlin* perlin){
	this->perlin = perlin;
	bHasSavedImage = false;
	particleManager = new ParticleManager(perlin, 15);
	fossileParticleManager = new FossileParticleManager(perlin, 100);
	orbManager = new OrbManager(perlin, 10);
	particleToOrbInteraction = new ParticleToOrbInteraction(perlin);
	blobManager = new BlobManager((int)ofRandom(3, 5));
	dustManager = new DustManager();
	tileSaver = new ofxTileSaver();
	tileSaver->init(4, 0, true);
}

WrittenImages::~WrittenImages(){
	delete particleManager;
	delete fossileParticleManager;
	delete orbManager;
	delete particleToOrbInteraction;
	delete blobManager;
	delete dustManager;
}

void WrittenImages::update(int numIterations){
	while(numIterations--){
		tickUpdate();
	}
}

void WrittenImages::tickUpdate(){
	fossileParticleManager->update();
	particleManager->update();
	orbManager->update();
	dustManager->update();
	dustManager->createDust(particleManager->getParticles());
	particleToOrbInteraction->update(particleManager->getParticles(), orbManager->getOrbs()); 
	particleToOrbInteraction->update(fossileParticleManager->getParticles(), orbManager->getOrbs());
}

void WrittenImages::draw(){
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glColor3f(1.0f, 1.0f, 1.0f);
	ofRect(0.0f, 0.0f, ofGetWidth(), ofGetHeight());
	blobManager->draw();
	
	fossileParticleManager->drawOutline();

	glPushMatrix();
	glTranslatef(0.0f, 0.0f, 200.0f);
	
	particleManager->drawFill();
	particleManager->drawOutline();
	particleManager->drawMixed();
	
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	dustManager->draw();
	
	glPopMatrix();
	
	
	//orbManager->debugDraw();
}



bool WrittenImages::hasSavedImage(){
	return bHasSavedImage;
}
