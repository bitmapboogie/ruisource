#include "ParticleManager.h"


ParticleManager::ParticleManager(ofxPerlin* perlin, int numParticles): ParticleContainerBase(perlin){
	ofPoint origin(ofRandomWidth(), ofRandomHeight());
	while(numParticles--){
		if(ofRandomuf() < 0.05f){
			origin.set(ofRandomWidth(), ofRandomHeight());
		}
		float pathWidth = ofRandom(1.0f, 20.0f);
		CompoundParticle* p = new CompoundParticle(perlin, origin, -1, -1, pathWidth);
		float randomStep = 10.0f;
		ofPoint force(ofRandom(-randomStep, randomStep), ofRandom(-randomStep, randomStep), ofRandom(-randomStep, randomStep));
		p->applyForce(force);
		
		particles.push_back(p);
		physics->add(p);
	}
}

ParticleManager::~ParticleManager(){
	for(vector<CompoundParticle*>::iterator it = particles.begin(); it != particles.end(); ++it){
		delete *it;
	}
	particles.clear();
}

void ParticleManager::update(){
	physics->update(0.1f);
	ofColor fillColor, outlineColor;
	for(vector<CompoundParticle*>::iterator it = particles.begin(); it != particles.end(); ++it){
		CompoundParticle& p = **it;
		if(!p.hasFinishedPath()){
			float noiseVal = perlin->noiseuf(p.x*0.1f, p.y*0.1f, p.z*0.1f);
			fillColor.r = fillColor.g = fillColor.b = noiseVal * 0.5f;
			outlineColor.r = outlineColor.g = outlineColor.b = 1.0f;
			outlineColor.a = 0.2f;
			p.update(fillColor, outlineColor, noiseVal);	
		}
	}
	ofPoint min(0.0f, 0.0f, -1000.0f);
	ofPoint max(ofGetWidth(), ofGetHeight(), 0.0f);
	constrain(min, max);
}

void ParticleManager::drawFill(){
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	for(vector<CompoundParticle*>::iterator it = particles.begin(); it != particles.end(); ++it){
		(*it)->drawFill();
	}
}

void ParticleManager::drawOutline(){
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	for(vector<CompoundParticle*>::iterator it = particles.begin(); it != particles.end(); ++it){
		(*it)->drawOutline();
	}
}

void ParticleManager::drawMixed(){
	for(vector<CompoundParticle*>::iterator it = particles.begin(); it != particles.end(); ++it){
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		(*it)->drawFill();
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		(*it)->drawOutline();
	}
}

vector<CompoundParticle*>& ParticleManager::getParticles(){
	return particles;
}

void ParticleManager::constrain(const ofPoint& min, const ofPoint& max){
	float repulsion = 10.0f;
	for(vector<CompoundParticle*>::iterator it = particles.begin(); it != particles.end(); ++it){
		CompoundParticle& part = **it;
		if(part.x < min.x){
			ofPoint force(repulsion, 0.0f);
			part.applyForce(force);
		} else if(part.x > max.x){
			ofPoint force(-repulsion, 0.0f);
			part.applyForce(force);
		}
		if(part.y < min.y){
			ofPoint force(0.0f, repulsion);
			part.applyForce(force);
		} else if(part.y > max.y){
			ofPoint force(0.0f, -repulsion);
			part.applyForce(force);
		}
		if(part.z < min.z){
			ofPoint force(0.0f, 0.0f, repulsion);
			part.applyForce(force);
		}else if(part.z > max.z){
			ofPoint force(0.0f, 0.0f, -repulsion);
			part.applyForce(force);
		}
	}
}
