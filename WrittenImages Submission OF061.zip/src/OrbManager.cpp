#include "OrbManager.h"

OrbManager::OrbManager(ofxPerlin* perlin, int numOrbs):ParticleContainerBase(perlin){
	//physics->enableCollisions(true);
	while(numOrbs--){
		ofPoint pos(ofRandomWidth(), ofRandomHeight(), ofRandom(0.0f, -1000.0f));
		Orb* orb = new Orb(perlin, pos);
		orbs.push_back(orb);
		physics->add(orb);
	}
}

OrbManager::~OrbManager(){
	for(vector<Orb*>::iterator it = orbs.begin(); it != orbs.end(); ++it){
		delete *it;
	}
	orbs.clear();
}

void OrbManager::update(){
	physics->update(0.2f);
	for(vector<Orb*>::iterator it = orbs.begin(); it != orbs.end(); ++it){
		(*it)->update();
	}
	
	ofPoint min(0.0f, 0.0f, -0.0f);
	ofPoint max(ofGetWidth(), ofGetHeight(), 500.0f);
	constrain(min, max);
}

void OrbManager::draw(){
	debugDraw();
}

void OrbManager::debugDraw(){
	glColor3f(1.0f, 0.0f, 0.0f);
	for(vector<Orb*>::iterator it = orbs.begin(); it != orbs.end(); ++it){
		(*it)->debugDraw();
	}
}

vector<Orb*>& OrbManager::getOrbs(){
	return orbs;
}

void OrbManager::constrain(const ofPoint& min, const ofPoint& max){
	float repulsion = 10.0f;
	for(vector<Orb*>::iterator it = orbs.begin(); it != orbs.end(); ++it){
		Orb& orb = **it;
		if(orb.x < min.x){
			ofPoint force(repulsion, 0.0f);
			orb.applyForce(force);
		} else if(orb.x > max.x){
			ofPoint force(-repulsion, 0.0f);
			orb.applyForce(force);
		}
		if(orb.y < min.y){
			ofPoint force(0.0f, repulsion);
			orb.applyForce(force);
		} else if(orb.y > max.y){
			ofPoint force(0.0f, -repulsion);
			orb.applyForce(force);
		}
		if(orb.z < min.z){
			ofPoint force(0.0f, 0.0f, repulsion);
			orb.applyForce(force);
		}else if(orb.z > max.z){
			ofPoint force(0.0f, 0.0f, -repulsion);
			orb.applyForce(force);
		}
	}
}