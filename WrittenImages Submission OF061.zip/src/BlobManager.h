#pragma once

#include "Blob.h"

class BlobManager{
public:
	BlobManager(int numBlobs){
		while(numBlobs--){
			ofPoint pos(ofRandomWidth(), ofRandomHeight());
			ofColor inColor;
			inColor.r = inColor.g = inColor.b = 0.7f;
			inColor.a = 1.0f;
			ofColor outColor;
			outColor.r = outColor.g = outColor.b = 0.3f;
			outColor.a = 0.0f;
			Blob* blob = new Blob(pos, inColor, outColor, ofRandom(300, 500));
			blobs.push_back(blob);
		}
	}
	
	virtual ~BlobManager(){
		for(vector<Blob*>::iterator it = blobs.begin(); it != blobs.end(); ++it){
			delete *it;
		}
		blobs.clear();
	}
	
	void draw(){
		for(vector<Blob*>::iterator it = blobs.begin(); it != blobs.end(); ++it){
			(*it)->draw(); 
		}
	}
protected:
	vector<Blob*> blobs;
};