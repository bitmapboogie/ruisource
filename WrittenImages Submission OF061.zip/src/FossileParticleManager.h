#pragma once

class FossileParticleManager: public ParticleManager{
public:
	FossileParticleManager(ofxPerlin* perlin, int numParticles):ParticleManager(perlin, numParticles){
		ofPoint origin(ofRandomWidth(), ofRandomHeight());
		while(numParticles--){
			if(ofRandomuf() < 0.1f){
				origin.set(ofRandomWidth(), ofRandomHeight());
			}
			CompoundParticle* p = new CompoundParticle(perlin, origin, -1, (int)ofRandom(50, 200), ofRandom(10.0f, 30.0f));
			float randomStep = 10.0f;
			ofPoint force(ofRandom(-randomStep, randomStep), ofRandom(-randomStep, randomStep), ofRandom(-randomStep, randomStep));
			p->applyForce(force);
			
			particles.push_back(p);
			physics->add(p);
		}
	}
	
	void update(){
		physics->update(0.1f);
		ofColor fillColor, outlineColor;
		for(vector<CompoundParticle*>::iterator it = particles.begin(); it != particles.end(); ++it){
			CompoundParticle& p = **it;
			if(!p.hasFinishedPath()){
				float noiseVal = perlin->noiseuf(p.x*0.1f, p.y*0.1f, p.z*0.1f);
				fillColor.r = fillColor.g = fillColor.b = noiseVal * 0.5f;
				outlineColor.r = outlineColor.g = outlineColor.b = 1.0f;
				outlineColor.a = 0.1f;
				p.update(fillColor, outlineColor, noiseVal);	
			}
		}
		ofPoint min(0.0f, 0.0f, -1000.0f);
		ofPoint max(ofGetWidth(), ofGetHeight(), 0.0f);
		constrain(min, max);
	}
	
	void drawOutline(){
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		for(vector<CompoundParticle*>::iterator it = particles.begin(); it != particles.end(); ++it){
			(*it)->drawOutline();
		}
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}
};