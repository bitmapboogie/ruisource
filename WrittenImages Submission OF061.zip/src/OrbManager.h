#pragma once

#include "ParticleContainerBase.h"
#include "Orb.h"

class OrbManager:public ParticleContainerBase{
public:
	
	OrbManager(ofxPerlin* perlin, int numOrbs);
	virtual ~OrbManager();
	void update();
	void draw();
	void debugDraw();
	vector<Orb*>& getOrbs();
protected:
	vector<Orb*>orbs;
	void constrain(const ofPoint& min, const ofPoint& max);
};