#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
	ofBackground(255,255,255);
	ofSetVerticalSync(true);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glDisable(GL_DEPTH_TEST);
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glEnable(GL_LINE_SMOOTH);
	
	perlin = new ofxPerlin();
	writtenImages = new WrittenImages(perlin);
	
	saver.init(NUM_TILES, 0, true);
}

//--------------------------------------------------------------
void testApp::update(){
#ifdef TEST_MODE
	writtenImages->tickUpdate();
#else
	if(ofGetFrameNum() % TILES_WAIT == 0){
		int pathIndex = floorf(ofGetFrameNum() / TILES_WAIT);
		if(pathIndex >= paths.size()) OF_EXIT_APP(0);
		saver.finish(paths[pathIndex], false);
		saver.cleanUp();
		delete writtenImages;
		writtenImages = new WrittenImages(perlin);
		int numIterations = 1000;
		writtenImages->update(numIterations);
	}
#endif
}

//--------------------------------------------------------------
void testApp::draw(){
#ifdef TEST_MODE
	writtenImages->draw();
#else
	saver.begin();
	writtenImages->draw();
	saver.end();
#endif

}

//--------------------------------------------------------------
void testApp::keyPressed(int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

