#pragma once

class DustParticle: public ofxParticle{
public:
	DustParticle(const ofPoint& pos, float radius):ofxParticle(pos, radius){
		origin = pos;
		setDrag(0.97f);
		float offSetStep = radius * 0.1f;
		offSet.set(ofRandom(-offSetStep, offSetStep), ofRandom(-offSetStep, offSetStep));
		insideRatio = ofRandom(0.5f, 0.8f);
		gray = ofRandom(0.8f, 0.95f);
	}
	void draw(){
		/*float angle = 0.0f;
		float angleAdd = TWO_PI / 99;
		glBegin(GL_TRIANGLE_FAN);
		glColor4f(gray, gray, gray, 1.0f);
		glVertex3f(x, y, z);
		glColor4f(gray, gray, gray, 0.0f);
		for(int i=0; i<100; ++i){
			glVertex3f(cosf(angle) * radius + x, sinf(angle) * radius + y, z);
			angle += angleAdd;
		}
		glEnd();*/
		
		glColor4f(gray, gray, gray, gray);
		ofNoFill();
		glPushMatrix();
		glTranslatef(x, y, z);
		ofCircle(0.0f, 0.0f, radius);
		glPopMatrix();
		ofFill();
		
		ofxVec3f diff = *this - origin;
		lineBegin = *this - diff.rescaled(radius);
		lineEnd = lineBegin - (diff * 0.1f);
		glBegin(GL_LINES);
		glVertex3f(lineBegin.x, lineBegin.y, lineBegin.z);
		glVertex3f(lineEnd.x, lineEnd.y, lineEnd.z);
		glEnd();
		
	}
protected:
	float insideRatio;
	ofPoint origin;
	ofPoint offSet;
	ofxVec3f lineBegin, lineEnd;
	float gray;
};