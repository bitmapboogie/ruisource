#include "ofMain.h"
#include "testApp.h"
#include "ofAppGlutWindow.h"

int main(int argc, char **argv){
	
    ofAppGlutWindow window;
	ofSetupOpenGL(&window, 4080/4,2720/4, OF_WINDOW);	//<- don't change the image size
	
	testApp* app = new testApp();
	for(int i=1;i<argc; i++){
		app->paths.push_back(argv[i]);
	}
	
	if(argc==1){ // debug files
		for(int i=0; i<4; ++i){
			string path = "debug_img" + ofToString(i) + ".png";
			app->paths.push_back(path);
		}
		
	}
	
	ofRunApp(app);
}
