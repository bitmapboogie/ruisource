#pragma once

#include "Particle.h"

class CompoundParticle: public Particle{
public:
	
	CompoundParticle(ofxPerlin* perlin, const ofPoint& pos, int numParticles = -1, int pathSize = -1, float pathWidth = 3):Particle(perlin, pos, pathSize, pathWidth){
		if(numParticles < 0) numParticles = (int)ofRandom(1, 4);
		while(numParticles--){
			Particle* p = new Particle(perlin, pos, -1, pathWidth);
			p->setDrag(0.99f);
			particles.push_back(p);
		}
	}
	
	virtual ~CompoundParticle(){
		for(vector<Particle*>::iterator it = particles.begin(); it != particles.end(); ++it){
			delete *it;
		}
		particles.clear();
	}
	
	void update(const ofColor& fillColor, const ofColor& outlineColor, float widthMult){
		float noiseRes = 0.01f;
		float noiseMul = 7.0;
		float randomStep = 5.0f;
		float counter = (float)ofGetFrameNum() * 0.01f;
		
		float radXZ = perlin->noise(x * noiseRes, z * noiseRes, counter) * TWO_PI;
		float radY = perlin->noise(x * noiseRes, y * noiseRes, counter) * TWO_PI;
		ofPoint noiseForce;
		noiseForce.x = cosf(radXZ) * noiseMul + ofRandom(-randomStep, randomStep);
		noiseForce.y = -sinf(radY) * noiseMul + ofRandom(-randomStep, randomStep);
		noiseForce.z = sinf(radXZ) * noiseMul + ofRandom(-randomStep, randomStep);
		applyForce(noiseForce);
		
		Particle::update(ofColor(), ofColor(), 1.0f);
		ofPoint target;
		randomStep = 1.0f;
		for(vector<Particle*>::iterator it = particles.begin(); it != particles.end(); ++it){
			Particle& p = **it;
			target = *this;
			target.x += ofRandom(-randomStep, randomStep);
			target.y += ofRandom(-randomStep, randomStep);
			target.z += ofRandom(-randomStep, randomStep);
			p.setTarget(target);
			p.update(fillColor, outlineColor, widthMult);
			p.updateParticle();
		}
	}
	
	void drawFill(){
		for(vector<Particle*>::iterator it = particles.begin(); it != particles.end(); ++it){
			(*it)->drawFill();
		}
	}
	
	void drawOutline(){
		for(vector<Particle*>::iterator it = particles.begin(); it != particles.end(); ++it){
			(*it)->drawOutline();
		}
	}
	
	vector<Particle*> getParticles(){
		return particles;
	}
	
protected:
	ofColor col;
	vector<Particle*> particles;
};