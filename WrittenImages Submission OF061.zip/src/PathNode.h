#pragma once

#include "ofMain.h"
#include "ofxVec3f.h"

class PathNode: public ofPoint{
public:
	PathNode(const ofPoint& pos, float width, const ofColor& fillColor, const ofColor& outlineColor): ofPoint(pos){
		this->width = width;
		this->fillColor = fillColor;
		this->outlineColor = outlineColor;
	}
	
	void calcRibbonVertices(const ofPoint& nextNode, const ofxVec3f& vecToCross = ofxVec3f(0.0f, 0.0f, 1.0f)){
		ofxVec3f diff = nextNode - *this;
		diff.cross(vecToCross);
		diff.normalize();
		diff *= width;
		vertA = *this + diff;
		vertB = *this - diff;
	}
	
	ofColor& getFillColor(){
		return fillColor;
	}
	
	ofColor& getOutlineColor(){
		return outlineColor;
	}
	
	void renderRibbonVertices(){
		glVertex3f(vertA.x, vertA.y, vertA.z * 0.5f);
		glVertex3f(vertB.x, vertB.y, vertB.z * 0.5f);
	}
	
	ofPoint& getVertA(){
		return vertA;
	}
	ofPoint& getVertB(){
		return vertB;
	}
	
protected:
	float width;
	ofColor fillColor;
	ofColor outlineColor;
	ofPoint vertA, vertB;
};
