#pragma once

#include "ParticleContainerBase.h"
#include "ofxPhysics3d.h"
#include "DustParticle.h"

class DustManager: public ParticleContainerBase{
public:
	
	DustManager():ParticleContainerBase(NULL){
		
	}
	
	virtual ~DustManager(){
		for(vector<DustParticle*>::iterator it = particles.begin(); it != particles.end(); ++it){
			delete *it;
		}
		particles.clear();
	}
	
	void createDust(vector<CompoundParticle*>& particles){
		float randomStep = 2.0f;
		for(vector<CompoundParticle*>::iterator it = particles.begin(); it != particles.end(); ++it){
			CompoundParticle& p = **it;
			if(p.hasFinishedPath()) continue;
			if(ofRandomuf() < 0.03f){
				DustParticle* dust = new DustParticle(p, ofRandom(1.0f, 5.0f));
				physics->add(dust);
				ofPoint vel = p.getVel();
				vel.x += ofRandom(-randomStep, randomStep);
				vel.y += ofRandom(-randomStep, randomStep);
				vel.z += ofRandom(-randomStep, randomStep);
				dust->applyForce(vel);
				this->particles.push_back(dust);
			}
		}
	}
	void update(){
		physics->update(0.5f);
	}
	
	void draw(){
		for(vector<DustParticle*>::iterator it = particles.begin(); it != particles.end(); ++it){
			(*it)->draw();
		}
	}
	vector<DustParticle*>& getParticles(){
		return particles;
	}
protected:
	vector<DustParticle*> particles;
};