#pragma once

#include "ofMain.h"

class Blob: public ofPoint{
public:
	
	static const int RESOLUTION = 300;
	
	Blob(const ofPoint& pos, const ofColor& inColor, const ofColor& outColor, float radius):ofPoint(pos){
		this->inColor = inColor;
		this->outColor = outColor;
		this->radius = radius;
		insideRatio = ofRandom(0.5f, 0.9f);
		float offSetStep = radius * 0.1f;
		offSet.set(ofRandom(-offSetStep, offSetStep), ofRandom(-offSetStep, offSetStep));
	}
	
	void draw(){
		float angle = 0.0f;
		float angleAdd = TWO_PI / (RESOLUTION-1);
		glBegin(GL_TRIANGLE_FAN);
		glColor4f(inColor.r, inColor.g, inColor.b, inColor.a);
		glVertex3f(x, y, z);
		glColor4f(outColor.r, outColor.g, outColor.b, outColor.a);
		for(int i=0; i<RESOLUTION; ++i){
			glVertex3f(x + cosf(angle) * radius, y + sinf(angle) * radius, z);
			angle += angleAdd;
		}
		glEnd();
	}
	
protected:
	float radius;
	float insideRatio;
	ofPoint offSet;
	ofColor inColor, outColor;
};