#pragma once

#include "ofxParticle.h"
#include "PathNode.h"
#include "ofxPerlin.h"

class Orb;

class Particle: public ofxParticle{
public:
	Particle(ofxPerlin* perlin, const ofPoint& pos, int pathSize = -1, float pathWidth = 3.0f);
	virtual ~Particle();
	virtual void update(const ofColor& fillColor, const ofColor& outlineColor, float width);
	void setTarget(const ofPoint& target);
	bool isInTarget();
	virtual void drawFill();
	virtual void drawOutline();
	Orb* getNearestOrb(const vector<Orb*>& orbs);
	
	vector<PathNode>& getPath();
	
	bool hasFinishedPath();
	
protected:
	ofxPerlin* perlin;
	ofPoint target;
	int life;
	vector<PathNode> path;
	int pathSize;
	float pathWidth;
	Orb* targetOrb;
};
