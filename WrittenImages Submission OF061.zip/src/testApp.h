#ifndef _TEST_APP
#define _TEST_APP


//#define TEST_MODE

#define NUM_TILES 4
#define TILES_WAIT 100


#include "ofMain.h"
#include "WrittenImages.h"
#include "ofxPerlin.h"
#include "ofxTileSaver.h"

class testApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed  (int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void windowResized(int w, int h);
	
	ofxPerlin* perlin;
	WrittenImages* writtenImages;
	vector<string>paths;
	
	ofxTileSaver saver;

};

#endif
