#pragma once

#include "ofxPerlin.h"
#include "Particle.h"

class Orb: public Particle{
public:
	
	Orb(ofxPerlin* perlin, const ofPoint& pos):Particle(perlin, pos){
		setRadius(ofRandom(20, 100));
		setDrag(0.98f);
		radiusSQ = radius*radius;
		center = ofPoint(ofGetWidth()/2.0f, ofGetHeight()/2.0f, 0.0f);
	}
	
	void update(){
		ofPoint force = (center - *this)*0.001f;
		applyForce(force);
		
		float randomStep = 1.2f;
		ofPoint noiseForce;
		noiseForce.x = ofRandom(-randomStep, randomStep);
		noiseForce.y = ofRandom(-randomStep, randomStep);
		noiseForce.z = ofRandom(-randomStep, randomStep);
		applyForce(noiseForce);
	}
	
	void applyRepulsion(Particle* p, float amount = 1.0f){
		ofPoint force = *this - *p;
		ofxVec3f crossVec(force.z, force.y, force.x);
		crossVec.normalize();
		crossVec *= 10.0f;
		force *= 0.01f;
		p->applyForce(force);
		p->applyForce(crossVec);
		p->applyRepulsionForce(*this, amount);
	}
	
	void applyRepulsion(vector<Particle*>& particles, float amount = 1.0f){
		for(vector<Particle*>::iterator it = particles.begin(); it != particles.end(); ++it){
			applyRepulsion(*it);
		}
	}	
	
	void draw(){
		glPushMatrix();
		glTranslatef(x, y, z);
		ofCircle(0.0f, 0.0f, 20.0f);
		glPopMatrix();
	}
						
	void debugDraw(){
		glPushMatrix();
		glTranslatef(x, y, z);
		ofCircle(0.0f, 0.0f, 10);
		glPopMatrix();
	}
	
protected:
	float radiusSQ;
	ofPoint center;
};