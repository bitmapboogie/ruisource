#include "Particle.h"
#include "Orb.h"

Particle::Particle(ofxPerlin* perlin, const ofPoint& pos, int pathSize, float pathWidth): ofxParticle(pos, 1){
	this->perlin = perlin;
	this->targetOrb = targetOrb;
	this->pathWidth = pathWidth;
	setRadius(1.0f);
	setDrag(0.95f);
	target = pos;
	life = 0;
	if(pathSize < 0) pathSize = (int)ofRandom(100.0f, 1000.0f);
	this->pathSize = pathSize;
	path.reserve(pathSize + 1);
}

Particle::~Particle(){
	path.clear();
}

void Particle::update(const ofColor& fillColor, const ofColor& outlineColor, float widthMult){
	ofPoint force = target - *this;
	force *= 0.1f;
	applyForce(force);
	
	if(life < pathSize){
		//float width = widthMult*pathWidth;
		ofxVec3f forces = getForces();
		float width = pathWidth * forces.length();
		ofColor _fillColor;
		_fillColor.r = _fillColor.g = _fillColor.b = width * 0.1f;
		path.push_back(PathNode(*this, width, fillColor, outlineColor));
	}
	
	++life;
}

void Particle::setTarget(const ofPoint& target){
	this->target = target;
}

bool Particle::isInTarget(){
	float dx = target.x - x;
	float dy = target.y - y;
	float dz = target.z - z;
	return dx*dx+dy*dy+dz*dz < 1.0f;
}

void Particle::drawFill(){
	if(path.size() < 2) return;
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	vector<PathNode>::iterator itA = path.begin();
	vector<PathNode>::iterator itB = itA;
	++itB;
	glBegin(GL_QUAD_STRIP);
	for(; itB != path.end(); ++itA, ++itB){
		PathNode& nodeA = *itA;
		PathNode& nodeB = *itB;
		nodeA.calcRibbonVertices(nodeB);
		ofColor& fillColor = nodeA.getFillColor();
		glColor4f(fillColor.r, fillColor.g, fillColor.b, fillColor.a);
		nodeA.renderRibbonVertices();
	}
	
	glEnd();
}

void Particle::drawOutline(){
	if(path.size() < 2) return;
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	vector<PathNode>::iterator itA = path.begin();
	vector<PathNode>::iterator itB = itA;
	++itB;
	glBegin(GL_QUAD_STRIP);
	for(; itB != path.end(); ++itA, ++itB){
		PathNode& nodeA = *itA;
		PathNode& nodeB = *itB;
		nodeA.calcRibbonVertices(nodeB);
		ofColor& outlineColor = nodeA.getOutlineColor();
		glColor4f(outlineColor.r, outlineColor.g, outlineColor.b, outlineColor.a);
		nodeA.renderRibbonVertices();
	}
	
	glEnd();
}

Orb* Particle::getNearestOrb(const vector<Orb*>& orbs){
	int numOrbs = orbs.size();
	if(numOrbs == 0) return NULL;
	if(numOrbs == 1) return orbs.front();
	vector<Orb*>::const_iterator it = orbs.begin();
	float currDistSQ, minDistSQ;
	currDistSQ = minDistSQ = distanceToSquared(*it);
	Orb* result = *it;
	for(++it; it != orbs.end(); ++it){
		Orb* orb = *it;
		currDistSQ = distanceToSquared(orb);
		if(currDistSQ < minDistSQ){
			result = orb;
			minDistSQ = currDistSQ;
		}
	}
	return result;
}

vector<PathNode>& Particle::getPath(){
	return path;
}

bool Particle::hasFinishedPath(){
	return life > pathSize;
}
