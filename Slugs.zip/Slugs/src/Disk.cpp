/*****
 Copyright 2008 Rui Madeira
 
 This file is part of Slugs.
 
 Slugs is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Foobar is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Slugs.  If not, see <http://www.gnu.org/licenses/>.
 *****/

#include "Disk.h"

Disk::Disk(ofxVec3f iniPos, float _radius ){
	center = iniPos;
	radius = _radius;
	for(int i=0; i<NUMP; i++){
		float angle = (float)i/(NUMP-1)*TWO_PI;
		float x = center.x;
		float y = center.y + sin(angle)*radius;
		float z = center.z + cos(angle)*radius;
		p[i].set(x, y, z);
		contourP[i].set(x, y, z);
	}
	
	accel = 0;
	vel = 0;
}

void Disk::move(ofxVec3f target, float rotX, float rotY){
	float k = 0.8;
	float damp = 0.4;
	
	accel = (target - center) * k;
	vel += accel;
	vel *= damp;
	center += vel;
	
	
	rotX *= RAD_TO_DEG;
	rotY *= RAD_TO_DEG;
	
	for(int i=0; i<NUMP; i++){
		float angle = (float)i/(NUMP-1)*TWO_PI;
		float x = 0;
		float y = sin(angle)*radius;
		float z = cos(angle)*radius;
		p[i].set(x, y, z);
		p[i].rotate(rotX, rotY, 0.0f);
		p[i] += center;
		
		float strokeGap = 0.01f;
		y = sin(angle)*(radius+strokeGap);
		z = cos(angle)*(radius+strokeGap);
		contourP[i].set(x, y, z);
		contourP[i].rotate(rotX, rotY, 0.0f);
		contourP[i] += center;

	}
}

