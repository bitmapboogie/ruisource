/*****
 Copyright 2008 Rui Madeira
 
 This file is part of Slugs.
 
 Slugs is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Foobar is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Slugs.  If not, see <http://www.gnu.org/licenses/>.
 *****/

#include "FrameGrabber.h"


FrameGrabber::FrameGrabber(string _fileName, int _numFrames, bool _close){
	fileName = _fileName; 
	maxFrames = _numFrames;
	close = _close;
	frameCounter = 0;
	minutes = seconds = 0;
}

void FrameGrabber::grabFrame(){
	frameCounter++;
	if(frameCounter <= maxFrames){
		string file = fileName + ofToString(frameCounter, 0) + ".png";
		img.grabScreen(0,0,ofGetWidth(), ofGetHeight());
		img.saveImage(file);
		float elapsedTime = ofGetElapsedTimef();
		seconds = (int)elapsedTime%60;
		minutes = (int)(elapsedTime/60);
		
		string ellapsed = " elapsed: " + ofToString(minutes, 0) + "min "+ ofToString(seconds, 0) + "sec\n";
		std::cout << ofToString(frameCounter, 0) + " of " + ofToString(maxFrames, 0) + " frames " + 
		"at " + ofToString(ofGetFrameRate(),2) + "fps" + ellapsed;
	} else if(close)OF_EXIT_APP(0);
}
