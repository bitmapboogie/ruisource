/*****
 Copyright 2008 Rui Madeira
 
 This file is part of Slugs.
 
 Slugs is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Foobar is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Slugs.  If not, see <http://www.gnu.org/licenses/>.
 *****/

#pragma once

#include "ofMain.h"

class FrameGrabber{
public:
string fileName;
int frameCounter;
int maxFrames;
bool close;
ofImage img;

float seconds, minutes;

FrameGrabber(string _fileName, int _numFrames, bool _close);
void grabFrame();

};