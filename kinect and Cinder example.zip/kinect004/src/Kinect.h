#pragma once

#include "cinder/Cinder.h"

extern "C" {
	
	class Kinect{
	public:
		Kinect();
		~Kinect();
		
		bool hasInited() const{
			return bInited;
		}
		
		uint8_t * getColorPixels();
		uint16_t* getDepthPixels();

		
	protected:
		bool bInited;
	};
	
}