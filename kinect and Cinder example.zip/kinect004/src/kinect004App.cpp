#include "cinder/app/AppBasic.h"
#include "cinder/gl/gl.h"
#include "cinder/gl/Texture.h"
#include "cinder/Surface.h"
#include "cinder/ImageIo.h"
#include "cinder/Utilities.h"

#include "Kinect.h"

using namespace ci;
using namespace ci::app;
using namespace std;


class kinect004App : public AppBasic {
  public:
	void prepareSettings( Settings* settings);
	void setup();
	void mouseUp( MouseEvent event );
	void update();
	void draw();
	
	Kinect kinect;
	gl::Texture texture;
	uint8_t* buf;
	uint8_t* colorRange;
	
};

void kinect004App::prepareSettings(Settings* settings){
	settings->setWindowSize(1024, 768);
}

void kinect004App::setup(){
	texture = gl::Texture( 640, 480 );
	buf = new uint8_t[640*480]; 
	colorRange = new uint8_t[2048];
	for(int i=0; i<2048; ++i){
		float norm = (float)i / 2048.0f;
		colorRange[i] = 256.0f - norm*norm * 256.0f;
	}
}

void kinect004App::mouseUp( MouseEvent event ){
	string path = getSaveFilePath( getHomeDirectory());
	if(path.size()){
		writeImage( path, copyWindowSurface( getWindowBounds() ) );
	}
}

void kinect004App::update()
{	
	uint16_t* depthBuffer = kinect.getDepthPixels();
	
	int index = 0;
	for(int i=0; i<640; ++i){
		for(int j=0; j<480; ++j){
			buf[index] = colorRange[ depthBuffer[index] ];
			++index;
		}
	}
	
	texture.update( Channel8u(640, 480, 640, 1, buf), Area(0, 0, 640, 480) );
}

void kinect004App::draw()
{
	// clear out the window with black
	gl::clear( Color( 0, 0, 0 ) ); 
	gl::setMatricesWindow( getWindowWidth(), getWindowHeight() );
	gl::draw( texture, getWindowBounds() );
}


CINDER_APP_BASIC( kinect004App, RendererGl )
