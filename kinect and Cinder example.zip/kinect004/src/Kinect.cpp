

extern "C" {
#include <libusb.h>
#include "libfreenect.h"
}

#include "Kinect.h"

libusb_device_handle* dev;
int threadHandle;
pthread_t thread;
pthread_mutex_t mutex;
bool bRunUpdate;
uint8_t* colorPixels;
uint16_t* depthPixels;



void depthImageCB(uint16_t *buf, int width, int height){
	pthread_mutex_lock(&mutex);
	memcpy(depthPixels, buf, width * height * 2);
	pthread_mutex_unlock(&mutex);
}

void colorImageCB(uint8_t *buf, int width, int height){
	pthread_mutex_lock(&mutex);
	memcpy(colorPixels, buf, width * height * 3);
	pthread_mutex_unlock(&mutex);
}

void *threadedFunc( void *arg){
	while(bRunUpdate && libusb_handle_events( NULL ) == 0);
	pthread_exit(NULL);
	return NULL;
}

Kinect::Kinect(){
	colorPixels = new uint8_t[640*480*3];
	depthPixels = new uint16_t[640*480];
	
	libusb_init( NULL );
	dev = libusb_open_device_with_vid_pid( NULL, 0x45e, 0x2ae);
	libusb_claim_interface(dev, 0);
	bInited = dev != NULL;
	if(!bInited){
		printf("computer says noooo...\n");
		return;
	}
	cams_init(dev, depthImageCB, colorImageCB);
	
	bRunUpdate = true;
	threadHandle = pthread_create(&thread, NULL, threadedFunc, NULL);
}

Kinect::~Kinect(){
	bRunUpdate = false;
	delete[] colorPixels;
	delete[] depthPixels;
}

//are these locks necessary?
unsigned char* Kinect::getColorPixels(){
	pthread_mutex_lock(&mutex);
	return colorPixels;
	pthread_mutex_unlock(&mutex);
}

uint16_t* Kinect::getDepthPixels(){
	pthread_mutex_lock(&mutex);
	return depthPixels;
	pthread_mutex_unlock(&mutex);
}
