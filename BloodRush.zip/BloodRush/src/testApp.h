/*****
 Copyright 2008 Rui Madeira
 
 This file is part of Blood Rush.
 
 Blood Rush is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Blood Rush is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Blood Rush.  If not, see <http://www.gnu.org/licenses/>.
 ****/

#ifndef _TEST_APP
#define _TEST_APP

#include "ofMain.h"
#include "ofAddons.h"
#include "Boid.h"
//using a perlin noise class created by John Ratcliff which can be found here:
// http://www.flipcode.com/archives/Perlin_Noise_Class.shtml
#include "Perlin.h"
#include "Camera.h"
#include "Particles.h"

class testApp : public ofSimpleApp{
	
	public:
		
		void setup();
		void update();
		void draw();
		
		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased();
		
		//
		
		Perlin *noise;
		Boid *boid[numBoids];
		
		vector <Particles> particles;

		GLint maxParticles;
		int frameCounter;
		
		Camera cam;
		GLint camDist;
		
		bool depthTest;
		
		float averX, averY, averZ;
		
		bool full;
		
		#ifdef SAVE_IMAGE_SEQUENCE
		ofImage img;
		bool takeSnapShot;
		#endif
};

#endif
	
