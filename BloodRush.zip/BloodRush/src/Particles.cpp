/*****
 Copyright 2008 Rui Madeira
 
 This file is part of Blood Rush.
 
 Blood Rush is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Blood Rush is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Blood Rush.  If not, see <http://www.gnu.org/licenses/>.
 ****/

#include "Particles.h"

Particles::Particles(){
	size = ofRandom(2, 5);
	fieldDivide = 1000;	
	G = ofRandom(5, 15);
	life = (int)ofRandom(40, 300);
	step = 2;
	
	r = (int)ofRandom(30, 100);
	g = (int)ofRandom(0, 20);
	b = (int)ofRandom(0, 40);

}

Particles::~Particles(){}

void Particles::partSetup(GLfloat _x, GLfloat _y, GLfloat _z, Perlin *_noise){
	x = _x;
	y = _y;
	z = _z;
	noise  = _noise;
}

void Particles::move(){
life--;
	float radXZ = noise->Get(x/fieldDivide, z/fieldDivide)*TWO_PI;
	float radY = noise->Get(x/fieldDivide, y/fieldDivide)*TWO_PI;
	vx = cos(radXZ)*10+ofRandom(-step, step);
	vy = -sin(radY)*10+ofRandom(-step, step)+G;
	vz = sin(radXZ)*10+ofRandom(-step, step);
	
	x += vx;
	y += vy;
	z += vz;
	

}

void Particles::render(){
	ofSetColor(r, g, b, 100);
	ofCircle(x, y, z, size);
}











