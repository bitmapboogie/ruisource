/*****
 Copyright 2008 Rui Madeira
 
 This file is part of Blood Rush.
 
 Blood Rush is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Blood Rush is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Blood Rush.  If not, see <http://www.gnu.org/licenses/>.
 ****/

#ifndef PARTICLES_H
#define PARTICLES_H

#include "ofMain.h"
#include "perlin.h"


class Particles{
public:
	GLfloat x, y, z, vx, vy, vz, G, size;
	Perlin *noise;
	GLint fieldDivide;
	GLint life, step;
	GLint r, g, b;
	Particles();
	~Particles();
	void partSetup(GLfloat _x, GLfloat _y, GLfloat _z, Perlin *_noise);
	void move();
	void render();
};

#endif