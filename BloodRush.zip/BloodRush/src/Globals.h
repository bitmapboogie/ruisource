/*****
 Copyright 2008 Rui Madeira
 
 This file is part of Blood Rush.
 
 Blood Rush is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Blood Rush is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Blood Rush.  If not, see <http://www.gnu.org/licenses/>.
 ****/

#ifndef GLOBALS_H
#define GLOBALS_H

//#define SAVE_IMAGE_SEQUENCE

#ifdef SAVE_IMAGE_SEQUENCE
#define MaxParticles 6000
#define MaxFrames 3000
#else
#define MaxParticles 800
#endif



//boids
#ifdef SAVE_IMAGE_SEQUENCE
#define numBoids 1000
#else
#define numBoids 500
#endif
#define larg 15


//pontos
#define numPoints 90
#define pK 0.8;
#define pDamp 0.4


//flowField complexity
#define fieldComplex 3000

#endif

