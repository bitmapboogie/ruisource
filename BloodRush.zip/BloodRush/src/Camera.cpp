/*****
 Copyright 2008 Rui Madeira
 
 This file is part of Blood Rush.
 
 Blood Rush is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Blood Rush is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Blood Rush.  If not, see <http://www.gnu.org/licenses/>.
 ****/

#include "Camera.h"

Camera::Camera(){
	fieldOfView = 65.0f;
	yon = 10000.0f;
	hither = 0.5f;
	w = glutGet(GLUT_WINDOW_WIDTH);
	h = glutGet(GLUT_WINDOW_HEIGHT);
	aspectRatio = (float)w/(float)h;
	
	vx = vy = vz = 0;
	k = 0.1;
	damp = 0.1;
	upX = 0;
	upY = 1;
	upZ = 0;
	eyeX = eyeY = eyeZ = 0;
	
	camX = ofGetWidth()/2;
	camY = ofGetHeight()/2;
	camZ = 0;
}

Camera::~Camera(){};

void Camera::goTo(float _x, float _y, float _z){
	ax = (_x - camX)*k;
	vx += ax;
	vx *= damp;
	camX += ax;
	
	ay = (_y - camY)*k;
	vy += ay;
	vy *= damp;
	camY += vy;
	
	az = (_z - camZ) * k;
	vz += az;
	vz *= damp;
	camZ += az;
	
	eyeX = camX;
	eyeY = camY;
	eyeZ = camZ-1;
	
}

void Camera::place(){
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fieldOfView, aspectRatio, hither, yon);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(camX, camY, camZ, eyeX, eyeY, eyeZ, upX, upY, upZ);
}
