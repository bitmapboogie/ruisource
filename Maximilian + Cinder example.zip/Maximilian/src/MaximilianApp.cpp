#include "cinder/app/AppBasic.h"
#include "cinder/gl/gl.h"
#include "MaxiPlayer.h"

using namespace ci;
using namespace ci::app;
using namespace std;

class MaximilianApp : public AppBasic {
  public:
	void setup();
	void mouseDown( MouseEvent event );	
	void mouseUp( MouseEvent event);
	void update();
	void draw();
	
	MaxiPlayer* maxi;
};

void MaximilianApp::setup()
{
	maxi = new MaxiPlayer();
}

void MaximilianApp::mouseDown( MouseEvent event )
{
}

void MaximilianApp::mouseUp( MouseEvent event){
	maxi->trigger();
}

void MaximilianApp::update()
{
}

void MaximilianApp::draw()
{
	// clear out the window with black
	gl::clear( Color( 0, 0, 0 ) ); 
}


CINDER_APP_BASIC( MaximilianApp, RendererGl )
