#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
	ofBackground(200, 200, 200);
	
	kinect.setVerbose(false);
	kinect.init( true );
	kinect.open();
	kinect.enableDepthNearValueWhite( true );
	
	ofEnableSmoothing();
	
	bWasHandOpen = false;
	oldNumBlobs = 0;
	
	bSetup = true;
	
	bHandBusy = false;
	
	for(int i=0; i<20; ++i){
		draggables.push_back( Draggable() );
	}

}

//--------------------------------------------------------------
void testApp::update(){
	kinect.update();
	handTracking.detect( kinect.getDepthPixels() );
	handTracking.filterDefects();
	
	vector<ofxCvBlobWithDefects>& blobs = handTracking.getBlobs();
	bool bIsHandOpen = false;
	ofPoint screenPos;
	if(blobs.size() > 0){
		ofxCvBlobWithDefects& blob = blobs.front();
		screenPos = blobs.front().centroid;
		screenPos.x *= (float)ofGetWidth() / 640.0f;
		screenPos.y *= (float)ofGetHeight() / 480.0f;
		int numDefects = blob.defects.size();
		bIsHandOpen = numDefects >= 3;
	}else{
		bIsHandOpen = false;
		bWasHandOpen = false;
	}
	
	if(blobs.size() && oldNumBlobs){
		if(bIsHandOpen && !bWasHandOpen){
			for(vector<Draggable>::iterator it = draggables.begin(); it != draggables.end(); ++it){
				it->setDrag( false );
			}
			bHandBusy = false;
		}
		if(!bIsHandOpen && bWasHandOpen){
			for(vector<Draggable>::iterator it = draggables.begin(); it != draggables.end(); ++it){
				Draggable& draggable = *it;
				if(draggable.isInside(screenPos)){
					draggable.setDrag( true );
					bHandBusy = true;
					break;
				}
			}
		}
	}
	
	if(blobs.size()){
		for(vector<Draggable>::iterator it = draggables.begin(); it != draggables.end(); ++it){
			Draggable& draggable = *it;
			if(!bIsHandOpen && draggable.isDrag()){
				draggable.goTo( screenPos );
			}else{
				if(bHandBusy) continue;
				draggable.isInside( screenPos );
			}
		}
	}
	
	if(!oldNumBlobs && !blobs.size()){
		bIsHandOpen = false;
		bWasHandOpen = false;
	}
	
	bWasHandOpen = bIsHandOpen;
	oldNumBlobs = blobs.size();
	
	for(vector<Draggable>::iterator it = draggables.begin(); it != draggables.end(); ++it){
		it->update();
	}
	
}

//--------------------------------------------------------------
void testApp::draw(){
	if(bSetup){
		handTracking.drawSetup();
		
		glColor3f(1.0f, 1.0f, 1.0f);
		ofPoint center = ofPoint(ofGetWidth() / 2.0f, ofGetHeight() / 2.0f );
		glBegin(GL_LINES);
		glVertex2f( center.x, center.y );
		glVertex2f(center.x + (avgFlow.x * 5), center.y + (avgFlow.y * 5) );
		glEnd();
		
	}else{
		handTracking.draw();

		for(vector<Draggable>::iterator it = draggables.begin(); it != draggables.end(); ++it){
			it->draw();
		}
	}
	glColor3f(1.0f, 1.0f, 1.0f);
	kinect.getTextureReference().draw(ofGetWidth() - 180, ofGetHeight() - 140, 160, 120); 
}

//--------------------------------------------------------------
void testApp::keyPressed(int key){
	
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){
	if(key == ' '){
		bSetup = !bSetup;
	}
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

