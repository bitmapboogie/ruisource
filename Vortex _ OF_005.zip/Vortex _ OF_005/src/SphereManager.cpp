/*********************
 Copyright 2009 Rui Madeira
 
 This file is part of Vortex.
 
 Vortex is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Vortex is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Vortex.  If not, see <http://www.gnu.org/licenses/>.
 *////////////////////////

#include "SphereManager.h"

SphereManager::SphereManager(){
	sceneCenter.set(ofGetWidth()/2, ofGetHeight()/2, 0);
	
	collisionConfiguration = new btDefaultCollisionConfiguration();
	dispatcher = new btCollisionDispatcher(collisionConfiguration);
	
	btVector3 aabbMin(-10000, -10000, -10000);
	btVector3 aabbMax(10000, 10000, 10000);
	int maxProxies = 1024;
	overlappingPairCache = new btAxisSweep3(aabbMin, aabbMax, maxProxies);
	
	solver = new btSequentialImpulseConstraintSolver();
	theWorld = new btDiscreteDynamicsWorld(dispatcher, overlappingPairCache, solver, collisionConfiguration);
	theWorld->setGravity(btVector3(0, 0, 0));
	
	coreImg.loadImage("core.png");
}

SphereManager::~SphereManager(){
	delete collisionConfiguration;
	delete dispatcher;
	delete overlappingPairCache;
	delete solver;
	delete theWorld;
	spheres.clear();
}

void SphereManager::createSphere(){
	ofxVec3f pos;
	pos.set(ofRandom(-100, 100), ofRandom(-100, 100), ofRandom(-100,100));
	float radius = ofRandom(5, 20);
	spheres.push_back(new Sphere(pos, radius));
	theWorld->addRigidBody(spheres.back()->getRigidBody());
}

void SphereManager::update(){
	theWorld->stepSimulation(1.0f/60.0f, 10);
	for(int i=0; i<spheres.size(); i++){
		spheres[i]->update();
	}
}

void SphereManager::render(){
	ofSetRectMode(OF_RECTMODE_CENTER);
	glPushMatrix();
	glTranslatef(sceneCenter.x, sceneCenter.y, sceneCenter.z);
	for(int i=0; i<spheres.size(); i++){
		spheres[i]->render();
	}
	//renderParticles();
	glPopMatrix();
}

Sphere* SphereManager::getSphere(int _id){
	if(_id >= 0 and _id < spheres.size()) return spheres[_id];
	cout << "SphereManager::getSphere() : array out of bounds\n";
	return spheres[0];
}

ofxVec3f SphereManager::getSceneCenter(){
	return sceneCenter;
}

void SphereManager::setSceneCenter(ofxVec3f _center){
	sceneCenter = _center;
}

int SphereManager::getNumSpheres(){
	return spheres.size();
}

