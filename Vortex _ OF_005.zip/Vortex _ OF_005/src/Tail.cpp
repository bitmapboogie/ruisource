/*********************
 Copyright 2009 Rui Madeira
 
 This file is part of Vortex.
 
 Vortex is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Vortex is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Vortex.  If not, see <http://www.gnu.org/licenses/>.
 *////////////////////////

#include "Tail.h"

Tail::Tail(ofxVec3f _pos, float _tailWidth, int _numPoints, float _damp, float _k){
	damp = _damp;
	k = _k;
	tailWidth = _tailWidth;
	for(int i=0; i<_numPoints; i++){
		points.push_back(ofxVec3f(_pos));
	}
}

Tail::~Tail(){
	points.clear();
}

void Tail::update(ofxVec3f _pos){
	points[0].set(_pos);
	for(int i=1; i<points.size(); i++){
		points[i] += (points[i-1] - points[i]) * 0.2f;
	}
}

void Tail::render(){
	float offX, offY;
	float angle;
	float _width;
	ofxVec3f normalVec;
	glBegin(GL_QUAD_STRIP);
	for(int i=1; i<points.size(); i++){
		_width = (1 - (float)i / (points.size()-1)) * tailWidth; 
		//_width = sin(PI * (float)i/(points.size()-1)) * tailWidth;
		normalVec = points[i] - points[i-1];
		normalVec.cross(ofxVec3f(0,1,0));
		normalVec.normalize();
		angle = atan2(points[i].y - points[i-1].y, points[i].x - points[i-1].x);
		offX = sin(angle) * _width;
		offY = cos(angle) * _width;
		glNormal3f(normalVec.x, normalVec.y, normalVec.z);
		glVertex3f(points[i].x + offX, points[i].y + offY, points[i].z);
		glVertex3f(points[i].x - offX, points[i].y - offY, points[i].z);
	}
	glEnd();
}

void Tail::addSegment(){
	points.push_back(ofxVec3f(points.back()));
}

void Tail::removeSegment(){
	if(points.size() > 1)
		points.pop_back();
}
