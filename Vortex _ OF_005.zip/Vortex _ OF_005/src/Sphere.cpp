/*********************
 Copyright 2009 Rui Madeira
 
 This file is part of Vortex.
 
 Vortex is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Vortex is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Vortex.  If not, see <http://www.gnu.org/licenses/>.
 *////////////////////////

#include "Sphere.h"


Sphere::Sphere(ofxVec3f _pos, float _radius, int _res){
	currentSphereResolution = _res;
	targetSphereResolution = _res;
	resolutionInterp = 0.2;
	
	theShape = new btSphereShape(btScalar(1.0f));
	
	currentRadius = _radius;
	targetRadius = _radius;
	radiusInterp = 0.2f;
	iniRadius = _radius;
	theShape->setLocalScaling(btVector3(currentRadius, currentRadius, currentRadius));
	
	btTransform initTransform;
	initTransform.setIdentity();
	btScalar mass(10.0f);
	btVector3 inertia;
	theShape->calculateLocalInertia(mass, inertia);
	initTransform.setOrigin(btVector3(_pos.x, _pos.y, _pos.z));
	theMotionState = new btDefaultMotionState(initTransform);
	btRigidBody::btRigidBodyConstructionInfo rbInfo(mass, theMotionState, theShape, inertia);
	theBody = new btRigidBody(rbInfo);
	theBody->setDamping(btScalar(0.7), btScalar(0.9));
	
	float val = ofRandom(0.1f, 1.0f);
	color[0] = val ;
	color[1] = val ;
	color[2] = val;
	color[3] = 1.0f;
}

Sphere::~Sphere(){
	delete theMotionState;
	delete theShape;
	delete theBody;
}

void Sphere::update(){
		currentRadius += (targetRadius - currentRadius) * radiusInterp;
	theShape->setLocalScaling(btVector3(currentRadius, currentRadius, currentRadius));
	currentSphereResolution += (targetSphereResolution - currentSphereResolution) * resolutionInterp;
	
}

void Sphere::render(){
	float matrix[16];
	btTransform trans;
	float lineLength = currentRadius * 0.1f;
	float lineColor = 1.0f - color[0];
	theMotionState->getWorldTransform(trans);
	trans.getOpenGLMatrix(matrix);
	glPushMatrix();
	glNormal3f(0,0,1);
	glMultMatrixf(matrix);
	glColor4f(0.0f, .0f, .0f, 0.05f);
	glDisable(GL_DEPTH_TEST);
	ofxSphere(0, 0, 0, currentRadius);
	glEnable(GL_DEPTH_TEST);
	glColor4fv(color);
	ofxSphere(0,0,0,iniRadius);
	glPopMatrix();
}

ofxVec3f Sphere::getPosition(){
	btTransform trans;
	theMotionState->getWorldTransform(trans);
	btVector3 btPos = trans.getOrigin();
	return ofxVec3f(btPos.x(), btPos.y(), btPos.z());
}


ofxVec3f Sphere::getVelocity(){
	btVector3 _vel = theBody->getLinearVelocity();
	return ofxVec3f(_vel.x(), _vel.y(), _vel.z());
}

void Sphere::applyForce(ofxVec3f _force){
	btVector3 btForce(_force.x, _force.y, _force.z);
	theBody->applyCentralForce(btForce);
}

void Sphere::applyRandomForce(float _scale){
	ofxVec3f force;
	force.set(0,0,1);
	force.rotate(ofRandomuf()*360, ofRandomuf()*360, 0);
	force *= _scale;
	applyForce(force);
}

void Sphere::applyImpulse(ofxVec3f _impulse){
	btVector3 btImpulse(_impulse.x, _impulse.y, _impulse.z);
	theBody->applyCentralImpulse(btImpulse);
}

void Sphere::applyRandomImpulse(float _scale){
	ofxVec3f impulse;
	impulse.set(0, 0, 1);
	impulse.rotate(ofRandomuf()*360, ofRandomuf()*360, 0);
	impulse *= _scale;
	applyImpulse(impulse);
}

void Sphere::setRadius(float _radius){
	targetRadius = _radius;
}

float Sphere::getRadius(){
	return currentRadius;
}


btCollisionShape * Sphere::getCollisionShape(){
	return theShape;
}

btRigidBody * Sphere::getRigidBody(){
	return theBody;
}

void Sphere::setColor(float _r, float _g, float _b, float _alpha){
	color[0] = _r;
	color[1] = _g;
	color[2] = _b;
	color[3] = _alpha;
}

float * Sphere::getColor(){
	return color;
}

bool Sphere::isPointInsideBoundingBox(ofxVec3f p){
	ofxVec3f min, max;
	getBoundingBox(min, max);
	bool bInside = p.x > min.x and p.y > min.y and p.z > min.z and p.x < max.x and p.y < max.y and p.z < max.z;
	return bInside;
}

void Sphere::getBoundingBox(ofxVec3f& aabbMin, ofxVec3f& aabbMax){
	ofxVec3f pos = getPosition();
	float radius = getRadius();
	aabbMin.set(pos - radius);
	aabbMax.set(pos + radius);
}

void Sphere::renderSphere(int resolution, float radius){
	
	float theta,nextTheta, phi, x, y, z;
	for(int i=0; i<resolution; i++){
		theta = (float)i/(resolution-1) * TWO_PI;
		nextTheta = (float)((i+1)%resolution)/(resolution-1) * TWO_PI;
		glBegin(GL_QUAD_STRIP);
		for(int j=0; j<resolution; j++){
			phi = (float)j/(resolution-1) * PI;
			x = cos(theta) * sin(phi);
			y = sin(theta) * sin(phi);
			z = cos(phi);
			glNormal3f(x, y, z);
			glVertex3f(x * radius, y * radius, z * radius);
			x = cos(nextTheta) * sin(phi);
			y = sin(nextTheta) * sin(phi);
			z = cos(phi);
			glNormal3f(x, y, z);
			glVertex3f(x * radius, y * radius, z * radius);
		}
		glEnd();
	}
}

void Sphere::setSphereResolution(float _res){
	targetSphereResolution = _res;
}

int Sphere::getSphereResolution(){
	return (int)currentSphereResolution;
}




