/*********************
 Copyright 2009 Rui Madeira
 
 This file is part of Vortex.
 
 Vortex is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Vortex is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Vortex.  If not, see <http://www.gnu.org/licenses/>.
 *////////////////////////

#pragma once

#include "btBulletDynamicsCommon.h"
#include "btBulletCollisionCommon.h"
#include "ofMain.h"
#include "Sphere.h"
#include "Tail.h"
#include "Particle.h"

class SphereManager{
protected:
	
	vector<Sphere*>spheres;
	
	btDefaultCollisionConfiguration * collisionConfiguration;
	btCollisionDispatcher * dispatcher;
	btAxisSweep3 * overlappingPairCache;
	btSequentialImpulseConstraintSolver * solver;
	btDynamicsWorld * theWorld;
	
	ofxVec3f sceneCenter;
	
	ofImage coreImg;
	
public:
	SphereManager();
	~SphereManager();
	
	void createSphere();
	void update();
	void render();
	Sphere* getSphere(int _id); 
	
	ofxVec3f getSceneCenter();
	void setSceneCenter(ofxVec3f _center);
	int getNumSpheres();
};