/*********************
 Copyright 2009 Rui Madeira
 
 This file is part of Vortex.
 
 Vortex is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Vortex is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Vortex.  If not, see <http://www.gnu.org/licenses/>.
 *////////////////////////

#pragma once

#include "ofMain.h"
#include "ofxVec3f.h"


class Tail{
protected:
	vector<ofxVec3f> points;
	float damp, k;
	float tailWidth;
public:
	Tail(ofxVec3f pos, float _tailWidth, int _numPoints = 100, float _damp = 0.5, float _k = 0.9);
	~Tail();
	
	void update(ofxVec3f _pos);
	void render();
	
	void addSegment();
	void removeSegment();
};










