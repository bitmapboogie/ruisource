/*********************
 Copyright 2009 Rui Madeira
 
 This file is part of Vortex.
 
 Vortex is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Vortex is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Vortex.  If not, see <http://www.gnu.org/licenses/>.
 *////////////////////////

#include "testApp.h"


//--------------------------------------------------------------
void testApp::setup(){	 
	ofBackground(255, 255, 255);
	//ofBackground(0, 0, 0);
	ofSetVerticalSync(true);
	ofEnableSmoothing();
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	//glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_DEPTH_TEST);
	sphereManager = new SphereManager();
	
	for(int i=0; i<NUM_SPHERES; i++){
		sphereManager->createSphere();
	}
	
	music.loadSound("music.mp3");
	music.play();
	
	light.pointLight(255, 255, 255, ofGetWidth()/2, ofGetHeight()/2, 1000);
	light.specular(255, 255, 255);
	ofxLightsOff();
	
	bands = new int[sphereManager->getNumSpheres()];
	for(int i=0; i<NUM_SPHERES; i++){
		bands[i] = (int)(ofRandomuf() * NUM_BANDS*0.5);
	}
	
	backgroundImg.loadImage("fundo.png");
	
#ifndef SAVE_FRAMES
	ofxSetSphereResolution(5);
#endif
}

//--------------------------------------------------------------
void testApp::update(){
#ifdef SAVE_FRAMES
	int FPS = 30;
	float totalFrames = (music.length / music.internalFreq) * FPS;
	float musicPos = (float)ofGetFrameNum() / totalFrames;
	music.setPosition(musicPos);
#endif
	float *fftValues = ofSoundGetSpectrum(NUM_BANDS);
	float normalizedValues[NUM_SPHERES];
	float averageVal = 0;
	float maxVal = 0;
	for(int i=0; i<NUM_BANDS; i++){
		if(fftValues[i] > maxVal) maxVal = fftValues[i];
	}
	for(int i=0; i<NUM_BANDS; i++){
		normalizedValues[i] = fftValues[i] / maxVal;
		averageVal += normalizedValues[i];
	}
	averageVal /= NUM_BANDS;
	
	sphereManager->update();
	
	if(music.getIsPlaying()){
		float threshold = 0.9;
		ofxVec3f force;
		ofxVec3f crossVec;
		crossVec.set(0, 1, 0);
		crossVec.rotate(ofGetFrameNum(), 0, ofGetFrameNum() * 0.5);
		ofxVec3f tangentVec;
		Sphere * s;
		for(int i=0; i<NUM_SPHERES; i++){
			s = sphereManager->getSphere(i);
			if(normalizedValues[bands[i]] > threshold){
				s->setRadius(averageVal * 10 +  normalizedValues[bands[i]] * 50 + 10);
				s->applyRandomImpulse(normalizedValues[bands[i]] * 100);
			} else {
				s->setRadius(maxVal * 60 + averageVal * 10 + 10);
			}
			force.set(-s->getPosition());
			force *= maxVal* 15;
			tangentVec = force.crossed(crossVec);
			tangentVec.normalize();
			tangentVec *= maxVal*1000;
			force += tangentVec;
			s->applyImpulse(force);
			s->applyRandomImpulse(maxVal * 4000);
		}
	} else {
		Sphere * s;
		for(int i=0; i<NUM_SPHERES; i++){
			s = sphereManager->getSphere(i);
			s->setRadius(0);
		}
	}
	
#ifndef SAVE_FRAMES
	cout << ofGetFrameRate() << endl;
#else
	string info = ofToString(ofGetFrameNum(), 0) + " of " + ofToString(totalFrames) + "\n"; 
	cout << info << endl;
	if(ofGetFrameNum() > totalFrames) std::exit(0);
#endif
}

//--------------------------------------------------------------
void testApp::draw(){
	ofxLightsOn();
	sphereManager->render();
	
#ifdef SAVE_FRAMES
	if(music.getPosition() < 1.0){
		ofImage frame;
		frame.grabScreen(0,0,ofGetWidth(), ofGetHeight());
		string fileName = "frameNum" + ofToString(ofGetFrameNum()) + ".png";
		frame.saveImage(fileName);
	} 
#endif
}

//--------------------------------------------------------------
void testApp::keyPressed  (int key){ 
	
}

//--------------------------------------------------------------
void testApp::keyReleased  (int key){ 
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){
	
}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
}

//--------------------------------------------------------------
void testApp::mouseReleased(){
}
