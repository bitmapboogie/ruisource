/*********************
 Copyright 2009 Rui Madeira
 
 This file is part of Vortex.
 
 Vortex is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Vortex is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Vortex.  If not, see <http://www.gnu.org/licenses/>.
 *////////////////////////

#pragma once

#include "ofMain.h"
#include "btBulletDynamicsCommon.h"
#include "btBulletCollisionCommon.h"
#include "ofxVec3f.h"
#include "ofx3DUtils.h"

class Sphere{
protected:
	btSphereShape * theShape;
	btRigidBody * theBody;
	btMotionState * theMotionState;
	
	float targetRadius, currentRadius, radiusInterp, iniRadius;
	float color[4];
	float targetSphereResolution, currentSphereResolution, resolutionInterp;
	
public:
	Sphere(ofxVec3f _pos, float _radius, int _res = 20);
	~Sphere();
	
	void render();
	void update();
	
	ofxVec3f getPosition();
	ofxVec3f getVelocity();
	
	void applyForce(ofxVec3f _force);
	void applyRandomForce(float _scale);
	void applyImpulse(ofxVec3f _impulse);
	void applyRandomImpulse(float _scale);
	void setRadius(float _radius);
	float getRadius();
	btCollisionShape * getCollisionShape();
	btRigidBody * getRigidBody();
	
	void setColor(float _r, float _g, float _b, float _alpha = 1.0f);
	float * getColor();
	
	bool isPointInsideBoundingBox(ofxVec3f _point);
	void getBoundingBox(ofxVec3f& aabbMin, ofxVec3f& aabbMax); 
	
	void setSphereResolution(float _res);
	int getSphereResolution();
	void renderSphere(int resolution, float radius);
};