/*********************
 Copyright 2009 Rui Madeira
 
 This file is part of Vortex.
 
 Vortex is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Vortex is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Vortex.  If not, see <http://www.gnu.org/licenses/>.
 *////////////////////////

#pragma once

#include "ofxVec3f.h"

class Particle:public ofxVec3f{
protected:
	float damp;
	ofxVec3f accel, vel, gravity;
	bool bHasForce;
	float life;
	bool bDead;
public:
	Particle(ofxVec3f _pos = ofxVec3f(), float _damp = 0.7){
		set(_pos);
		damp = _damp;
		life = ofRandom(10, 100);
		bDead = false;
	}
	
	void setGravity(ofxVec3f _g){
		gravity.set(_g);
	}
	
	void addForce(ofxVec3f _f){
		accel += _f;
		bHasForce = true;
	}
	
	void update(){
		life--;
		if(life <= 0){
			bDead = true;
			return;
		}
		if(bHasForce){
			bHasForce = false;
			vel += accel;
			vel += gravity;
			vel *= damp;
			*this += vel;
			accel.set(0,0, 0);
			return;
		}
		vel += gravity;
		vel *= damp;
		*this += vel;
	}
	
	
	float getDamp(){return damp;}
	void setDamp(float _damp){damp = _damp;}
	
	ofxVec3f getPosition(){ return *this;}
	ofxVec3f getVelocity(){	return vel;}
	ofxVec3f getForces(){ return accel;}
	void setPosition(ofxVec3f _pos){set(_pos);}
	void setVelocity(ofxVec3f _vel){vel.set(_vel);}
	void setForces(ofxVec3f _forces){accel.set(_forces);}
	bool getIsDead(){return bDead;}
};