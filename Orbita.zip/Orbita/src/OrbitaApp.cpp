#include "cinder/app/AppCocoaTouch.h"
#include "cinder/app/Renderer.h"
#include "cinder/Text.h"

#include "NodeManager.h"
#include "Center.h"
#include "HaloManager.h"
#include "GlobalSettings.h"
#include "ResetButton.h"
#include "HelpButton.h"
#include "SoundGenerator.h"
#include "NodeConverter.h"
#include "SplashScreen.h"
#include "NodeGrabber.h"
#include "Help.h"

using namespace ci;
using namespace ci::app;

//main class! YAY!

class OrbitApp : public AppCocoaTouch {
public:
	void setup();
	void resize( ResizeEvent event );
	void update();
	void draw();
	void touchesBegan( TouchEvent e );
	void touchesMoved( TouchEvent e );
	void touchesEnded( TouchEvent e );
	void shutdown();
	
	NodeManager nodeManager;
	Center* center;
	HaloManager haloManager;
	ResetButton resetButton;
	HelpButton helpButton;
	Help help;
	SoundGenerator soundGen;
	NodeConverter nodeConverter;
	SplashScreen splashScreen;
	NodeGrabber nodeGrabber;
	
};

void OrbitApp::setup(){
	//simple not very correct way of checking if its a retina display or not...
	if( getWindowWidth() == 320 ) GlobalSettings::prepareSettingsForIphone3();
	else GlobalSettings::prepareSettingsForIphone4();
	center = new Center( GlobalSettings::getCenter() );
	resetButton.init();
	helpButton.init();
	help.init();
}

void OrbitApp::resize( ResizeEvent event ){
	gl::setMatricesWindow( getWindowWidth(), getWindowHeight() );
	splashScreen.loadImage();
	splashScreen.draw();
}

void OrbitApp::update(){
	if( splashScreen.isShowing() ){
		splashScreen.update();
	} else {
		if( help.isShowing() ) return;
		nodeManager.update();
		haloManager.update();
		nodeConverter.convert( nodeManager, soundGen, haloManager );
	}
}

void OrbitApp::draw(){
	gl::clear( Color::black() );
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable( GL_LINE_SMOOTH );
	glEnableClientState( GL_VERTEX_ARRAY );
	nodeManager.draw();
	center->draw();
	haloManager.draw();
	resetButton.draw();
	helpButton.draw();
	help.draw();
	splashScreen.draw();
}

void OrbitApp::touchesBegan( TouchEvent e ){
	if( splashScreen.isShowing() ) return;
	if( help.isShowing() ) return;
	if( resetButton.isInside( e ) ) return;
	if( helpButton.isInside( e ) ) return;
	center->setColor( Color(1.0f, 0.0f, 0.0f) );
	nodeGrabber.touchesBegan( e, nodeManager, *center );
}

void OrbitApp::touchesMoved( TouchEvent e ){
	if( splashScreen.isShowing() ) return;
	if( help.isShowing() ) return;
	nodeGrabber.touchesMoved( e, nodeManager, *center );
}

void OrbitApp::touchesEnded( TouchEvent e ){
	if( getActiveTouches().size() == 0 ) center->setColor( Color::white() );
	if( splashScreen.isShowing() ){
		splashScreen.fadeOut();
		return;
	}
	
	if( help.isShowing() ){
		help.switchPage();
		return;
	}
	
	if( resetButton.isInside( e ) ){
		nodeManager.clear();
		return;
	}
	if( helpButton.isInside( e ) ){
		help.beginShowing();
		return;
	}
	nodeGrabber.touchesEnded( e, nodeManager, *center );
}

void OrbitApp::shutdown(){
	soundGen.quit();
}



CINDER_APP_COCOA_TOUCH( OrbitApp, RendererGl )
