#pragma once

#include "cinder/Vector.h"
#include "cinder/app/App.h"
#include "cinder/gl/gl.h"
#include "Graphics.h"
#include "GlobalSettings.h"

using namespace ci;
using namespace ci::gl;

// that circle on the center of the screen where you touch to create Nodes
class Center{
public:
	Center(const Vec2f& pos);
	
	void draw();
	const Vec2f& getPos() const;
	float getRadius() const;
	bool isInside(const Vec2f& pt) const;
	void setColor( const Color& color );
	
	const Vec2f& getCenter(){ return pos;}
protected:
	static Vec2f pos;
	float radius;
	float rectHeight, rectWidth;
	Color color;
	
};
