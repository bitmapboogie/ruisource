#include "Graphics.h"

vector<GLfloat> Graphics::solidCircleVertices = vector<GLfloat>();
vector<GLfloat> Graphics::strokedCircleVertices = vector<GLfloat>();
vector<GLfloat> Graphics::haloVertices = vector<GLfloat>();
//vector<GLfloat> Graphics::lineVertices = vector<GLfloat>();
//vector<GLfloat> Graphics::rectVertices = vector<GLfloat>();

GLfloat Graphics::lineVertices[4];
GLfloat Graphics::rectVertices[8];

GraphicsIniter Graphics::_graphicsIniter = GraphicsIniter();

