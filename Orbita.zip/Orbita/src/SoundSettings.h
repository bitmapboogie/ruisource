#pragma once


//glogal class with sound settings
class SoundSettings{
public:
	static const float sampleRatef = 44100.0f;
	static const float bufferSizef = 1024.0f;
	static const int sampleRatei = 44100;
	static const int bufferSizei = 1024;
};
