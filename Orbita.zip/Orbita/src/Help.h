#pragma once

#include "cinder/Vector.h"
#include "cinder/gl/Texture.h"
#include "cinder/Rect.h"
#include "cinder/app/App.h"

#include "GlobalSettings.h"

using namespace ci;


//the Help class

class Help{
public:
	Help(){
		pageIndex = -1;
		pages = NULL;
		numPages = 0;
	}
	
	void init(){
		rect.x1 = 0.0f;
		rect.y1 = 0.0f;
		rect.x2 = (float)app::getWindowWidth();
		rect.y2 = (float)app::getWindowHeight();
		
		numPages = 6;
		if( pages ){
			delete[] pages;
		}
		pages = new gl::Texture[ numPages ];
		pages[0] = gl::Texture( loadImage( loadResource( "instructions-01.png" ) ) );
		pages[1] = gl::Texture( loadImage( loadResource( "instructions-02.png" ) ) );
		pages[2] = gl::Texture( loadImage( loadResource( "instructions-03.png" ) ) );
		pages[3] = gl::Texture( loadImage( loadResource( "instructions-04.png" ) ) );
		pages[4] = gl::Texture( loadImage( loadResource( "instructions-05.png" ) ) );
		pages[5] = gl::Texture( loadImage( loadResource( "instructions-06.png" ) ) );
	}
	
	void draw(){
		if( pageIndex == -1 ) return;
		gl::color( Color::white() );
		gl::draw( pages[pageIndex], rect );
	}
	
	
	bool isInside( const Vec2f& pt ) const{
		return rect.contains( pt );
	}
	
	int getNumPages() const{
		return numPages;
	}
	
	bool isShowing() const{
		return pageIndex > -1;
	}
	
	void beginShowing(){
		pageIndex = 0;
	}
	
	void switchPage(){
		++pageIndex;
		if( pageIndex >= numPages ) pageIndex = -1;
	}
	
protected:
	int pageIndex;
	int numPages;
	gl::Texture *pages;
	Rectf rect;
};
