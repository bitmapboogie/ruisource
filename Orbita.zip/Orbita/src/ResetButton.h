#pragma once

#include "cinder/Cinder.h"
#include "cinder/Vector.h"
#include "cinder/app/TouchEvent.h"
#include "GlobalSettings.h"
#include "Graphics.h"
#include "cinder/gl/gl.h"
#include "cinder/app/App.h"

#include "ButtonBase.h"

using namespace ci;

//the reset button on the lower left corner of the screen

class ResetButton: public ButtonBase{
public:
	ResetButton(){
		rectWidth = rectHeight = 0.0f;
	}
	
	void init(){
		radius = GlobalSettings::getMaxRadius();
		radiusSQ = radius*radius;
		if( GlobalSettings::isIphone4() ){
			pos.x = 30.0f;
			pos.y = (float)app::getWindowHeight() - 30.0f;
			rectWidth = 20.0f;
			rectHeight = 5.0f;
		}else{
			pos.x = 15.0f;
			pos.y = (float)app::getWindowHeight() - 15.0f;
			rectWidth = 10.0;
			rectHeight = 2.0f;
		}
	}
	
	void draw(){
		glPushMatrix();
		glTranslatef( pos.x, pos.y, 0.0f );
		glRotatef( 45.0f, 0.0f, 0.0f, 1.0f );
		gl::color( Color(0.2f, 0.2f, 0.2f) );
		Graphics::drawRectSolid( Vec2f(-rectWidth, -rectHeight), Vec2f(rectWidth, rectHeight));
		Graphics::drawRectSolid( Vec2f(-rectHeight, -rectWidth), Vec2f(rectHeight, rectWidth));
		glPopMatrix();
	}
	
protected:
	float rectWidth, rectHeight;
};

