#pragma once

#include "cinder/Vector.h"
#include "cinder/gl/gl.h"
#include <vector>


#ifndef TWO_PI
#define TWO_PI 6.28318530717958647693
#endif

#ifndef PI
#define PI       3.14159265358979323846
#endif

using namespace ci;
using namespace std;

#define SOLID_CIRCLE_RES 20
#define STROKED_CIRCLE_RES 50
#define HALO_VERTICES_RES 30

class GraphicsIniter;

//some helpfull drawing methods

class Graphics{
public: 
	
	static void drawCircleSolid(const Vec2f& pos, float radius){
		glPushMatrix();
		glTranslatef( pos.x, pos.y, 0.0f );
		glScalef( radius, radius, 1.0f );
		//glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(2, GL_FLOAT, 0, &solidCircleVertices[0]);
		glDrawArrays(GL_TRIANGLE_FAN, 0, SOLID_CIRCLE_RES + 1);
		glPopMatrix();
	}
	
	static void drawCircleDashed( const Vec2f& pos, float radius){
		glPushMatrix();
		glTranslatef(pos.x, pos.y, 0.0f);
		glScalef( radius, radius, 1.0f );
		//glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(2, GL_FLOAT, 0, &strokedCircleVertices[0]);
		glDrawArrays(GL_LINES, 0, STROKED_CIRCLE_RES);
		glPopMatrix();
	}
	
	static void drawCircleStroked( const Vec2f& pos, float radius){
		glPushMatrix();
		glTranslatef(pos.x, pos.y, 0.0f);
		glScalef( radius, radius, 1.0f );
		//glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(2, GL_FLOAT, 0, &strokedCircleVertices[0]);
		glDrawArrays(GL_LINE_LOOP, 0, STROKED_CIRCLE_RES);
		glPopMatrix();
	}
	
	static void drawLine( const Vec2f& vA, const Vec2f& vB ){
		lineVertices[0] = vA.x;
		lineVertices[1] = vA.y;
		lineVertices[2] = vB.x;
		lineVertices[3] = vB.y;
		//glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(2, GL_FLOAT, 0, &lineVertices[0]);
		glDrawArrays(GL_LINES, 0, 2);
	}
	
	static void drawHalo( const Vec2f& pos, float radius){
		glPushMatrix();
		glTranslatef( pos.x, pos.y, 0.0f);
		glScalef( radius, radius, 0.0f );
		//glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(2, GL_FLOAT, 0, &haloVertices[0]);
		glDrawArrays(GL_TRIANGLE_STRIP, 0, HALO_VERTICES_RES * 2);
		glPopMatrix();
	}
	
	static void drawRectSolid( const Vec2f& topLeft, const Vec2f& bottomRight){
		rectVertices[0] = topLeft.x;
		rectVertices[1] = topLeft.y;
		rectVertices[2] = bottomRight.x;
		rectVertices[3] = topLeft.y;
		rectVertices[4] = bottomRight.x;
		rectVertices[5] = bottomRight.y;
		rectVertices[6] = topLeft.x;
		rectVertices[7] = bottomRight.y;
	//	glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(2, GL_FLOAT, 0, rectVertices);
		glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
	}
	
	static void drawRectStroked( const Vec2f& topLeft, const Vec2f& bottomRight){
		rectVertices[0] = topLeft.x;
		rectVertices[1] = topLeft.y;
		rectVertices[2] = bottomRight.x;
		rectVertices[3] = topLeft.y;
		rectVertices[4] = bottomRight.x;
		rectVertices[5] = bottomRight.y;
		rectVertices[6] = topLeft.x;
		rectVertices[7] = bottomRight.y;
	//	glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(2, GL_FLOAT, 0, rectVertices);
		glDrawArrays(GL_LINE_LOOP, 0, 4);
	}
	
protected:
	static vector<GLfloat> solidCircleVertices;
	static vector<GLfloat> strokedCircleVertices;
	static vector<GLfloat> haloVertices;
	static GLfloat lineVertices[4];
	static GLfloat rectVertices[8];
	static GraphicsIniter _graphicsIniter;
	
	friend class GraphicsIniter;
};

class GraphicsIniter{
	friend class Graphics;
protected:
	GraphicsIniter(){
		Graphics::solidCircleVertices.push_back( 0.0f );
		Graphics::solidCircleVertices.push_back( 0.0f );
		float angle = 0.0f;
		float angleAdd = TWO_PI / (SOLID_CIRCLE_RES - 1);
		for(int i=0; i<SOLID_CIRCLE_RES; ++i){
			Graphics::solidCircleVertices.push_back( cosf( angle ) );
			Graphics::solidCircleVertices.push_back( sinf( angle ) );
			angle += angleAdd;
		}
		
		angle = 0.0f;
		angleAdd = TWO_PI / (STROKED_CIRCLE_RES - 1);
		for(int i=0; i<STROKED_CIRCLE_RES; ++i){
			Graphics::strokedCircleVertices.push_back( cosf( angle ) );
			Graphics::strokedCircleVertices.push_back( sinf( angle ) );
			angle += angleAdd;
		}
		
		angle = 0.0f;
		angleAdd = TWO_PI / (HALO_VERTICES_RES - 1);
		for(int i=0; i<HALO_VERTICES_RES; ++i){
			float x = cosf( angle );
			float y = sinf( angle );
			Graphics::haloVertices.push_back( x * 0.5f );
			Graphics::haloVertices.push_back( y * 0.5f );
			Graphics::haloVertices.push_back( x * 1.0f );
			Graphics::haloVertices.push_back( y * 1.0f );
			angle += angleAdd;
		}
	}
};










