#include "NodeManager.h"

NodeManager::NodeManager(){
}

NodeManager::~NodeManager(){
	nodes.clear();
}

void NodeManager::update(){
	for(vector<Node>::iterator it = nodes.begin(); it != nodes.end(); ++it){
		it->update();
	}
}

void NodeManager::draw(){
	for(vector<Node>::iterator it = nodes.begin(); it != nodes.end(); ++it){
		it->drawLapBegin();
	}
	for(vector<Node>::iterator it = nodes.begin(); it != nodes.end(); ++it){
		it->draw();
	}
}

void NodeManager::clear(){
	nodes.clear();
}

Node* NodeManager::createNode( const Vec2f& pos ){
	nodes.push_back( Node( pos, Color( 1.0f, 0.0f, 0.0f ) ) );
	return &( nodes.back() );
}

bool NodeManager::removeNode( const Node* node ){
	for( vector<Node>::iterator it = nodes.begin(); it != nodes.end(); ++it){
		if( &( *it ) == node ){
			nodes.erase( it );
			return true;
		} 
	}
	return false;
}

vector<Node>& NodeManager::getNodes(){
	return nodes;
}

Node* NodeManager::getNearestNode( const Vec2f& pt ){
	if(nodes.size() == 0) return NULL;
	float dx, dy, distSQ, minDistSQ = MAXFLOAT;
	Node* res = NULL;
	for(vector<Node>::iterator it = nodes.begin(); it != nodes.end(); ++it){
		Node& node = *it;
		const Vec2f& pos = node.getPos();
		dx = pos.x - pt.x;
		dy = pos.y - pt.y;
		distSQ = dx*dx+dy*dy;
		if( distSQ < minDistSQ ){
			res = &node;
			minDistSQ = distSQ;
		}
	}
	return res;
}

Node* NodeManager::getNodeWithNearestLapPos( const Vec2f& pt ){
	if( nodes.size() == 0 ) return NULL;
	float dx, dy, distSQ, minDistSQ = MAXFLOAT;
	Node* res = NULL;
	for(vector<Node>::iterator it = nodes.begin(); it != nodes.end(); ++it){
		Node& node = *it;
		const Vec2f& pos = node.getLapBeginPos();
		dx = pos.x - pt.x;
		dy = pos.y - pt.y;
		distSQ = dx*dx+dy*dy;
		if( distSQ < minDistSQ ){
			res = &node;
			minDistSQ = distSQ;
		}
	}
	return res;
}

bool NodeManager::hasDragNode() const{
	for(vector<Node>::const_iterator it = nodes.begin(); it != nodes.end(); ++it){
		if(it->isDragged()) return true;
	}
	return false;
}
















