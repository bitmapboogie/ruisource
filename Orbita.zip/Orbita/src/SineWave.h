#pragma once

#include "SoundSettings.h"
#include "SineLUT.h"

//#include "rui.h"

// sine wave oscilator

class SineWave{
public:
	SineWave( float freq = 440.0f ){
		setFreq( freq );
		angle = 0.0f;
		val = 0;
	}
	
	void setFreq( float freq ){
		this->freq = freq;
		angleAdd = (freq * 360.0) / SoundSettings::sampleRatef;
	}
	
	float getFreq() const{
		return freq;
	}
	
	float tick(){
		val = SineLUT::sine( angle );
		angle += angleAdd;
		if( angle > 360.0f ){
			angle -= 360.0f;
		}
		return val;
	}
	
protected:
	float val;
	float freq;
	float angle, angleAdd;
};
