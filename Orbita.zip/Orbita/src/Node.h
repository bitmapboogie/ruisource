#pragma once

#include "cinder/Vector.h"
#include "cinder/gl/gl.h"
#include "cinder/app/App.h"
#include "cinder/app/TouchEvent.h"
#include "cinder/Rand.h"
#include "Center.h"
#include "Graphics.h"
#include "GlobalSettings.h"
//#include "rui.h"

using namespace ci;
using namespace ci::gl;
using namespace ci::app;

//Nodes are the white circles that the user creates
class Node{
public:
	Node(const Vec2f& pos, const Color& color);
	~Node();
	
	void update();
	void drawLapBegin();
	void draw();
	
	void beginDrag(const Vec2f& pos);
	void endDrag();
	bool isDragged() const;
	
	bool isInside( const Vec2f& pt )const;
	
	const Vec2f& getPos() const;
	void setPos( const Vec2f& pos );
	const Vec2f& getLapBeginPos() const;
	
	float getDistance()const;
	float getDistanceNorm() const;
	float getRadius() const;
	float getRadiusNorm() const;
	
	bool hasFinishedLap() const;
	
	const Color& getColor() const;
	void setColor( const Color& color );
	
protected:
	bool bDrag;
	Vec2f pos, oldPos;
	Vec2f dragPos;
	Vec2f lapBeginPos;
	float radius;
	float distance;
	float speed;
	float radiusCounter;
	bool bHasFinishedLap;
	bool bFirstLap;
	float distanceToLapBegin;
	Color color;
};
