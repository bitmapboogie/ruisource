#pragma once

#include "cinder/Cinder.h"
#include "cinder/Vector.h"
#include "cinder/app/App.h"

using namespace ci;

//some global stuff

class GlobalSettings{
public:
	
	//max radius for a Node
	static float getMaxRadius(){
		return maxRadius;
	}
	
	static float getInvMaxRadius(){
		return invMaxRadius;
	}
	
	//max distance to grab a node when touching the screen
	static float getMaxDistance(){
		return maxDistance;
	}
	
	static float getInvMaxDistance(){
		return invMaxDistance;
	}
	
	//this is called manualy! yea its pretty lame...
	static void prepareSettingsForIphone4(){
		bIsIphone4 = true;
		maxRadius = 50.0f;
		invMaxRadius = 1.0f / maxRadius;
		maxDistance = app::getWindowHeight() / 2.0f;
		invMaxDistance = 1.0f / maxDistance;
		center.x = app::getWindowWidth() / 2.0f;
		center.y = maxDistance;
	}
	
	//this is called manualy! yea its pretty lame...
	static void prepareSettingsForIphone3(){
		bIsIphone4 = false;
		maxRadius = 25.0f;
		invMaxRadius = 1.0f / maxRadius;
		maxDistance = app::getWindowHeight() / 2.0f;
		invMaxDistance = 1.0f / maxDistance;
		center.x = app::getWindowWidth() / 2.0f;
		center.y = maxDistance;
	}
	
	//iphone4 = retina display!
	static bool isIphone4(){
		return bIsIphone4;
	}
	
	static bool isIphone3(){
		return !bIsIphone4;
	}
	
	static const Vec2f& getCenter(){
		return center;
	}
	
protected:
	static float maxRadius;
	static float invMaxRadius;
	static float maxDistance;
	static float invMaxDistance;
	static Vec2f center;
	static bool bIsIphone4;
};
