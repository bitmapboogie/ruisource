#pragma once

#include "cinder/Vector.h"
#include "cinder/gl/gl.h"
#include "Graphics.h"
#include "GlobalSettings.h"

using namespace ci;

//growing halo that displays whenever a Node completes an orbit
class Halo{
public:
	Halo(const Vec2f& pos, int life);
	void update();
	void draw();
	bool isDead();
protected:
	Vec2f pos;
	float radius;
	float radiusAdd;
	float alpha;
	float life, iniLife;
};
