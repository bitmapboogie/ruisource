#pragma once

#include "Node.h"
#include "Center.h"
#include <vector>
#include "cinder/app/TouchEvent.h"

using namespace std;
using namespace ci;
using namespace ci::app;

//class to manage Nodes

class NodeManager{
public:
	NodeManager();
	~NodeManager();
	
	void update();
	void draw();
	
	void clear();
	
	Node* createNode( const Vec2f& pos );
	bool removeNode( const Node* node );
	
	vector<Node>& getNodes();
	
	Node* getNearestNode( const Vec2f& pt );
	Node* getNodeWithNearestLapPos( const Vec2f& pt );
	
	bool hasDragNode() const;
	
	
protected:
	vector<Node> nodes;
	vector<Node*> dragNodes;
	bool bHasGragNode;
};
