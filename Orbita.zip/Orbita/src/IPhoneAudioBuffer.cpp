#include "IPhoneAudioBuffer.h"

IPhoneAudioBufferListener* IPhoneAudioBuffer::listener = NULL;
AQCallbackStruct IPhoneAudioBuffer::dataStruct;
bool IPhoneAudioBuffer::bInited = false;
std::thread* IPhoneAudioBuffer::mThread = NULL;
std::mutex IPhoneAudioBuffer::mMutex;
 
void audioCallBack( void *in, AudioQueueRef inQ, AudioQueueBufferRef	outQB) {
	UInt32 err;
	AQCallbackStruct* inData = (AQCallbackStruct*) in;
	if(inData->frameCount > 0){
		outQB->mAudioDataByteSize = 4*inData->frameCount;
		IPhoneAudioBufferData data;
		data.buffer = (short*)outQB->mAudioData;
		data.bufferSize = inData->frameCount;
		data.numChannels = 2;
		IPhoneAudioBuffer::lockBuffer();
		IPhoneAudioBuffer::getListener()->getData( data );
		IPhoneAudioBuffer::unlockBuffer();
		AudioQueueEnqueueBuffer( inQ, outQB, 0, NULL );
	}else{
		err = AudioQueueStop(inData->queue, false);
	}
}

void threadedFunc(){
	while(1){
		CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.25, false);
	}
}

void IPhoneAudioBuffer::init( IPhoneAudioBufferListener* _listener ){
	if(bInited) return;
	listener = _listener;
	UInt32 err;
	dataStruct.mDataFormat.mSampleRate = 44100.0;
	dataStruct.mDataFormat.mFormatID = kAudioFormatLinearPCM;
	dataStruct.mDataFormat.mFormatFlags = kLinearPCMFormatFlagIsSignedInteger  | kAudioFormatFlagIsPacked;
	dataStruct.mDataFormat.mBytesPerPacket = 4;
	dataStruct.mDataFormat.mFramesPerPacket = 1; // this means each packet in the AQ has two samples, one for each channel -> 4 bytes/frame/packet
	dataStruct.mDataFormat.mBytesPerFrame = 4;
	dataStruct.mDataFormat.mChannelsPerFrame = 2;
	dataStruct.mDataFormat.mBitsPerChannel = 16;
	
	err = AudioQueueNewOutput(&dataStruct.mDataFormat, audioCallBack, &dataStruct, CFRunLoopGetCurrent(), kCFRunLoopCommonModes, 0, &dataStruct.queue);
	
	dataStruct.frameCount = 1024;
	UInt32 bufferBytes  = dataStruct.frameCount * dataStruct.mDataFormat.mBytesPerFrame;
	
	// alloc 3 buffers.
	for (int i=0; i<BUFFERS; i++) {
		err = AudioQueueAllocateBuffer(dataStruct.queue, bufferBytes, &dataStruct.mBuffers[i]);
		// "Prime" by calling the callback once per buffer
		audioCallBack (&dataStruct, dataStruct.queue, dataStruct.mBuffers[i]);
	}	
	
	// set the volume of the queue -- note that the volume knobs on the ipod / celestial also change this
	err = AudioQueueSetParameter(dataStruct.queue, kAudioQueueParam_Volume, 1.0);
	
	// Start the queue
	err = AudioQueueStart(dataStruct.queue, NULL);
	
	// Hang around forever...
	if(!mThread) mThread = new std::thread( threadedFunc );
	bInited = true;
}



void IPhoneAudioBuffer::stop(){
	if(mThread){
		delete mThread;
		mThread = NULL;
	}
	AudioQueueDispose(dataStruct.queue, true);
	//bInited = false;
}