#pragma once

#include "Halo.h"
#include "Node.h"
#include "cinder/Vector.h"
#include <vector>

using namespace std;
using namespace ci;

//manager class to all Halos
class HaloManager{
public:
	HaloManager();
	~HaloManager();
	void update();
	void draw();
	void createHalo( const Vec2f& pos, int life );
protected:
	vector<Halo> halos;
};

