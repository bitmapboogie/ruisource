#include "HaloManager.h"

HaloManager::HaloManager(){
	
}

HaloManager::~HaloManager(){
	halos.clear();
}

void HaloManager::update(){
	for(vector<Halo>::iterator it = halos.begin(); it != halos.end();){
		Halo& halo = *it;
		if(halo.isDead()){
			halos.erase( it );
		}else{
			halo.update();
			++it;
		}
	}
}

void HaloManager::draw(){
	for(vector<Halo>::iterator it = halos.begin(); it != halos.end(); ++it){
		it->draw();
	}
}

void HaloManager::createHalo( const Vec2f& pos, int life ){
	halos.push_back( Halo( pos, life ) );
}
