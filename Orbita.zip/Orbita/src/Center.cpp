#include "Center.h"

Vec2f Center::pos = Vec2f::zero();

Center::Center(const Vec2f& pos){
	radius = GlobalSettings::getMaxRadius();
	this->pos = pos;
	color = Color::white();
	
	if( GlobalSettings::isIphone4() ){
		rectWidth = 5.0f;
		rectHeight = 30.0f;
	} else{
		rectWidth = 2.5;
		rectHeight = 15.0f;
	}
	
}

void Center::draw(){
	gl::color( color );
	Graphics::drawRectSolid( Vec2f(pos.x - rectWidth, pos.y - rectHeight), Vec2f( pos.x + rectWidth, pos.y + rectHeight) );
	Graphics::drawRectSolid( Vec2f(pos.x - rectHeight, pos.y - rectWidth), Vec2f( pos.x + rectHeight, pos.y + rectWidth) );
}

const Vec2f& Center::getPos() const{
	return pos;
}

float Center::getRadius() const{
	return radius;
}

bool Center::isInside( const Vec2f& pt ) const{
	float dx = pos.x - pt.x;
	float dy = pos.y - pt.y;
	return dx*dx+dy*dy < radius*radius;
}

void Center::setColor( const Color& color ){
	this->color = color;
}