#pragma once

#include "cinder/Rect.h"
#include "cinder/Vector.h"
#include "ButtonBase.h"

//the "help" button on the lower right corner of the screen

class HelpButton: public ButtonBase{
public:
	
	HelpButton(){
		rectWidth = rectHeight = 0.0f;
	}
	
	void init(){
		radius = GlobalSettings::getMaxRadius();
		radiusSQ = radius*radius;
		if( GlobalSettings::isIphone4() ){
			pos.x = (float)app::getWindowWidth() - 30.0f;
			pos.y = (float)app::getWindowHeight() - 30.0f;
			rectWidth = 20.0f;
			rectHeight = 5.0f;
		}else{
			pos.x = (float)app::getWindowWidth() - 15.0f;
			pos.y = (float)app::getWindowHeight() - 15.0f;
			rectWidth = 10.0;
			rectHeight = 2.0f;
		}
		dotPos.x = 0.0f;
		dotPos.y = rectHeight - (rectWidth*0.5f) - 1.0f;
	}
	
	void draw(){
		glPushMatrix();
		glTranslatef( pos.x, pos.y, 0.0f );
		gl::color( Color(0.2f, 0.2f, 0.2f) );
		Graphics::drawRectSolid( Vec2f(-rectHeight, rectWidth), Vec2f(rectHeight, 0.0f));
		Graphics::drawCircleSolid( dotPos, rectHeight );
		glPopMatrix();
	}
	
protected:
	float rectWidth, rectHeight;
	Vec2f dotPos;
};
