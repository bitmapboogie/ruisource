#pragma once

//#include "rui.h"

#ifndef TWO_PI
#define TWO_PI 6.28318530717958647693
#endif

#ifndef PI
#define PI       3.14159265358979323846
#endif

#define SINE_LUT_LOOPS 8
#define SINE_LUT_RES (360 * SINE_LUT_LOOPS)

#define SINE_LUT_RAD_TO_DEG 57.2958f

#include "cinder/CinderMath.h"

//simple sine LUT class i made up. 
//Not sure this is the proper way of doing this stuff but seems to work..

class SineLUT{
public:
	
	static float sine(float angleDeg){
		return lut[ (int)(angleDeg * SINE_LUT_LOOPS) ];
	}
	
	static float sineSafe( float angleDeg ){
		if( angleDeg > 360.0f ){
			angleDeg = fmodf( angleDeg, 360.0f );
		}
		return lut[ (int)(angleDeg * SINE_LUT_LOOPS) ];
	}
	
	static float sineRad( float angleRad ){
		return sine( angleRad * SINE_LUT_RAD_TO_DEG );
	}
	
	static float sineSafeRad( float angleRad ){
		return sineSafe( angleRad * SINE_LUT_RAD_TO_DEG );
	}
	
protected:
	static float* lut;
	class SineLUTIniter{
	protected:
		SineLUTIniter(){
			lut = new float[ SINE_LUT_RES ];
			float angle = 0.0f;
			float angleAdd = TWO_PI / (SINE_LUT_RES-1);
			for(int i=0; i<SINE_LUT_RES; i++){
				lut[i] = sinf( angle );
				angle += angleAdd;
			}
		}
		friend class SineLUT;
	};
	
	static SineLUTIniter _lutIniter;
	
	friend class SineLUTIniter;
};
