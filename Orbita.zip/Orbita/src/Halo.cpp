#include "Halo.h"

Halo::Halo(const Vec2f& pos, int life){
	this->pos = pos;
	this->life = (float)life;
	iniLife = this->life;
	radius = 0.0f;
	if( GlobalSettings::isIphone3() ){
		radiusAdd = 1.5f;
	} else {
		radiusAdd = 3.0f;
	}
	alpha = 1.0f;
}

void Halo::update(){
	life -= 1.0f;
	radius += radiusAdd;
	alpha = (life / iniLife);
}

void Halo::draw(){
	gl::color( ColorA(1.0f, 1.0f, 1.0f, alpha) );
	Graphics::drawHalo( pos, radius );
}

bool Halo::isDead(){
	return life <= 0.0f;
}
