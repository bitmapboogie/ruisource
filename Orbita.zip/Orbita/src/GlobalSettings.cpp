#include "GlobalSettings.h"

float GlobalSettings::maxRadius = 0.0f;
float GlobalSettings::invMaxRadius = 0.0f;
float GlobalSettings::maxDistance = 0.0f;
float GlobalSettings::invMaxDistance = 0.0f;
Vec2f GlobalSettings::center = Vec2f::zero();
bool GlobalSettings::bIsIphone4 = false;


