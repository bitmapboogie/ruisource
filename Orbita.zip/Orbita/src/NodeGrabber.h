#pragma once

#include "NodeManager.h"
#include "Graphics.h"
#include "cinder/app/TouchEvent.h"
#include "cinder/app/AppCocoaTouch.h"

using namespace ci;
using namespace ci::app;

//class to interface between screen touches and controlling nodes
class NodeGrabber{
public:
	
	//these control the relation between a touch and a node.
	//there are 5 of these as the iphone can detect only 5 simultaneous touches
	class NodeGrabberUnit{
	public:
		NodeGrabberUnit(){
			touchPos = Vec2f::zero();
			node = NULL;
		}
		
		void beginGrab( Node* node, const Vec2f& pos ){
			this->node = node;
			node->beginDrag( pos );
		}
		
		void endGrab(){
			if( node ){
				if( node->isDragged() ){
					node->endDrag();
					node->setColor( Color::white() );
				}
			}
			node = NULL;
		}
		
		void setTouchPos( const Vec2f& touchPos ){
			this->touchPos = touchPos;
			if( node ){
				node->setPos( touchPos );
			}
		}
		
		bool isGrabbing() const{
			return node != NULL;
		}
		
		Node* getNode() const{
			return node;
		}
		
	protected:
		Vec2f touchPos;
		Node* node;
	};
	
	NodeGrabber(){
		nodeGrabberUnits = new NodeGrabberUnit[5];
	}
	
	~NodeGrabber(){
		delete[] nodeGrabberUnits;
	}
	
	bool hasTouches() const{
		return bHasTouches;
	}
	
	void touchesBegan( const TouchEvent& e, NodeManager& nodeManager, Center& center ){
		bHasTouches = true;
		const vector<TouchEvent::Touch>& touches = e.getTouches();
		for( vector<TouchEvent::Touch>::const_iterator it = touches.begin(); it != touches.end(); ++it ){
			const TouchEvent::Touch& touch = *it;
			if( center.isInside( touch.getPos() ) ){
				Node* node = nodeManager.createNode( touch.getPos() );
				nodeGrabberUnits[ touch.getId() ].beginGrab( node, touch.getPos() );
				node->setColor( Color(1.0f, 0.0f, 0.0f) );
			} else {
				Node* node = nodeManager.getNearestNode( touch.getPos() );
				if( node ){
					if( node->isDragged() ) continue;
					nodeGrabberUnits[ touch.getId() ].beginGrab( node, touch.getPos() );
				}
			}
		}
	}
	
	void touchesMoved( const TouchEvent& e, NodeManager& nodeManager, Center& center ){
		const vector<TouchEvent::Touch>& touches = e.getTouches();
		for( vector<TouchEvent::Touch>::const_iterator it = touches.begin(); it != touches.end(); ++it ){
			const TouchEvent::Touch& touch = *it;
			if( nodeGrabberUnits[ touch.getId() ].isGrabbing() ){
				nodeGrabberUnits[ touch.getId() ].setTouchPos( touch.getPos() );
				Node* node = nodeGrabberUnits[ touch.getId() ].getNode();
				if( node ){
					if( center.isInside( node->getPos() ) ){
						node->setColor( Color(1.0f, 0.0f, 0.0f) );
					} else {
						node->setColor( Color::white() );
					}
				}
			}
		}
	}
	
	void touchesEnded( const TouchEvent& e, NodeManager& nodeManager, Center& center ){
		const vector<TouchEvent::Touch>& touches = e.getTouches();
		for( vector<TouchEvent::Touch>::const_iterator it = touches.begin(); it != touches.end(); ++it ){
			const TouchEvent::Touch& touch = *it;
			const Node* node = nodeGrabberUnits[ touch.getId() ].getNode();
			if( node ){
				if( center.isInside( node->getPos() ) ){
					nodeManager.removeNode( node );
				}
			}
			nodeGrabberUnits[ touch.getId() ].endGrab();
		}
		bHasTouches = AppCocoaTouch::get()->getActiveTouches().size() > 0;
	}
	
protected:
	NodeGrabberUnit* nodeGrabberUnits;
	bool bHasTouches;
	bool isNodeGrabbed( Node* node ){
		for( int i=0; i<5; ++i ){
			if( node == nodeGrabberUnits[i].getNode() ){
				return true;
			}
		}
		return false;
	}
	bool stopGrabNode( Node* node ){
		bool bFound = false;
		for(int i=0; i<5; ++i){
			if( node == nodeGrabberUnits[i].getNode() ){
				nodeGrabberUnits[i].endGrab();
				bFound = true;
			}
		}
		return bFound;
	}
									   
};





