#pragma once

#include "cinder/Vector.h"
#include "cinder/app/TouchEvent.h"

using namespace ci;
using namespace ci::app;

//base class for (round) buttons
class ButtonBase{
public:
	
	ButtonBase( ){
		pos = Vec2f::zero();
		radius = radiusSQ = 0.0f;
	}
	
	virtual void init() = 0;
	
	bool isInside( const Vec2f& pt ) const {
		float dx = pt.x - pos.x;
		float dy = pt.y - pos.y;
		return dx*dx+dy*dy < radiusSQ;
	}
	
	bool isInside( const TouchEvent& e ){
		const vector<TouchEvent::Touch>& touches = e.getTouches();
		for(vector<TouchEvent::Touch>::const_iterator it = touches.begin(); it != touches.end(); ++it){
			if( isInside( it->getPos() ) ){
				return true;
			}
		}
		return false;
	}
	
	const Vec2f& getPos() const{
		return pos;
	}
	
	float getRadius() const {
		return radius;
	}
							 
	float getRadiusSQ() const{
		return radiusSQ;
	}
	
protected:
	Vec2f pos;
	float radius, radiusSQ;
};
