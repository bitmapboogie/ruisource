#pragma once

#include "NodeManager.h"
#include "SoundGenerator.h"
#include "HaloManager.h"

//converts a node to sound!
class NodeConverter{
public:
	
	void convert( NodeManager& nodeManager, SoundGenerator& soundGen, HaloManager& haloManager ){
		vector<Node>& nodes = nodeManager.getNodes();
		for( vector<Node>::const_iterator it = nodes.begin(); it != nodes.end(); ++it){
			const Node& node = *it;
			if( node.hasFinishedLap() ){
				float freq = (MAX_FREQ - MIN_FREQ) * node.getDistanceNorm() + MIN_FREQ;
				float radiusNorm = node.getRadiusNorm();
				float duration = ( MAX_DURATION - MIN_DURATION ) * (radiusNorm*radiusNorm) + MIN_DURATION;
				soundGen.trigger( freq, duration );
				haloManager.createHalo( node.getLapBeginPos(), (int)( radiusNorm * radiusNorm * 50.0f) + 10 );
			}
		}
	}
	
protected:
	static const float MAX_FREQ = 600.0f;
	static const float MIN_FREQ = 150.0f;
	static const float MAX_DURATION = 1.0f;
	static const float MIN_DURATION = 0.0f;
	
};

