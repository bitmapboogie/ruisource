#pragma once

#include <AudioToolbox/AudioQueue.h>
#include "cinder/Function.h"
#include "cinder/Thread.h"

#define BUFFERS 3

using namespace ci;


struct IPhoneAudioBufferData{
	short* buffer;
	int bufferSize;
	int numChannels;
};

class IPhoneAudioBufferListener{
public:
	virtual void getData( IPhoneAudioBufferData& data) = 0;
};

struct AQCallbackStruct;


class IPhoneAudioBuffer{
public:
	
	static void init( IPhoneAudioBufferListener* listener);
	static void stop();
	static IPhoneAudioBufferListener* getListener(){
		return listener;
	}
	static void lockBuffer(){
		mMutex.lock();
	}
	static void unlockBuffer(){
		mMutex.unlock();
	}
	
protected:
	//cant initialize!!
	//static only
	IPhoneAudioBuffer(){}
	
	
protected:
	static IPhoneAudioBufferListener* listener;
	static AQCallbackStruct dataStruct;
	static bool bInited;
	static std::thread *mThread;
	static std::mutex mMutex;
	
};

typedef struct AQCallbackStruct {
	AudioQueueRef					queue;
	UInt32							frameCount;
	AudioQueueBufferRef				mBuffers[BUFFERS];
	AudioStreamBasicDescription		mDataFormat;
} AQCallbackStruct;