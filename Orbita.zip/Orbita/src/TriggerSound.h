#pragma once

#include "SineWave.h"
#include "SoundSettings.h"

//class that generates the sound played by Nodes

class TriggerEnvelope{
public:
	
	//simple envelope
	TriggerEnvelope(){
		bIncrease = true;
		bTriggered = false;
		val = 0.0f;
		increaseAmount = decreaseAmount = 0.0f;
	}
	
	void trigger( float upTime, float downTime ){
		val = 0.0f;
		bIncrease = true;
		increaseAmount = ( 1.0f / upTime ) / SoundSettings::sampleRatef;
		decreaseAmount = ( 1.0f / downTime ) / SoundSettings::sampleRatef;
		bTriggered = true;
	}
	
	float tick(){
		if(bTriggered == false) return 0.0f;
		if( bIncrease ){
			val += increaseAmount;
			if(val >= 1.0f){
				bIncrease = false;
				val = 1.0f;
			}
		}else{
			val -= decreaseAmount;
			if( val <= 0.0f ){
				bTriggered = false;
				return 0.0f;
			}
		}
		return val;
	}
	
protected:
	bool bTriggered;
	bool bIncrease;
	float val;
	float increaseAmount, decreaseAmount;;
};

class TriggerSound{
public:
	TriggerSound( float freq = 440.0f ){
		osc.setFreq( freq );
	}
	
	void update(){
		/*if( volume > 0.0f ){
			volume -= decay;
		}else volume = 0.0f;*/
	}
	
	void trigger( float freq, float seconds ){
		osc.setFreq( freq );
		envelope.trigger( seconds * 0.1f, seconds * 0.9f );
	}
	
	float tick(){
		return osc.tick() * envelope.tick();
	}
	
	
protected:
	TriggerEnvelope envelope;
	SineWave osc;
};