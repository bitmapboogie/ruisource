#pragma once

#include "IPhoneAudioBuffer.h"
#include "cinder/Rand.h"
#include "SineWave.h"
#include "TriggerSound.h"

using namespace ci;

//generates sine waves

class SoundGenerator: public IPhoneAudioBufferListener{
public:
	
	//10 oscilators for polyphony
	SoundGenerator( int numOscs = 10 ){
		if(numOscs <= 0) numOscs = 1;
		this->numOscs = numOscs;
		sounds = new TriggerSound[ numOscs ];
		soundIndex = 0;
		
		IPhoneAudioBuffer::init( this );
	}
	
	~SoundGenerator(){
		delete[] sounds;
	}
	
	void trigger( float freq, float duration ){
		sounds[ soundIndex ].trigger( freq, duration );
		soundIndex = (soundIndex+1) % numOscs;
	}
	
	void quit(){
		IPhoneAudioBuffer::stop();
	}
	
protected:
	
	static const float MAX_SHORT_F = 32767.0f;
	static const int MAX_SHORT_I = 32767;
	
	TriggerSound* sounds;
	int soundIndex;
	int numOscs;				  
	
	void getData( IPhoneAudioBufferData& data ){
		short* buffer = data.buffer;
		int bufferSize = data.bufferSize;
		float val;
		short vals;
		for(int i=0; i<bufferSize; ++i){
			val = 0.0f;
			for(int j=0; j<numOscs; ++j){
				val += sounds[j].tick();
			}
			val /= numOscs;
			vals = (short)(val * MAX_SHORT_F);
			buffer[i*2] = vals;
			buffer[i*2+1] = vals;
		}
	}
};





