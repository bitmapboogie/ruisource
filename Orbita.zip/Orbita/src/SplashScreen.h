#pragma once

#include "cinder/gl/Texture.h"
#include "cinder/Surface.h"
#include "cinder/ImageIo.h"
#include "cinder/Rect.h"
#include "cinder/app/App.h"

using namespace ci;

//the splash screen displayed at the beginning

class SplashScreen{
public:
	SplashScreen(){
		bShowing = true;
		bFade = false;
		alpha = 1.0f;
		counter = 0;
	}
	
	void loadImage(){
		texture = gl::Texture( ci::loadImage( loadResource( "Splashscreen.png" ) ) );
	}
	
	void update(){
		if( bShowing ){
			if( bFade ){
				alpha -= 0.05f;
				if( alpha <= 0.0f ){
					alpha = 0.0f;
					bShowing = false;
				}
			}
		}
	}
	
	void draw(){
		gl::color( ColorA( 1.0f, 1.0f, 1.0f, alpha ) );
		gl::draw( texture, Rectf( 0.0f, 0.0f, (float)app::getWindowWidth(), (float)app::getWindowHeight() ) );
	}
	
	void fadeOut(){
		bFade = true;
	}
	
	bool isShowing() const{
		return bShowing;
	}
protected:
	gl::Texture texture;
	float alpha;
	bool bShowing;
	bool bFade;
	int counter;
};