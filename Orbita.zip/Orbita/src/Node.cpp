#include "Node.h"

Node::Node(const Vec2f& pos, const Color& color){
	this->pos = pos;
	this->color = color;
	dragPos = pos;
	oldPos = pos;
	distance = 0.0f;
	speed = 0.0f;
	radiusCounter = Rand::randFloat(0.0f, TWO_PI);
	if(GlobalSettings::isIphone4()) radius = fabsf( cosf( radiusCounter ) ) * 76.0f + 4.0f;
	else radius = fabsf( cosf( radiusCounter ) ) * 38.0f + 2.0f;
	bHasFinishedLap = false;
	lapBeginPos = pos;
	distanceToLapBegin = 0.0f;
	bFirstLap = true;
	bDrag = true;
}

Node::~Node(){
	
}

void Node::update(){
	if( bDrag ){
		dragPos += (pos - dragPos) * 0.05f;
		if(GlobalSettings::isIphone4()) radius = fabsf( cosf( radiusCounter ) ) * 76.0f + 4.0f;
		else radius = fabsf( cosf( radiusCounter ) ) * 38.0f + 2.0f;
		radiusCounter += 0.015f;
		lapBeginPos = pos;
		oldPos = dragPos;
	}else{
		Vec2f temp = pos;
		Vec2f diff = pos - oldPos;
		float diffLength = diff.lengthSquared();
		if(diffLength > 0.0f){
			float invLength = 1.0f / sqrtf( diffLength );
			diff *= invLength;
		}else{
			diff.x = 0.01f;
			diff.y = 0.01f;
		}
		diff *= speed;
		pos += diff;
		oldPos = temp;
		const Vec2f& center = GlobalSettings::getCenter();
		diff = pos - center;
		diff.safeNormalize();
		diff *= distance;
		pos = center + diff;
		distanceToLapBegin = (lapBeginPos - pos).lengthSquared();
		if(distanceToLapBegin < speed*speed && !bHasFinishedLap && !bFirstLap){
			bHasFinishedLap = true;
		}else{
			bFirstLap = false;
			bHasFinishedLap = false;
		}
	}
}

void Node::drawLapBegin(){
	if( bDrag ) return;
	gl::color( Color(1.0f, 0.0f, 0.0f ) );
	Graphics::drawCircleStroked( lapBeginPos, radius * 0.5f );
}

void Node::draw(){
	gl::color( color );
	if( bDrag ){
		if(GlobalSettings::isIphone4()) Graphics::drawCircleStroked( pos, radius + 100.0f);
		else Graphics::drawCircleStroked( pos, radius + 50.0f);
		Graphics::drawLine( pos, dragPos );
	}
	Graphics::drawLine( pos, GlobalSettings::getCenter() );
	Graphics::drawCircleSolid( pos, radius * 0.5f );
}

void Node::beginDrag(const Vec2f& pos){
	bDrag = true;
	setPos( pos );
	lapBeginPos = pos;
}

void Node::endDrag(){
	bDrag = false;
	const Vec2f& center = GlobalSettings::getCenter();
	distance = (center - pos).length(); 
	speed = (dragPos - pos).length() * 0.1f;
	if(speed < 0.001f){
		speed = 0.001f;
	}
	distanceToLapBegin = 0.0f;
	lapBeginPos = pos;
	bFirstLap = true;
	oldPos = dragPos;
}

bool Node::isDragged() const{
	return bDrag;
}

bool Node::isInside( const Vec2f& pt ) const{
	float dx = pt.x - pos.x;
	float dy = pt.y - pos.y;
	return dx*dx+dy*dy < GlobalSettings::getMaxRadius()*GlobalSettings::getMaxRadius();
}

const Vec2f& Node::getPos() const{
	return pos;
}

void Node::setPos( const Vec2f& pos ){
	this->pos = pos;
	distance = (GlobalSettings::getCenter() - pos).length();
}

const Vec2f& Node::getLapBeginPos() const{
	return lapBeginPos;
}

float Node::getDistance() const{
	return distance;
}

float Node::getDistanceNorm() const{
	return distance * GlobalSettings::getInvMaxDistance();
}

float Node::getRadius() const{
	return radius;
}
float Node::getRadiusNorm() const{
	return radius * GlobalSettings::getInvMaxRadius();
}

bool Node::hasFinishedLap() const{
	if( bDrag ) return false;
	return bHasFinishedLap;
}

const Color& Node::getColor() const{
	return color;
}

void Node::setColor( const Color& color ){
	this->color = color;
}
