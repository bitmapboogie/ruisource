#include "SineLUT.h"

float* SineLUT::lut = NULL;
SineLUT::SineLUTIniter SineLUT::_lutIniter = SineLUT::SineLUTIniter(); 
